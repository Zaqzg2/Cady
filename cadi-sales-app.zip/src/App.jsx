import React, { useEffect, useState } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Customers from './pages/Customers';
import CustomerDetail from './pages/CustomerDetail';
import CustomerStatementPrint from './pages/CustomerStatementPrint';
import Products from './pages/Products';
import InvoiceForm from './pages/InvoiceForm';
import InvoicePrint from './pages/InvoicePrint';
import ReceiptForm from './pages/ReceiptForm';
import ReceiptPrint from './pages/ReceiptPrint';
import Settings from './pages/Settings';
import Reports from './pages/Reports';
import NotFound from './pages/NotFound';
import BottomNav from './components/BottomNav';
import { ToastProvider } from './components/Toast';
import { runSeedIfNeeded } from './db/seed';
import { useTheme } from './hooks/useTheme';
import { useFontFamily } from './hooks/useFontFamily';
import logoMark from './assets/logo-full.png';

export default function App() {
  const [ready, setReady] = useState(false);
  useTheme();
  useFontFamily();

  useEffect(() => {
    runSeedIfNeeded().finally(() => setReady(true));
  }, []);

  if (!ready) {
    return (
      <div className="boot-screen">
        <img src={logoMark} alt="كادي للمنظفات" className="boot-logo" />
        <style>{`
          .boot-screen {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--color-bg);
          }
          .boot-logo {
            width: 60%;
            max-width: 280px;
            animation: scaleIn 0.4s ease;
          }
        `}</style>
      </div>
    );
  }

  return (
    <ToastProvider>
      <HashRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/customers" element={<Customers />} />
          <Route path="/customers/:id" element={<CustomerDetail />} />
          <Route path="/customers/:id/statement" element={<CustomerStatementPrint />} />
          <Route path="/products" element={<Products />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/invoice/new" element={<InvoiceForm />} />
          <Route path="/invoice/:id/edit" element={<InvoiceForm />} />
          <Route path="/invoice/:id/print" element={<InvoicePrint />} />
          <Route path="/receipt/new" element={<ReceiptForm />} />
          <Route path="/receipt/:id/edit" element={<ReceiptForm />} />
          <Route path="/receipt/:id/print" element={<ReceiptPrint />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <BottomNav />
      </HashRouter>
    </ToastProvider>
  );
}
