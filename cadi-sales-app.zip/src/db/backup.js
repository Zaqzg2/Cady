// ============================================================
// خدمة النسخ الاحتياطي — تصدير/استيراد كامل بيانات IndexedDB
// الصيغة: ملف JSON واحد يحتوي كل الجداول + معلومات تعريفية
// ============================================================
import { db } from './db';

export const BACKUP_FORMAT_VERSION = 1;

/**
 * يجمع كل بيانات التطبيق (عملاء، منتجات، فواتير، سندات، كشف حساب، إعدادات)
 * في كائن واحد قابل للتحويل لـJSON.
 */
export async function exportAllData() {
  const [customers, products, invoices, receipts, ledger, settings] = await Promise.all([
    db.customers.toArray(),
    db.products.toArray(),
    db.invoices.toArray(),
    db.receipts.toArray(),
    db.ledger.toArray(),
    db.settings.toArray(),
  ]);

  return {
    formatVersion: BACKUP_FORMAT_VERSION,
    appName: 'كادي للمنظفات',
    exportedAt: new Date().toISOString(),
    counts: {
      customers: customers.length,
      products: products.length,
      invoices: invoices.length,
      receipts: receipts.length,
      ledger: ledger.length,
    },
    data: { customers, products, invoices, receipts, ledger, settings },
  };
}

/**
 * يولّد ملف JSON من كل البيانات ويبدأ تحميله مباشرة على الجهاز.
 */
export async function downloadBackupFile() {
  const backup = await exportAllData();
  const json = JSON.stringify(backup, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const dateStamp = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `كادي-نسخة-احتياطية-${dateStamp}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  return backup;
}

/**
 * يتحقق من صحة بنية ملف النسخة الاحتياطية قبل أي استيراد فعلي.
 * يرمي خطأ موصوفاً بالعربية إن كان الملف غير صالح.
 */
export function validateBackupFile(parsed) {
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('الملف غير صالح — ليس بصيغة JSON صحيحة');
  }
  if (!parsed.data || typeof parsed.data !== 'object') {
    throw new Error('الملف لا يحتوي على بيانات تطبيق كادي');
  }
  const requiredTables = ['customers', 'products', 'invoices', 'receipts', 'ledger'];
  for (const table of requiredTables) {
    if (!Array.isArray(parsed.data[table])) {
      throw new Error(`الملف ناقص — لا يحتوي على جدول "${table}"`);
    }
  }
  return true;
}

/**
 * يقرأ ملف نسخة احتياطية (File) ويُرجع الكائن المُحلَّل بعد التحقق من صحته.
 */
export async function readBackupFile(file) {
  const text = await file.text();
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('تعذّر قراءة الملف — تأكد أنه ملف النسخة الاحتياطية الصحيح');
  }
  validateBackupFile(parsed);
  return parsed;
}

/**
 * استيراد بنمط "استبدال كامل": يمسح كل البيانات الحالية ويستعيدها من النسخة الاحتياطية بالكامل.
 * يحافظ على الإعدادات الحالية (الطابعة، تخطيط الفاتورة) إلا إذا طُلب استيرادها أيضاً.
 */
export async function restoreFromBackup(backup, { includeSettings = false } = {}) {
  const { customers, products, invoices, receipts, ledger, settings } = backup.data;

  await db.transaction('rw', db.customers, db.products, db.invoices, db.receipts, db.ledger, db.settings, async () => {
    await db.customers.clear();
    await db.products.clear();
    await db.invoices.clear();
    await db.receipts.clear();
    await db.ledger.clear();

    if (customers.length) await db.customers.bulkAdd(customers);
    if (products.length) await db.products.bulkAdd(products);
    if (invoices.length) await db.invoices.bulkAdd(invoices);
    if (receipts.length) await db.receipts.bulkAdd(receipts);
    if (ledger.length) await db.ledger.bulkAdd(ledger);

    if (includeSettings && Array.isArray(settings) && settings.length) {
      await db.settings.clear();
      await db.settings.bulkAdd(settings);
    }
  });
}

/**
 * استيراد بنمط "دمج": يضيف بيانات النسخة الاحتياطية فوق البيانات الحالية دون مسحها.
 * يستخدم معرّفات جديدة تلقائياً (لا يحافظ على نفس الأرقام التسلسلية القديمة)
 * لتفادي أي تصادم مع سجلات موجودة حالياً، ويعيد ربط العلاقات (customerId, refId, productId)
 * بالمعرّفات الجديدة المُنشأة لضمان سلامة الروابط بين الجداول.
 *
 * ملاحظة: إن كان الملف المستورد يحتوي على عميل "عميل نقدي" (isCash:true)، سيُضاف كعميل
 * نقدي ثانٍ منفصل عن الموجود حالياً (لا دمج تلقائي بينهما)، لأن الدمج بالاسم قد يخلط
 * بيانات عميلين مختلفين فعلياً. يمكن للمستخدم حذف المكرر يدوياً من صفحة العملاء بعد الاستيراد.
 */
export async function mergeFromBackup(backup) {
  const { customers, products, invoices, receipts, ledger } = backup.data;

  await db.transaction('rw', db.customers, db.products, db.invoices, db.receipts, db.ledger, async () => {
    // عملاء: نُبقي على معرّف مؤقت قديم → جديد لإعادة الربط
    const customerIdMap = new Map();
    for (const c of customers) {
      const { id: oldId, ...rest } = c;
      const newId = await db.customers.add(rest);
      customerIdMap.set(oldId, newId);
    }

    const productIdMap = new Map();
    for (const p of products) {
      const { id: oldId, ...rest } = p;
      const newId = await db.products.add(rest);
      productIdMap.set(oldId, newId);
    }

    const invoiceIdMap = new Map();
    for (const inv of invoices) {
      const { id: oldId, customerId, items, ...rest } = inv;
      const newCustomerId = customerIdMap.get(customerId) ?? customerId;
      const newItems = (items || []).map((it) => ({
        ...it,
        productId: productIdMap.get(it.productId) ?? it.productId,
      }));
      const newId = await db.invoices.add({ ...rest, customerId: newCustomerId, items: newItems });
      invoiceIdMap.set(oldId, newId);
    }

    const receiptIdMap = new Map();
    for (const r of receipts) {
      const { id: oldId, customerId, ...rest } = r;
      const newCustomerId = customerIdMap.get(customerId) ?? customerId;
      const newId = await db.receipts.add({ ...rest, customerId: newCustomerId });
      receiptIdMap.set(oldId, newId);
    }

    for (const entry of ledger) {
      const { id: oldId, customerId, refId, type, ...rest } = entry;
      const newCustomerId = customerIdMap.get(customerId) ?? customerId;
      let newRefId = refId;
      if (type === 'invoice_sale' || type === 'invoice_return') {
        newRefId = invoiceIdMap.get(refId) ?? refId;
      } else if (type === 'receipt') {
        newRefId = receiptIdMap.get(refId) ?? refId;
      }
      await db.ledger.add({ ...rest, type, customerId: newCustomerId, refId: newRefId });
    }
  });
}
