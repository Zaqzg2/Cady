// ============================================================
// قاعدة البيانات المحلية — Dexie (IndexedDB)
// تعمل بالكامل دون إنترنت
// ============================================================
import Dexie from 'dexie';

export const db = new Dexie('cadiSalesDB');

db.version(1).stores({
  // العملاء
  customers: '++id, name, phone, area, balance, createdAt',

  // المنتجات
  products: '++id, name, price, unit, category, isActive',

  // الفواتير (بيع / مرتجع)
  invoices: '++id, type, customerId, date, total, discount, netTotal, status, items, signature, notes',

  // سندات القبض (التحصيلات)
  receipts: '++id, customerId, amount, date, repSignature, notes, invoiceId',

  // حركات رصيد العميل (دفتر كشف الحساب) — مشتقة، لكن نخزنها للسرعة والتاريخ
  ledger: '++id, customerId, date, type, refId, debit, credit, balanceAfter, note',

  // إعدادات التطبيق (مفتاح/قيمة)
  settings: 'key',
});

// الإصدار 2: لا تغيير في الفهارس (Dexie لا يحتاج تعريف كل حقل)؛
// أضيفت حقول جديدة للكائنات المخزَّنة فقط: paymentTerm/paymentMethod على الفواتير،
// collectionMethod على السندات، وrefNumber القابل للتعديل اليدوي على كليهما.
// عدم تغيير الفهارس يعني توافقاً تلقائياً كاملاً مع البيانات الموجودة مسبقاً.
db.version(2).stores({
  customers: '++id, name, phone, area, balance, createdAt',
  products: '++id, name, price, unit, category, isActive',
  invoices: '++id, type, customerId, date, total, discount, netTotal, status, items, signature, notes',
  receipts: '++id, customerId, amount, date, repSignature, notes, invoiceId',
  ledger: '++id, customerId, date, type, refId, debit, credit, balanceAfter, note',
  settings: 'key',
});

export const INVOICE_TYPES = {
  SALE: 'sale',
  RETURN: 'return',
};

export const PAYMENT_TERMS = {
  CASH: 'cash', // نقد فوري — لا يُسجَّل كمديونية على العميل
  CREDIT: 'credit', // آجل — يُسجَّل كمديونية على العميل
};

export const COLLECTION_METHODS = {
  CASH: 'cash', // استلام نقدي
  TRANSFER: 'transfer', // تحويل بنكي
};

export const LEDGER_TYPES = {
  INVOICE_SALE: 'invoice_sale',     // مديونية على العميل (دائن للشركة)
  INVOICE_RETURN: 'invoice_return', // تخفيض مديونية
  RECEIPT: 'receipt',               // تحصيل نقدي
  OPENING: 'opening',               // رصيد افتتاحي
};

/**
 * يحسب الرقم المرجعي التالي المتوقع لجدول معيّن (فواتير أو سندات)، بالاعتماد على
 * أعلى قيمة رقمية موجودة فعلياً في حقل refNumber عبر كل السجلات — لا فقط آخر id
 * تسلسلي. هذا يضمن أن تعديل رقم فاتورة يدوياً إلى قيمة أكبر (مثلاً 200) يجعل
 * الفاتورة التالية تتوقع 201 تلقائياً، بدل الرجوع للترقيم الداخلي القديم.
 * يتجاهل القيم غير الرقمية في refNumber (مثل أرقام مرجعية حرفية من نظام آخر).
 */
export async function getNextRefNumber(table) {
  const allDocs = await table.toArray();
  let maxNumeric = 0;

  for (const doc of allDocs) {
    const candidates = [doc.refNumber, doc.id];
    for (const candidate of candidates) {
      const n = Number(candidate);
      if (Number.isFinite(n) && n > maxNumeric) {
        maxNumeric = n;
        break; // نأخذ refNumber إن كان رقمياً، وإلا نقع على id كاحتياط لهذا السجل
      }
    }
  }

  return String(maxNumeric + 1);
}

export default db;
