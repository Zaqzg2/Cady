// ============================================================
// بيانات تجريبية أولية — تُحقن مرة واحدة عند أول تشغيل للتطبيق
// ============================================================
import { db } from './db';

const SEED_FLAG_KEY = 'seedCompleted';

const seedCustomers = [
  { name: 'بقالة النور', phone: '777123456', area: 'صنعاء - شارع الزبيري', balance: 0, createdAt: new Date().toISOString() },
  { name: 'سوبر ماركت الأمانة', phone: '733456789', area: 'صنعاء - حدة', balance: 0, createdAt: new Date().toISOString() },
  { name: 'مركز التموين الحديث', phone: '770987654', area: 'تعز - جمال', balance: 0, createdAt: new Date().toISOString() },
  { name: 'بقالة أبو محمد', phone: '711222333', area: 'صنعاء - الستين', balance: 0, createdAt: new Date().toISOString() },
  { name: 'محلات الرجاء التجارية', phone: '736554433', area: 'عدن - كريتر', balance: 0, createdAt: new Date().toISOString() },
  { name: 'عميل نقدي', phone: '', area: '—', balance: 0, createdAt: new Date().toISOString(), isCash: true },
];

const seedProducts = [
  { name: 'منظف أطباق كادي ليمون 1 لتر', price: 850, unit: 'حبة', category: 'منظف أطباق', isActive: true },
  { name: 'منظف أطباق كادي ليمون 500 مل', price: 480, unit: 'حبة', category: 'منظف أطباق', isActive: true },
  { name: 'صابون غسيل كادي 1 كيلو', price: 1100, unit: 'حبة', category: 'مساحيق غسيل', isActive: true },
  { name: 'مسحوق غسيل كادي أوتوماتيك 3 كيلو', price: 3200, unit: 'كرتون', category: 'مساحيق غسيل', isActive: true },
  { name: 'معطر أرضيات كادي لافندر 900 مل', price: 700, unit: 'حبة', category: 'معطرات', isActive: true },
  { name: 'مبيض كادي كلور 1 لتر', price: 550, unit: 'حبة', category: 'مبيضات', isActive: true },
  { name: 'منظف زجاج كادي 500 مل', price: 600, unit: 'حبة', category: 'منظفات زجاج', isActive: true },
  { name: 'صابون يدين كادي 1 لتر', price: 900, unit: 'حبة', category: 'عناية شخصية', isActive: true },
  { name: 'منظف عام كادي متعدد الاستخدام 1 لتر', price: 750, unit: 'حبة', category: 'منظف عام', isActive: true },
  { name: 'كرتون منظف أطباق كادي (12 حبة)', price: 9600, unit: 'كرتون', category: 'منظف أطباق', isActive: true },
];

export async function runSeedIfNeeded() {
  const flag = await db.settings.get(SEED_FLAG_KEY);
  if (flag?.value) return false;

  await db.transaction('rw', db.customers, db.products, db.settings, async () => {
    await db.customers.bulkAdd(seedCustomers);
    await db.products.bulkAdd(seedProducts);
    await db.settings.put({ key: SEED_FLAG_KEY, value: true });
  });

  return true;
}
