// ============================================================
// عمليات دفتر الأستاذ (كشف الحساب) — تحديث رصيد العميل بشكل ذري
// ============================================================
import { db, LEDGER_TYPES } from './db';

/**
 * إضافة حركة لكشف حساب العميل وتحديث رصيده الحالي.
 * debit: زيادة في مديونية العميل (فاتورة بيع)
 * credit: تخفيض مديونية العميل (سند قبض أو مرتجع)
 * date: تاريخ مخصص (ISO) إن أراد المستخدم تسجيل العملية بتاريخ غير الآن — افتراضياً تاريخ الآن.
 */
export async function addLedgerEntry({ customerId, type, refId, debit = 0, credit = 0, note = '', date = null }) {
  return db.transaction('rw', db.customers, db.ledger, async () => {
    const customer = await db.customers.get(customerId);
    if (!customer) throw new Error('العميل غير موجود');

    const currentBalance = customer.balance || 0;
    const balanceAfter = currentBalance + debit - credit;

    await db.ledger.add({
      customerId,
      date: date || new Date().toISOString(),
      type,
      refId,
      debit,
      credit,
      balanceAfter,
      note,
    });

    await db.customers.update(customerId, { balance: balanceAfter });

    return balanceAfter;
  });
}

/**
 * حذف حركة كشف حساب مرتبطة بمرجع معيّن (فاتورة/سند) وعكس تأثيرها على الرصيد.
 * يُستخدم عند حذف أو تعديل فاتورة/سند.
 * إن لم يُمرَّر type، يُحذف أي قيد مرتبط بهذا refId بغض النظر عن نوعه
 * (مفيد للفواتير التي قد تكون بيع أو مرتجع).
 */
export async function reverseLedgerEntriesByRef(refId, type = null) {
  return db.transaction('rw', db.customers, db.ledger, async () => {
    const entries = type
      ? await db.ledger.where({ refId, type }).toArray()
      : await db.ledger.where({ refId }).toArray();

    for (const entry of entries) {
      const customer = await db.customers.get(entry.customerId);
      if (customer) {
        // عكس الأثر: نطرح ما أضيف من مديونية ونعيد ما خُصم
        const reversedBalance = (customer.balance || 0) - entry.debit + entry.credit;
        await db.customers.update(entry.customerId, { balance: reversedBalance });
      }
      await db.ledger.delete(entry.id);
    }
  });
}

export async function getCustomerStatement(customerId) {
  const entries = await db.ledger.where('customerId').equals(customerId).sortBy('date');
  return entries;
}
