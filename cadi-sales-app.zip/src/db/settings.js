// ============================================================
// إعدادات التطبيق — تخطيط الفاتورة، الطابعة، المظهر
// ============================================================
import { db } from './db';

export const AVAILABLE_FONTS = [
  { value: 'Tajawal', label: 'Tajawal (افتراضي — أوضح في الشمس)' },
  { value: 'Almarai', label: 'Almarai' },
  { value: 'IBM Plex Sans Arabic', label: 'IBM Plex Sans Arabic' },
  { value: 'Cairo', label: 'Cairo' },
];

export const DEFAULT_SETTINGS = {
  theme: 'light', // 'light' | 'dark' | 'system'
  fontFamily: 'Tajawal', // أحد قيم AVAILABLE_FONTS — Tajawal أقرب لخطوط الفواتير التجارية التقليدية

  company: {
    name: 'كادي للمنظفات',
    phone: '777000111',
    address: 'صنعاء - اليمن',
    repName: '',
    footerNote: 'شكراً لتعاملكم معنا',
  },

  invoiceLayout: {
    showLogo: true,
    showCustomerPhone: true,
    showCustomerArea: true,
    showDate: true,
    showInvoiceNumber: true,
    columns: ['name', 'qty', 'price', 'total'], // ترتيب أعمدة جدول المنتجات
    fontSize: 'normal', // 'small' | 'normal' | 'large'
    paperWidth: 80, // مم
    rowDensity: 'normal', // 'compact' | 'normal' | 'spacious'
  },

  printer: {
    connected: false,
    deviceName: '',
    deviceId: '',
    printWidthPx: 576, // عرض منطقة الطباعة الفعلي بالنقطة — 576 للطابعات الحديثة (الأشيع)، 384 للأقدم/الأضيق
  },

  currency: 'ر.ي',
};

const SETTINGS_KEY = 'appSettings';

export async function getSettings() {
  const row = await db.settings.get(SETTINGS_KEY);
  if (!row) {
    await db.settings.put({ key: SETTINGS_KEY, value: DEFAULT_SETTINGS });
    return DEFAULT_SETTINGS;
  }
  // دمج مع الافتراضي لضمان وجود كل الحقول حتى عند تحديث التطبيق
  return deepMerge(DEFAULT_SETTINGS, row.value);
}

export async function updateSettings(partial) {
  const current = await getSettings();
  const updated = deepMerge(current, partial);
  await db.settings.put({ key: SETTINGS_KEY, value: updated });
  return updated;
}

function deepMerge(base, override) {
  const result = { ...base };
  for (const key in override) {
    if (
      typeof override[key] === 'object' &&
      override[key] !== null &&
      !Array.isArray(override[key]) &&
      typeof base[key] === 'object'
    ) {
      result[key] = deepMerge(base[key], override[key]);
    } else {
      result[key] = override[key];
    }
  }
  return result;
}
