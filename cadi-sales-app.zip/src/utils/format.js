// ============================================================
// دوال مساعدة عامة
// ملاحظة: نستخدم 'en-US'/'en-GB' عمداً (لا 'ar-YE') لضمان عرض الأرقام
// بصيغة لاتينية (123) في كل التطبيق، مطابقةً للمعيار التجاري المتبع
// في فواتير السوق اليمني (انظر نموذج المرجع المرفق).
// ============================================================

export function formatCurrency(amount, currency = 'ر.ي') {
  const n = Number(amount || 0);
  const formatted = n.toLocaleString('en-US', { maximumFractionDigits: 0 });
  return `${formatted} ${currency}`;
}

export function formatNumber(n) {
  return Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
}

export function formatDate(isoString) {
  const d = new Date(isoString);
  return d.toLocaleDateString('ar-YE-u-nu-latn', { year: 'numeric', month: 'long', day: 'numeric' });
}

export function formatDateTime(isoString) {
  const d = new Date(isoString);
  const datePart = d.toLocaleDateString('en-GB', { year: 'numeric', month: '2-digit', day: '2-digit' });
  const timePart = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  return `${datePart} ${timePart}`;
}

export function formatDateShort(isoString) {
  const d = new Date(isoString);
  return d.toLocaleDateString('en-GB', { year: '2-digit', month: '2-digit', day: '2-digit' });
}

export function invoiceNumber(id, type) {
  const prefix = type === 'return' ? 'مرتجع' : 'فاتورة';
  return `${prefix} #${String(id).padStart(5, '0')}`;
}

export function receiptNumber(id) {
  return `سند #${String(id).padStart(5, '0')}`;
}

export function isLikelyValidYemeniPhone(phone) {
  if (!phone || !phone.trim()) return true; // حقل اختياري، لا تنبيه إن كان فارغاً
  const digits = phone.replace(/[\s-]/g, '');
  return /^7\d{8}$/.test(digits);
}

export function classNames(...args) {
  return args.filter(Boolean).join(' ');
}
