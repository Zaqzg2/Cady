import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import TopHeader from '../components/TopHeader';
import BigCard from '../components/BigCard';
import {
  CashIcon, ReturnInvoiceIcon, SaleInvoiceIcon, ReceiptIcon, DownloadIcon, CloseIcon,
  ChevronIcon,
} from '../components/Icons';
import { db } from '../db/db';
import { formatCurrency, formatDateTime } from '../utils/format';
import { useInstallPrompt } from '../hooks/useInstallPrompt';

const OP_META = {
  invoice_sale: { label: 'فاتورة بيع', icon: <SaleInvoiceIcon />, tone: 'sale' },
  invoice_return: { label: 'مرتجع', icon: <ReturnInvoiceIcon />, tone: 'return' },
  receipt: { label: 'سند قبض', icon: <ReceiptIcon />, tone: 'receipt' },
};

export default function Home() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({ todaySales: 0, todayReceipts: 0, invoiceCount: 0 });
  const [recentOps, setRecentOps] = useState([]);
  const { canInstall, promptInstall } = useInstallPrompt();
  const [dismissedInstall, setDismissedInstall] = useState(false);

  useEffect(() => {
    loadStats();
    loadRecentOperations();
  }, []);

  async function loadRecentOperations() {
    const [invoices, receipts, customers] = await Promise.all([
      db.invoices.orderBy('date').reverse().limit(10).toArray(),
      db.receipts.orderBy('date').reverse().limit(10).toArray(),
      db.customers.toArray(),
    ]);
    const customerMap = new Map(customers.map((c) => [c.id, c.name]));

    const merged = [
      ...invoices.map((i) => ({
        kind: i.type === 'return' ? 'invoice_return' : 'invoice_sale',
        id: i.id,
        date: i.date,
        amount: i.netTotal,
        customerName: i.cashCustomerName || customerMap.get(i.customerId) || '—',
      })),
      ...receipts.map((r) => ({
        kind: 'receipt',
        id: r.id,
        date: r.date,
        amount: r.amount,
        customerName: customerMap.get(r.customerId) || '—',
      })),
    ];

    merged.sort((a, b) => new Date(b.date) - new Date(a.date));
    setRecentOps(merged.slice(0, 5));
  }

  async function loadStats() {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const startISO = startOfDay.toISOString();

    const invoices = await db.invoices.where('date').above(startISO).toArray();
    const receipts = await db.receipts.where('date').above(startISO).toArray();

    const todaySales = invoices
      .filter((i) => i.type === 'sale')
      .reduce((sum, i) => sum + (i.netTotal || 0), 0);
    const todayReceipts = receipts.reduce((sum, r) => sum + (r.amount || 0), 0);

    setStats({ todaySales, todayReceipts, invoiceCount: invoices.length });
  }

  return (
    <div className="page-with-nav">
      <TopHeader title="كادي للمنظفات" />

      {canInstall && !dismissedInstall ? (
        <div className="install-banner">
          <DownloadIcon />
          <div className="install-banner-text">
            <span className="install-banner-title">ثبّت التطبيق على هاتفك</span>
            <span className="install-banner-sub">وصول أسرع ويعمل دون إنترنت</span>
          </div>
          <button className="install-banner-action" onClick={promptInstall}>تثبيت</button>
          <button className="install-banner-close" onClick={() => setDismissedInstall(true)} aria-label="إغلاق">
            <CloseIcon />
          </button>
        </div>
      ) : null}

      <div className="home-content">
        <div className="stats-strip">
          <div className="stat-pill">
            <span className="stat-pill-label">مبيعات اليوم</span>
            <span className="stat-pill-value">{formatCurrency(stats.todaySales)}</span>
          </div>
          <div className="stat-pill">
            <span className="stat-pill-label">تحصيلات اليوم</span>
            <span className="stat-pill-value">{formatCurrency(stats.todayReceipts)}</span>
          </div>
        </div>

        <h2 className="section-title">عملية جديدة</h2>

        <div className="cards-grid">
          <BigCard
            icon={<CashIcon />}
            label="عميل نقدي"
            sublabel="بيع فوري بدون حساب"
            tone="primary"
            onClick={() => navigate('/invoice/new?mode=cash')}
          />
          <BigCard
            icon={<ReturnInvoiceIcon />}
            label="فاتورة مرتجع"
            sublabel="استرجاع بضاعة"
            tone="amber"
            onClick={() => navigate('/invoice/new?type=return')}
          />
          <BigCard
            icon={<SaleInvoiceIcon />}
            label="فاتورة بيع"
            sublabel="بيع لعميل بالحساب"
            tone="maroon"
            onClick={() => navigate('/invoice/new?type=sale')}
          />
          <BigCard
            icon={<ReceiptIcon />}
            label="سند قبض"
            sublabel="تحصيل من عميل"
            tone="red"
            onClick={() => navigate('/receipt/new')}
          />
        </div>

        {recentOps.length > 0 ? (
          <>
            <h2 className="section-title">آخر العمليات</h2>
            <ul className="recent-ops-list">
              {recentOps.map((op) => {
                const meta = OP_META[op.kind];
                const printPath = op.kind === 'receipt' ? `/receipt/${op.id}/print` : `/invoice/${op.id}/print`;
                return (
                  <li key={`${op.kind}-${op.id}`}>
                    <button className="recent-op-row" onClick={() => navigate(printPath)}>
                      <span className={`recent-op-icon ${meta.tone}`}>{meta.icon}</span>
                      <span className="recent-op-info">
                        <span className="recent-op-title">{meta.label} · {op.customerName}</span>
                        <span className="recent-op-date">{formatDateTime(op.date)}</span>
                      </span>
                      <span className={`recent-op-amount ${meta.tone}`}>{formatCurrency(op.amount)}</span>
                      <ChevronIcon dir="end" />
                    </button>
                  </li>
                );
              })}
            </ul>
          </>
        ) : null}
      </div>

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 16px);
        }
        .home-content {
          padding: 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .install-banner {
          display: flex;
          align-items: center;
          gap: 10px;
          background: var(--color-primary);
          color: white;
          padding: 10px 12px;
          margin: 10px 16px 0;
          border-radius: var(--radius-md);
          max-width: 560px;
          margin-inline: auto;
        }
        .install-banner svg {
          width: 22px; height: 22px;
          flex-shrink: 0;
        }
        .install-banner-text {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 1px;
          min-width: 0;
        }
        .install-banner-title {
          font-size: 12.5px;
          font-weight: 700;
        }
        .install-banner-sub {
          font-size: 10.5px;
          opacity: 0.85;
        }
        .install-banner-action {
          background: white;
          color: var(--color-primary);
          border: none;
          border-radius: 999px;
          padding: 7px 16px;
          font-size: 12px;
          font-weight: 800;
          cursor: pointer;
          flex-shrink: 0;
        }
        .install-banner-close {
          background: transparent;
          border: none;
          color: white;
          opacity: 0.8;
          width: 26px; height: 26px;
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
          cursor: pointer;
        }
        .install-banner-close svg { width: 14px; height: 14px; }
        .stats-strip {
          display: flex;
          gap: 10px;
          margin-bottom: 22px;
        }
        .stat-pill {
          flex: 1;
          background: var(--color-primary);
          color: white;
          border-radius: var(--radius-md);
          padding: 14px 16px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .stat-pill:last-child {
          background: var(--color-primary-dark);
        }
        .stat-pill-label {
          font-size: 12px;
          opacity: 0.85;
          font-weight: 500;
        }
        .stat-pill-value {
          font-size: 17px;
          font-weight: 800;
        }
        .section-title {
          font-size: 14px;
          font-weight: 700;
          color: var(--color-ink-soft);
          margin: 0 0 12px 4px;
        }
        .cards-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }
        .recent-ops-list {
          list-style: none;
          margin: 22px 0 0;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .recent-op-row {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 10px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 10px 12px;
          cursor: pointer;
        }
        .recent-op-row:active { background: var(--color-bg-sunken); }
        .recent-op-row svg:last-child { width: 16px; height: 16px; color: var(--color-ink-faint); flex-shrink: 0; }
        .recent-op-icon {
          width: 36px; height: 36px;
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
        }
        .recent-op-icon svg { width: 17px; height: 17px; }
        .recent-op-icon.sale { background: rgba(200,30,30,0.08); color: var(--color-primary); }
        .recent-op-icon.return { background: rgba(214,160,21,0.14); color: var(--color-amber); }
        .recent-op-icon.receipt { background: rgba(46,125,91,0.12); color: var(--color-success); }
        .recent-op-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 2px;
          text-align: start;
          min-width: 0;
        }
        .recent-op-title {
          font-size: 12.5px;
          font-weight: 700;
          color: var(--color-ink);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .recent-op-date {
          font-size: 10.5px;
          color: var(--color-ink-faint);
        }
        .recent-op-amount {
          font-weight: 800;
          font-size: 12.5px;
          flex-shrink: 0;
        }
        .recent-op-amount.sale { color: var(--color-primary); }
        .recent-op-amount.return { color: var(--color-amber); }
        .recent-op-amount.receipt { color: var(--color-success); }
      `}</style>
    </div>
  );
}
