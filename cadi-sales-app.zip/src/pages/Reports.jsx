import React, { useEffect, useMemo, useState } from 'react';
import TopHeader from '../components/TopHeader';
import { db } from '../db/db';
import { formatCurrency } from '../utils/format';
import { SaleInvoiceIcon, ReturnInvoiceIcon, ReceiptIcon, CustomerIcon } from '../components/Icons';

const RANGES = [
  { value: 'today', label: 'اليوم' },
  { value: 'week', label: '٧ أيام' },
  { value: 'month', label: '٣٠ يوماً' },
  { value: 'all', label: 'الكل' },
];

export default function Reports() {
  const [range, setRange] = useState('today');
  const [invoices, setInvoices] = useState([]);
  const [receipts, setReceipts] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      const [inv, rec, cust] = await Promise.all([
        db.invoices.toArray(),
        db.receipts.toArray(),
        db.customers.toArray(),
      ]);
      setInvoices(inv);
      setReceipts(rec);
      setCustomers(cust);
      setLoaded(true);
    })();
  }, []);

  const cutoffDate = useMemo(() => {
    const d = new Date();
    if (range === 'today') { d.setHours(0, 0, 0, 0); return d; }
    if (range === 'week') { d.setDate(d.getDate() - 7); return d; }
    if (range === 'month') { d.setDate(d.getDate() - 30); return d; }
    return null; // 'all'
  }, [range]);

  const filteredInvoices = useMemo(() => {
    if (!cutoffDate) return invoices;
    return invoices.filter((i) => new Date(i.date) >= cutoffDate);
  }, [invoices, cutoffDate]);

  const filteredReceipts = useMemo(() => {
    if (!cutoffDate) return receipts;
    return receipts.filter((r) => new Date(r.date) >= cutoffDate);
  }, [receipts, cutoffDate]);

  const sales = filteredInvoices.filter((i) => i.type === 'sale');
  const returns = filteredInvoices.filter((i) => i.type === 'return');
  const totalSales = sales.reduce((s, i) => s + (i.netTotal || 0), 0);
  const totalReturns = returns.reduce((s, i) => s + (i.netTotal || 0), 0);
  const totalReceipts = filteredReceipts.reduce((s, r) => s + (r.amount || 0), 0);
  const netRevenue = totalSales - totalReturns;

  const topDebtors = useMemo(() => {
    return [...customers]
      .filter((c) => (c.balance || 0) > 0)
      .sort((a, b) => b.balance - a.balance)
      .slice(0, 5);
  }, [customers]);

  if (!loaded) {
    return (
      <div className="page-with-nav">
        <TopHeader title="التقارير" showBack />
      </div>
    );
  }

  return (
    <div className="page-with-nav">
      <TopHeader title="التقارير" showBack rightSlot={<span />} />

      <div className="reports-content">
        <div className="range-tabs">
          {RANGES.map((r) => (
            <button
              key={r.value}
              className={range === r.value ? 'active' : ''}
              onClick={() => setRange(r.value)}
            >
              {r.label}
            </button>
          ))}
        </div>

        <div className="summary-grid">
          <div className="summary-card sale">
            <SaleInvoiceIcon />
            <span className="summary-value">{formatCurrency(totalSales)}</span>
            <span className="summary-label">مبيعات ({sales.length} فاتورة)</span>
          </div>
          <div className="summary-card return">
            <ReturnInvoiceIcon />
            <span className="summary-value">{formatCurrency(totalReturns)}</span>
            <span className="summary-label">مرتجعات ({returns.length} فاتورة)</span>
          </div>
          <div className="summary-card receipt">
            <ReceiptIcon />
            <span className="summary-value">{formatCurrency(totalReceipts)}</span>
            <span className="summary-label">تحصيلات ({filteredReceipts.length} سند)</span>
          </div>
          <div className="summary-card net">
            <span className="summary-value">{formatCurrency(netRevenue)}</span>
            <span className="summary-label">صافي المبيعات</span>
          </div>
        </div>

        <h2 className="section-title"><CustomerIcon /> أعلى 5 عملاء مديونية</h2>
        {topDebtors.length === 0 ? (
          <div className="empty-state">لا يوجد عملاء عليهم مديونية حالياً 🎉</div>
        ) : (
          <ul className="debtors-list">
            {topDebtors.map((c) => (
              <li key={c.id} className="debtor-row">
                <span className="debtor-name">{c.name}</span>
                <span className="debtor-balance">{formatCurrency(c.balance)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 16px);
        }
        .reports-content {
          padding: 14px 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .range-tabs {
          display: flex;
          gap: 6px;
          background: var(--color-bg-sunken);
          border-radius: var(--radius-sm);
          padding: 4px;
          margin-bottom: 16px;
        }
        .range-tabs button {
          flex: 1;
          height: 38px;
          border: none;
          background: transparent;
          border-radius: 7px;
          font-weight: 700;
          font-size: 12.5px;
          color: var(--color-ink-soft);
          cursor: pointer;
        }
        .range-tabs button.active {
          background: var(--color-primary);
          color: white;
        }
        .summary-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          margin-bottom: 24px;
        }
        .summary-card {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 16px 12px;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .summary-card svg {
          width: 20px; height: 20px;
          color: var(--color-primary);
        }
        .summary-card.return svg { color: var(--color-amber); }
        .summary-value {
          font-size: 16px;
          font-weight: 800;
          color: var(--color-ink);
        }
        .summary-label {
          font-size: 11px;
          color: var(--color-ink-faint);
        }
        .summary-card.net {
          background: var(--color-primary);
        }
        .summary-card.net .summary-value,
        .summary-card.net .summary-label {
          color: white;
        }
        .section-title {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 14px;
          font-weight: 700;
          color: var(--color-ink-soft);
          margin: 0 0 12px 4px;
        }
        .section-title svg { width: 17px; height: 17px; }
        .empty-state {
          text-align: center;
          padding: 30px 0;
          color: var(--color-ink-faint);
          font-size: 13.5px;
        }
        .debtors-list {
          list-style: none;
          margin: 0;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .debtor-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-sm);
          padding: 12px 14px;
        }
        .debtor-name {
          font-weight: 700;
          font-size: 13.5px;
          color: var(--color-ink);
        }
        .debtor-balance {
          font-weight: 800;
          font-size: 13.5px;
          color: var(--color-danger);
        }
      `}</style>
    </div>
  );
}
