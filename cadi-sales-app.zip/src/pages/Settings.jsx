import React, { useEffect, useRef, useState } from 'react';
import TopHeader from '../components/TopHeader';
import SettingsSection from '../components/SettingsSection';
import BackupSection from '../components/BackupSection';
import Toggle from '../components/Toggle';
import { Field, Input, Button } from '../components/ui';
import {
  EditIcon, LedgerIcon, BoxOpenIcon, MoonIcon, SunIcon, BluetoothIcon, CheckIcon, SaveIcon,
} from '../components/Icons';
import { getSettings, updateSettings, AVAILABLE_FONTS } from '../db/settings';
import { useTheme } from '../hooks/useTheme';
import { useFontFamily } from '../hooks/useFontFamily';
import { useToast } from '../components/Toast';
import { bluetoothPrinter } from '../services/bluetoothPrinter';
import { buildImagePrintBytes } from '../services/receiptImagePrint';
import logoMark from '../assets/logo-full.png';

const FONT_SIZE_OPTIONS = [
  { value: 'small', label: 'صغير' },
  { value: 'normal', label: 'عادي' },
  { value: 'large', label: 'كبير' },
];
const DENSITY_OPTIONS = [
  { value: 'compact', label: 'مضغوط' },
  { value: 'normal', label: 'عادي' },
  { value: 'spacious', label: 'مريح' },
];

export default function Settings() {
  const showToast = useToast();
  const { theme, setTheme } = useTheme();
  const { fontFamily, setFontFamily } = useFontFamily();
  const [settings, setSettings] = useState(null);
  const [printerBusy, setPrinterBusy] = useState(false);
  const [testPrinting, setTestPrinting] = useState(false);
  const testPrintRef = useRef(null);

  useEffect(() => {
    getSettings().then(setSettings);
  }, []);

  if (!settings) {
    return (
      <div className="page-with-nav">
        <TopHeader title="الإعدادات" />
      </div>
    );
  }

  async function persist(partial) {
    const updated = await updateSettings(partial);
    setSettings(updated);
  }

  async function handleConnectPrinter() {
    if (!bluetoothPrinter.isSupported()) {
      showToast('متصفحك لا يدعم الاتصال بالبلوتوث — جرّب Chrome على أندرويد', 'error');
      return;
    }
    setPrinterBusy(true);
    try {
      const info = await bluetoothPrinter.connect();
      await persist({ printer: { connected: true, deviceName: info.name, deviceId: info.id } });
      showToast(`تم الاتصال بـ ${info.name}`);
    } catch (e) {
      if (e?.name !== 'NotFoundError') {
        showToast('تعذّر الاتصال بالطابعة', 'error');
      }
    } finally {
      setPrinterBusy(false);
    }
  }

  async function handleDisconnectPrinter() {
    await bluetoothPrinter.disconnect();
    await persist({ printer: { connected: false, deviceName: '', deviceId: '' } });
    showToast('تم قطع الاتصال بالطابعة');
  }

  async function handleTestPrint() {
    if (!bluetoothPrinter.isSupported()) {
      showToast('متصفحك لا يدعم الاتصال بالبلوتوث — جرّب Chrome على أندرويد', 'error');
      return;
    }
    setTestPrinting(true);
    try {
      if (!bluetoothPrinter.isConnected()) {
        await bluetoothPrinter.connect();
      }
      const bytes = await buildImagePrintBytes(testPrintRef.current, settings.printer.printWidthPx);
      await bluetoothPrinter.write(bytes);
      showToast('تم إرسال الاختبار — تحقق من وضوح النص على الورق');
    } catch (e) {
      if (e?.name !== 'NotFoundError') {
        showToast('تعذّر الطباعة — تأكد من الاتصال بالطابعة', 'error');
      }
    } finally {
      setTestPrinting(false);
    }
  }

  return (
    <div className="page-with-nav">
      <TopHeader title="الإعدادات" />

      <div className="settings-content">
        <SettingsSection icon={<EditIcon />} title="بيانات الشركة" subtitle="تظهر في ترويسة كل فاتورة وسند">
          <Field label="اسم الشركة">
            <Input
              value={settings.company.name}
              onChange={(e) => persist({ company: { name: e.target.value } })}
            />
          </Field>
          <Field label="رقم الهاتف">
            <Input
              value={settings.company.phone}
              onChange={(e) => persist({ company: { phone: e.target.value } })}
              type="tel"
              inputMode="numeric"
            />
          </Field>
          <Field label="العنوان">
            <Input
              value={settings.company.address}
              onChange={(e) => persist({ company: { address: e.target.value } })}
            />
          </Field>
          <Field label="اسم المندوب" hint="يظهر في الفاتورة والسند — اتركه فارغاً لإظهار اسم الشركة بدلاً منه">
            <Input
              value={settings.company.repName}
              onChange={(e) => persist({ company: { repName: e.target.value } })}
              placeholder="مثال: صادق عبدالواسع"
            />
          </Field>
          <Field label="ملاحظة أسفل الفاتورة">
            <Input
              value={settings.company.footerNote}
              onChange={(e) => persist({ company: { footerNote: e.target.value } })}
            />
          </Field>
        </SettingsSection>

        <SettingsSection icon={<LedgerIcon />} title="تخطيط الفاتورة" subtitle="الترويسة وبيانات العميل الظاهرة">
          <Toggle
            label="إظهار الشعار"
            checked={settings.invoiceLayout.showLogo}
            onChange={(v) => persist({ invoiceLayout: { showLogo: v } })}
          />
          <Toggle
            label="إظهار رقم الفاتورة"
            checked={settings.invoiceLayout.showInvoiceNumber}
            onChange={(v) => persist({ invoiceLayout: { showInvoiceNumber: v } })}
          />
          <Toggle
            label="إظهار التاريخ والوقت"
            checked={settings.invoiceLayout.showDate}
            onChange={(v) => persist({ invoiceLayout: { showDate: v } })}
          />
          <Toggle
            label="إظهار هاتف العميل"
            checked={settings.invoiceLayout.showCustomerPhone}
            onChange={(v) => persist({ invoiceLayout: { showCustomerPhone: v } })}
          />
          <Toggle
            label="إظهار منطقة العميل"
            checked={settings.invoiceLayout.showCustomerArea}
            onChange={(v) => persist({ invoiceLayout: { showCustomerArea: v } })}
          />
        </SettingsSection>

        <SettingsSection icon={<BoxOpenIcon />} title="جدول المنتجات" subtitle="حجم الخط، تباعد الصفوف، عرض الورق">
          <span className="sub-label">حجم الخط في الإيصال</span>
          <div className="option-row">
            {FONT_SIZE_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                className={`option-chip ${settings.invoiceLayout.fontSize === opt.value ? 'active' : ''}`}
                onClick={() => persist({ invoiceLayout: { fontSize: opt.value } })}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <span className="sub-label">تباعد صفوف الجدول</span>
          <div className="option-row">
            {DENSITY_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                className={`option-chip ${settings.invoiceLayout.rowDensity === opt.value ? 'active' : ''}`}
                onClick={() => persist({ invoiceLayout: { rowDensity: opt.value } })}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <span className="sub-label">عرض الورق</span>
          <div className="option-row">
            {[58, 80].map((w) => (
              <button
                key={w}
                className={`option-chip ${settings.invoiceLayout.paperWidth === w ? 'active' : ''}`}
                onClick={() => persist({ invoiceLayout: { paperWidth: w } })}
              >
                {w} مم
              </button>
            ))}
          </div>
        </SettingsSection>

        <SettingsSection icon={theme === 'dark' ? <MoonIcon /> : <SunIcon />} title="المظهر" subtitle="الوضع الليلي والنهاري ونوع الخط">
          <div className="option-row">
            <button className={`option-chip ${theme === 'light' ? 'active' : ''}`} onClick={() => setTheme('light')}>
              <SunIcon /> نهاري
            </button>
            <button className={`option-chip ${theme === 'dark' ? 'active' : ''}`} onClick={() => setTheme('dark')}>
              <MoonIcon /> ليلي
            </button>
            <button className={`option-chip ${theme === 'system' ? 'active' : ''}`} onClick={() => setTheme('system')}>
              تلقائي
            </button>
          </div>

          <span className="sub-label">نوع الخط</span>
          <div className="font-options">
            {AVAILABLE_FONTS.map((f) => (
              <button
                key={f.value}
                className={`font-option-chip ${fontFamily === f.value ? 'active' : ''}`}
                style={{ fontFamily: `'${f.value}', sans-serif` }}
                onClick={() => setFontFamily(f.value)}
              >
                <span className="font-preview">كادي للمنظفات — Aa</span>
                <span className="font-name">{f.label}</span>
                {fontFamily === f.value ? <CheckIcon /> : null}
              </button>
            ))}
          </div>
          <p className="printer-hint">
            بعض الخطوط تحتاج اتصالاً بالإنترنت لمرة واحدة فقط لتحميلها أول مرة، وبعدها تعمل دون إنترنت تلقائياً.
          </p>
        </SettingsSection>

        <SettingsSection icon={<BluetoothIcon />} title="طابعة البلوتوث" subtitle="ربط طابعة 80مم حرارية" defaultOpen>
          {settings.printer.connected ? (
            <div className="printer-status connected">
              <span><CheckIcon /> متصل بـ: {settings.printer.deviceName || 'طابعة'}</span>
              <Button variant="danger" size="sm" onClick={handleDisconnectPrinter}>قطع الاتصال</Button>
            </div>
          ) : (
            <div className="printer-status">
              <span className="muted">لا توجد طابعة متصلة حالياً</span>
              <Button onClick={handleConnectPrinter} disabled={printerBusy}>
                {printerBusy ? 'جاري البحث...' : 'البحث عن طابعة وربطها'}
              </Button>
            </div>
          )}
          <p className="printer-hint">
            تأكد من تفعيل البلوتوث على هاتفك وأن الطابعة في وضع الاستعداد (مضيئة) قبل الربط. يدعم التطبيق طابعات ESC/POS الحرارية القياسية بعرض 80مم.
          </p>

          <span className="sub-label">عرض الطباعة</span>
          <p className="printer-hint">
            إذا ظهر النص صغيراً جداً مع هامش فارغ كبير على الجوانب، جرّب 576 نقطة (الأشيع للطابعات الحديثة).
            إذا ظهرت الصورة مقصوصة عن حدود الورق، جرّب 384 نقطة.
          </p>
          <div className="option-row">
            <button
              className={`option-chip ${(settings.printer.printWidthPx || 576) === 576 ? 'active' : ''}`}
              onClick={() => persist({ printer: { printWidthPx: 576 } })}
            >
              576 نقطة (الأشيع)
            </button>
            <button
              className={`option-chip ${settings.printer.printWidthPx === 384 ? 'active' : ''}`}
              onClick={() => persist({ printer: { printWidthPx: 384 } })}
            >
              384 نقطة
            </button>
          </div>

          <span className="sub-label">تجربة الطباعة</span>
          <p className="printer-hint">
            الإيصال يُطبع بالكامل كصورة (نص عربي متصل وصحيح بصرياً) لتجاوز قيود الطابعات
            التي لا تدعم ربط الحروف العربية. اضغط الزر أدناه لتجربة طباعة سريعة والتحقق من وضوح النتيجة.
          </p>
          <Button
            variant="secondary"
            fullWidth
            onClick={handleTestPrint}
            disabled={testPrinting}
          >
            {testPrinting ? 'جاري الطباعة...' : 'طباعة اختبار'}
          </Button>
        </SettingsSection>

        <SettingsSection icon={<SaveIcon />} title="النسخ الاحتياطي" subtitle="حماية بياناتك من الضياع">
          <BackupSection />
        </SettingsSection>
      </div>

      {/* عنصر اختبار الطباعة — مخفي خارج حدود الشاشة المرئية لكنه قابل للتصوير بـhtml2canvas */}
      <div className="test-print-offscreen">
        <div ref={testPrintRef} className="test-print-content">
          <img src={logoMark} alt="كادي" className="test-print-logo" />
          <div className="test-print-divider" />
          <div className="test-print-title">اختبار الطباعة العربية</div>
          <div className="test-print-line">هذا نص عربي متصل لتجربة الوضوح</div>
          <div className="test-print-line">الأرقام: 1234567890</div>
          <div className="test-print-line">السعر: 1,500 ر.ي</div>
          <div className="test-print-divider" />
          <div className="test-print-footer">إذا ظهر هذا النص بوضوح ومتصلاً، فالطباعة تعمل بشكل صحيح</div>
        </div>
      </div>

      <style>{`
        .test-print-offscreen {
          position: fixed;
          top: 0;
          left: -9999px;
          width: 384px;
        }
        .test-print-content {
          background: #ffffff;
          color: #161010;
          padding: 14px 10px;
          font-family: var(--font-body), 'Cairo', sans-serif;
          direction: rtl;
          font-size: 14px;
        }
        .test-print-logo {
          display: block;
          height: 64px;
          margin: 0 auto 8px;
          object-fit: contain;
        }
        .test-print-divider {
          border-top: 1.5px dashed #888;
          margin: 8px 0;
        }
        .test-print-title {
          text-align: center;
          font-weight: 800;
          font-size: 16px;
          margin-bottom: 6px;
        }
        .test-print-line {
          text-align: center;
          padding: 3px 0;
        }
        .test-print-footer {
          text-align: center;
          font-size: 12px;
          font-weight: 600;
          line-height: 1.6;
        }
      `}</style>

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 16px);
        }
        .settings-content {
          padding: 14px 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .sub-label {
          display: block;
          font-size: 12px;
          font-weight: 700;
          color: var(--color-ink-soft);
          margin: 14px 0 8px;
        }
        .option-row {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }
        .option-chip {
          display: flex;
          align-items: center;
          gap: 5px;
          padding: 9px 16px;
          border-radius: var(--radius-sm);
          border: 1.5px solid var(--color-border);
          background: var(--color-surface-2);
          color: var(--color-ink-soft);
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
        }
        .option-chip.active {
          background: var(--color-primary);
          border-color: var(--color-primary);
          color: white;
        }
        .option-chip svg { width: 15px; height: 15px; }
        .font-options {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .font-option-chip {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 14px;
          border-radius: var(--radius-sm);
          border: 1.5px solid var(--color-border);
          background: var(--color-surface-2);
          cursor: pointer;
          text-align: start;
        }
        .font-option-chip.active {
          border-color: var(--color-primary);
          background: rgba(200,30,30,0.05);
        }
        .font-preview {
          flex: 1;
          font-size: 15px;
          color: var(--color-ink);
          font-weight: 600;
        }
        .font-name {
          font-size: 11px;
          color: var(--color-ink-faint);
          font-weight: 600;
          flex-shrink: 0;
        }
        .font-option-chip.active .font-name {
          color: var(--color-primary);
        }
        .font-option-chip svg {
          width: 16px; height: 16px;
          color: var(--color-primary);
          flex-shrink: 0;
        }
        .printer-status {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          flex-wrap: wrap;
        }
        .printer-status.connected span {
          display: flex;
          align-items: center;
          gap: 6px;
          color: var(--color-success);
          font-weight: 700;
          font-size: 13px;
        }
        .printer-status.connected svg { width: 16px; height: 16px; }
        .printer-status .muted {
          color: var(--color-ink-faint);
          font-size: 13px;
        }
        .printer-hint {
          font-size: 11.5px;
          color: var(--color-ink-faint);
          line-height: 1.7;
          margin: 14px 0 0;
        }
      `}</style>
    </div>
  );
}
