import React, { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import TopHeader from '../components/TopHeader';
import CustomerStatementTemplate from '../components/CustomerStatementTemplate';
import { Button } from '../components/ui';
import { PrintIcon, ShareIcon, DownloadIcon } from '../components/Icons';
import { db } from '../db/db';
import { getSettings } from '../db/settings';
import { useToast } from '../components/Toast';
import { useBluetoothPrint } from '../hooks/useBluetoothPrint';
import { bluetoothPrinter } from '../services/bluetoothPrinter';
import { downloadElementAsPdf, elementToReceiptPdfFile } from '../services/pdfBuilder';
import { buildImagePrintBytes } from '../services/receiptImagePrint';

export default function CustomerStatementPrint() {
  const { id } = useParams();
  const customerId = Number(id);
  const navigate = useNavigate();
  const showToast = useToast();
  const { printing, printBytes } = useBluetoothPrint();
  const statementRef = useRef(null);

  const [customer, setCustomer] = useState(null);
  const [ledgerEntries, setLedgerEntries] = useState(null);
  const [settings, setSettings] = useState(null);
  const [pdfBusy, setPdfBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const [c, entries, s] = await Promise.all([
        db.customers.get(customerId),
        db.ledger.where('customerId').equals(customerId).sortBy('date'),
        getSettings(),
      ]);

      // نجلب الرقم المرجعي الفعلي (refNumber القابل للتعديل اليدوي) لكل حركة من جدولها الأصلي،
      // بدل الاعتماد على refId الداخلي الخام الذي قد يختلف عن الرقم المعروض فعلياً على الفاتورة/السند.
      const invoiceIds = entries.filter((e) => e.type === 'invoice_sale' || e.type === 'invoice_return').map((e) => e.refId);
      const receiptIds = entries.filter((e) => e.type === 'receipt').map((e) => e.refId);
      const [invoiceDocs, receiptDocs] = await Promise.all([
        invoiceIds.length ? db.invoices.where('id').anyOf(invoiceIds).toArray() : [],
        receiptIds.length ? db.receipts.where('id').anyOf(receiptIds).toArray() : [],
      ]);
      const invoiceRefMap = new Map(invoiceDocs.map((d) => [d.id, d.refNumber || d.id]));
      const receiptRefMap = new Map(receiptDocs.map((d) => [d.id, d.refNumber || d.id]));

      const enrichedEntries = entries.map((e) => ({
        ...e,
        documentNumber: e.type === 'receipt'
          ? (receiptRefMap.get(e.refId) ?? e.refId)
          : (invoiceRefMap.get(e.refId) ?? e.refId),
      }));

      setCustomer(c);
      setLedgerEntries(enrichedEntries);
      setSettings(s);
    })();
  }, [customerId]);

  async function handlePrint() {
    if (!bluetoothPrinter.isSupported()) {
      showToast('متصفحك لا يدعم الاتصال بالبلوتوث — جرّب Chrome على أندرويد', 'error');
      return;
    }
    showToast(bluetoothPrinter.isConnected() ? 'جاري تجهيز الإيصال...' : 'اختر طابعتك من القائمة...');
    try {
      const bytes = await buildImagePrintBytes(statementRef.current, settings.printer.printWidthPx);
      const ok = await printBytes(bytes);
      showToast(ok ? 'تمت الطباعة بنجاح' : 'تعذّر الاتصال بالطابعة', ok ? 'success' : 'error');
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء الطباعة', 'error');
    }
  }

  async function handleDownload() {
    setPdfBusy(true);
    try {
      // كشف الحساب بنفس صيغة إيصال 80مم (أو 58 حسب اختيار المستخدم في الإعدادات) — لا A4
      await downloadElementAsPdf(statementRef.current, `كشف-حساب-${customer.name}`, settings.invoiceLayout.paperWidth);
      showToast('تم تحميل كشف الحساب كملف PDF');
    } catch (e) {
      console.error(e);
      showToast('تعذّر إنشاء ملف PDF', 'error');
    } finally {
      setPdfBusy(false);
    }
  }

  async function handleShare() {
    const filename = `كشف-حساب-${customer.name}`;
    try {
      setPdfBusy(true);
      const file = await elementToReceiptPdfFile(statementRef.current, filename, settings.invoiceLayout.paperWidth);
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ title: 'كشف حساب - كادي للمنظفات', files: [file] });
        return;
      }
    } catch (e) {
      // فشل التوليد أو ألغى المستخدم — ننتقل للخيار النصي البديل
    } finally {
      setPdfBusy(false);
    }

    const text = `كشف حساب ${customer.name} — الرصيد الحالي: ${customer.balance} ر.ي`;
    if (navigator.share) {
      try { await navigator.share({ title: 'كشف حساب - كادي للمنظفات', text }); } catch (e) { /* ألغى المستخدم */ }
    } else {
      await navigator.clipboard?.writeText(text);
      showToast('تم نسخ ملخص كشف الحساب');
    }
  }

  if (!customer || !ledgerEntries || !settings) {
    return (
      <div className="page-with-nav">
        <TopHeader title="جاري التحميل..." showBack />
      </div>
    );
  }

  return (
    <div className="page-with-nav">
      <TopHeader title="كشف الحساب" showBack />

      <div className="statement-print-content">
        <div className="statement-preview-frame">
          <div ref={statementRef}>
            <CustomerStatementTemplate customer={customer} ledgerEntries={ledgerEntries} settings={settings} />
          </div>
        </div>

        <div className="print-actions">
          <Button fullWidth size="lg" icon={<PrintIcon />} onClick={handlePrint} disabled={printing}>
            {printing ? 'جاري الطباعة...' : 'طباعة 80مم'}
          </Button>
          <div className="action-row">
            <Button variant="secondary" fullWidth icon={<ShareIcon />} onClick={handleShare} disabled={pdfBusy}>مشاركة</Button>
            <Button variant="secondary" fullWidth icon={<DownloadIcon />} onClick={handleDownload} disabled={pdfBusy}>
              {pdfBusy ? 'جاري التجهيز...' : 'تحميل PDF'}
            </Button>
          </div>
          <Button variant="ghost" fullWidth onClick={() => navigate(-1)}>رجوع</Button>
        </div>
      </div>

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 16px);
        }
        .statement-print-content {
          padding: 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .statement-preview-frame {
          background: var(--color-bg-sunken);
          border-radius: var(--radius-md);
          padding: 16px 0;
          display: flex;
          justify-content: center;
          margin-bottom: 20px;
          overflow-x: auto;
          max-height: 60vh;
          overflow-y: auto;
        }
        .print-actions {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .action-row {
          display: flex;
          gap: 10px;
        }
      `}</style>
    </div>
  );
}
