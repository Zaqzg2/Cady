import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import TopHeader from '../components/TopHeader';
import CustomerPicker from '../components/CustomerPicker';
import SignaturePad from '../components/SignaturePad';
import DateTimeField from '../components/DateTimeField';
import { Button, Field, Input } from '../components/ui';
import { ChevronIcon, EditIcon } from '../components/Icons';
import { db, COLLECTION_METHODS, getNextRefNumber } from '../db/db';
import { addLedgerEntry, reverseLedgerEntriesByRef } from '../db/ledger';
import { formatCurrency, formatDateTime } from '../utils/format';
import { useToast } from '../components/Toast';

export default function ReceiptForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const showToast = useToast();
  const isEditMode = !!id;

  const presetCustomerId = searchParams.get('customerId') ? Number(searchParams.get('customerId')) : null;

  const [customer, setCustomer] = useState(null);
  const [amount, setAmount] = useState('');
  const [collectionMethod, setCollectionMethod] = useState(COLLECTION_METHODS.CASH);
  const [notes, setNotes] = useState('');
  const [existingSignature, setExistingSignature] = useState(null);
  const [receiptDate, setReceiptDate] = useState(new Date().toISOString());
  const [refNumber, setRefNumber] = useState('');
  const [editingDate, setEditingDate] = useState(false);
  const [editingRefNumber, setEditingRefNumber] = useState(false);
  const [existingReceiptId, setExistingReceiptId] = useState(null);
  const [customerPickerOpen, setCustomerPickerOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loaded, setLoaded] = useState(!isEditMode);

  const signatureRef = useRef(null);

  useEffect(() => {
    if (isEditMode || !presetCustomerId) return;
    (async () => {
      const c = await db.customers.get(presetCustomerId);
      if (c) setCustomer(c);
    })();
  }, [presetCustomerId, isEditMode]);

  // توقع رقم السند التالي (تقديري) لعرضه قابلاً للتعديل قبل الحفظ الفعلي.
  // يتابع أعلى رقم مرجعي رقمي مستخدَم فعلياً، فلو عُدِّل سند سابق يدوياً لرقم
  // أكبر، يتابع الترقيم من هذا الرقم الجديد بدل العودة للترقيم الداخلي القديم.
  useEffect(() => {
    if (isEditMode) return;
    (async () => {
      const next = await getNextRefNumber(db.receipts);
      setRefNumber(next);
    })();
  }, [isEditMode]);

  useEffect(() => {
    if (!isEditMode) return;
    (async () => {
      const receipt = await db.receipts.get(Number(id));
      if (!receipt) { setLoaded(true); return; }
      setAmount(String(receipt.amount));
      setCollectionMethod(receipt.collectionMethod || COLLECTION_METHODS.CASH);
      setNotes(receipt.notes || '');
      setExistingSignature(receipt.repSignature || null);
      setReceiptDate(receipt.date || new Date().toISOString());
      setRefNumber(receipt.refNumber || String(receipt.id));
      setExistingReceiptId(receipt.id);
      if (receipt.customerId) {
        const c = await db.customers.get(receipt.customerId);
        if (c) setCustomer(c);
      }
      setLoaded(true);
    })();
  }, [id, isEditMode]);

  async function handleSave() {
    if (!customer) {
      showToast('يرجى اختيار العميل أولاً', 'error');
      return;
    }
    const amountValue = Number(amount);
    if (!amountValue || amountValue <= 0) {
      showToast('أدخل مبلغاً صحيحاً أكبر من صفر', 'error');
      return;
    }

    setSaving(true);
    try {
      const signatureData = signatureRef.current?.getDataURL() || null;

      const receiptData = {
        customerId: customer.id,
        amount: amountValue,
        collectionMethod,
        date: receiptDate,
        repSignature: signatureData,
        notes,
      };

      if (isEditMode) {
        const receiptId = Number(id);
        receiptData.refNumber = refNumber || String(receiptId);
        await reverseLedgerEntriesByRef(receiptId, 'receipt');
        await db.receipts.update(receiptId, receiptData);
        await addLedgerEntry({
          customerId: customer.id,
          type: 'receipt',
          refId: receiptId,
          credit: amountValue,
          note: 'سند قبض',
          date: receiptDate,
        });
        showToast('تم تحديث السند بنجاح');
        navigate(-1);
      } else {
        const receiptId = await db.receipts.add(receiptData);
        await db.receipts.update(receiptId, { refNumber: refNumber || String(receiptId) });
        await addLedgerEntry({
          customerId: customer.id,
          type: 'receipt',
          refId: receiptId,
          credit: amountValue,
          note: 'سند قبض',
          date: receiptDate,
        });
        showToast('تم حفظ السند بنجاح');
        navigate(`/receipt/${receiptId}/print`, { replace: true });
      }
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء الحفظ', 'error');
    } finally {
      setSaving(false);
    }
  }

  if (!loaded) {
    return (
      <div className="page-with-nav">
        <TopHeader title="جاري التحميل..." showBack />
      </div>
    );
  }

  return (
    <div className="page-with-nav">
      <TopHeader title={isEditMode ? 'تعديل سند القبض' : 'سند قبض جديد'} showBack rightSlot={<span />} />

      <div className="receipt-form-content">
        <button className="customer-select-row" onClick={() => setCustomerPickerOpen(true)}>
          <div className="customer-select-avatar">{customer ? (customer.name.trim().charAt(0) || '؟') : '؟'}</div>
          <div className="customer-select-info">
            <span className="customer-select-label">العميل</span>
            <span className="customer-select-name">{customer ? customer.name : 'اختر العميل'}</span>
          </div>
          <ChevronIcon />
        </button>

        <div className="meta-edit-row">
          <span className="meta-edit-label">التاريخ والوقت</span>
          {editingDate ? (
            <DateTimeField value={receiptDate} onChange={setReceiptDate} />
          ) : (
            <button className="meta-edit-value" onClick={() => setEditingDate(true)}>
              {formatDateTime(receiptDate)} <EditIcon />
            </button>
          )}
        </div>

        <div className="meta-edit-row">
          <span className="meta-edit-label">رقم السند</span>
          {editingRefNumber ? (
            <Input value={refNumber} onChange={(e) => setRefNumber(e.target.value)} autoFocus />
          ) : (
            <button className="meta-edit-value" onClick={() => setEditingRefNumber(true)}>
              #{refNumber || existingReceiptId || '...'} <EditIcon />
            </button>
          )}
        </div>

        {customer && customer.balance > 0 ? (
          <div className="current-balance-hint">
            مديونية العميل الحالية: <strong>{formatCurrency(customer.balance)}</strong>
          </div>
        ) : null}

        <div className="amount-input-card">
          <span className="amount-label">المبلغ المستلم</span>
          <div className="amount-input-row">
            <input
              type="number"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              className="amount-input"
              autoFocus
            />
            <span className="amount-currency">ر.ي</span>
          </div>
          {customer && customer.balance > 0 ? (
            <button className="fill-full-balance" onClick={() => setAmount(String(customer.balance))}>
              تحصيل كامل المديونية ({formatCurrency(customer.balance)})
            </button>
          ) : null}
        </div>

        <div className="collection-method-switch">
          <button
            className={collectionMethod === COLLECTION_METHODS.CASH ? 'active' : ''}
            onClick={() => setCollectionMethod(COLLECTION_METHODS.CASH)}
          >
            💵 نقداً
          </button>
          <button
            className={collectionMethod === COLLECTION_METHODS.TRANSFER ? 'active' : ''}
            onClick={() => setCollectionMethod(COLLECTION_METHODS.TRANSFER)}
          >
            🏦 تحويل بنكي
          </button>
        </div>

        {customer && Number(amount) > 0 && Number(amount) > Math.max(customer.balance, 0) ? (
          <p className="amount-exceeds-warning">
            ⚠️ المبلغ المُدخَل أكبر من مديونية العميل
            {customer.balance > 0 ? ` (${formatCurrency(customer.balance)})` : ''}.
            سيصبح للعميل رصيد دائن لدى الشركة. تحقق أن هذا مقصود.
          </p>
        ) : null}

        <Field label="ملاحظات (اختياري)">
          <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="ملاحظات على السند" />
        </Field>

        <Field label="توقيع المندوب">
          <SignaturePad ref={signatureRef} height={150} initialDataURL={existingSignature} />
        </Field>

        <Button fullWidth size="lg" onClick={handleSave} disabled={saving}>
          {saving ? 'جاري الحفظ...' : 'حفظ سند القبض'}
        </Button>
      </div>

      <CustomerPicker
        open={customerPickerOpen}
        onClose={() => setCustomerPickerOpen(false)}
        onSelect={(c) => { setCustomer(c); setCustomerPickerOpen(false); }}
        selectedId={customer?.id}
      />

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 24px);
        }
        .receipt-form-content {
          padding: 14px 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .customer-select-row {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 12px;
          background: var(--color-surface);
          border: 1.5px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 12px 14px;
          margin-bottom: 12px;
          cursor: pointer;
        }
        .customer-select-row svg { width: 18px; height: 18px; color: var(--color-ink-faint); flex-shrink: 0; }
        .customer-select-avatar {
          width: 40px; height: 40px;
          border-radius: 50%;
          background: var(--color-bg-sunken);
          color: var(--color-primary);
          display: flex; align-items: center; justify-content: center;
          font-weight: 800; font-size: 16px;
          flex-shrink: 0;
        }
        .customer-select-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 1px;
          text-align: start;
          min-width: 0;
        }
        .customer-select-label {
          font-size: 11px;
          color: var(--color-ink-faint);
          font-weight: 600;
        }
        .customer-select-name {
          font-size: 14.5px;
          font-weight: 700;
          color: var(--color-ink);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .meta-edit-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          padding: 10px 2px;
          margin-bottom: 6px;
        }
        .meta-edit-label {
          font-size: 12.5px;
          font-weight: 600;
          color: var(--color-ink-faint);
          flex-shrink: 0;
        }
        .meta-edit-value {
          display: flex;
          align-items: center;
          gap: 6px;
          background: transparent;
          border: none;
          font-size: 13.5px;
          font-weight: 700;
          color: var(--color-ink);
          cursor: pointer;
          padding: 4px 0;
        }
        .meta-edit-value svg {
          width: 13px; height: 13px;
          color: var(--color-ink-faint);
        }
        .collection-method-switch {
          display: flex;
          gap: 8px;
          margin-bottom: 16px;
        }
        .collection-method-switch button {
          flex: 1;
          height: 42px;
          border: 1.5px solid var(--color-border);
          background: var(--color-surface);
          border-radius: var(--radius-sm);
          font-weight: 700;
          font-size: 13.5px;
          color: var(--color-ink-soft);
          cursor: pointer;
        }
        .collection-method-switch button.active {
          background: var(--color-primary);
          border-color: var(--color-primary);
          color: white;
        }
        .current-balance-hint {
          background: rgba(200,30,30,0.08);
          color: var(--color-danger);
          font-size: 12.5px;
          padding: 8px 12px;
          border-radius: var(--radius-sm);
          margin-bottom: 16px;
          text-align: center;
        }
        .amount-exceeds-warning {
          background: rgba(214,160,21,0.12);
          color: var(--color-amber);
          font-size: 12px;
          font-weight: 700;
          padding: 10px 12px;
          border-radius: var(--radius-sm);
          margin: 0 0 16px;
          line-height: 1.6;
          text-align: center;
        }
        .amount-input-card {
          background: var(--color-primary);
          border-radius: var(--radius-lg);
          padding: 20px;
          margin-bottom: 18px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
        }
        .amount-label {
          color: rgba(255,255,255,0.85);
          font-size: 13px;
          font-weight: 600;
        }
        .amount-input-row {
          display: flex;
          align-items: baseline;
          gap: 8px;
        }
        .amount-input {
          background: transparent;
          border: none;
          outline: none;
          color: white;
          font-size: 38px;
          font-weight: 900;
          text-align: center;
          width: 200px;
          font-family: inherit;
        }
        .amount-input::placeholder {
          color: rgba(255,255,255,0.5);
        }
        .amount-currency {
          color: rgba(255,255,255,0.85);
          font-size: 16px;
          font-weight: 700;
        }
        .fill-full-balance {
          background: rgba(255,255,255,0.18);
          color: white;
          border: none;
          border-radius: 999px;
          padding: 8px 16px;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
}
