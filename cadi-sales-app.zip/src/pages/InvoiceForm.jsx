import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import TopHeader from '../components/TopHeader';
import CustomerPicker from '../components/CustomerPicker';
import ProductPicker from '../components/ProductPicker';
import InvoiceLineItem from '../components/InvoiceLineItem';
import SignaturePad from '../components/SignaturePad';
import DateTimeField from '../components/DateTimeField';
import { Button, Field, Input } from '../components/ui';
import { PlusIcon, DiscountIcon, ChevronIcon, EditIcon } from '../components/Icons';
import { db, PAYMENT_TERMS, getNextRefNumber } from '../db/db';
import { addLedgerEntry, reverseLedgerEntriesByRef } from '../db/ledger';
import { formatCurrency, formatDateTime } from '../utils/format';
import { useToast } from '../components/Toast';

export default function InvoiceForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const showToast = useToast();
  const isEditMode = !!id;

  const initialType = searchParams.get('type') === 'return' ? 'return' : 'sale';
  const isCashMode = searchParams.get('mode') === 'cash';
  const presetCustomerId = searchParams.get('customerId') ? Number(searchParams.get('customerId')) : null;

  const [invoiceType, setInvoiceType] = useState(initialType);
  const [paymentTerm, setPaymentTerm] = useState(isCashMode ? PAYMENT_TERMS.CASH : PAYMENT_TERMS.CREDIT);
  const [customer, setCustomer] = useState(null);
  const [items, setItems] = useState([]); // { productId, name, unit, price, qty }
  const [discount, setDiscount] = useState('');
  const [discountType, setDiscountType] = useState('amount'); // 'amount' | 'percent'
  const [notes, setNotes] = useState('');
  const [existingSignature, setExistingSignature] = useState(null);
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString());
  const [refNumber, setRefNumber] = useState('');
  const [cashCustomerName, setCashCustomerName] = useState('');
  const [editingDate, setEditingDate] = useState(false);
  const [editingRefNumber, setEditingRefNumber] = useState(false);
  const [existingInvoiceId, setExistingInvoiceId] = useState(null);

  const [customerPickerOpen, setCustomerPickerOpen] = useState(false);
  const [productPickerOpen, setProductPickerOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loaded, setLoaded] = useState(!isEditMode);

  const signatureRef = useRef(null);

  // تحميل بيانات العميل المُمَرّر مسبقاً (من صفحة العميل) أو ضبط عميل نقدي
  useEffect(() => {
    if (isEditMode) return;
    (async () => {
      if (presetCustomerId) {
        const c = await db.customers.get(presetCustomerId);
        if (c) setCustomer(c);
      } else if (isCashMode) {
        const all = await db.customers.toArray();
        const cashCustomer = all.find((c) => c.isCash);
        if (cashCustomer) setCustomer(cashCustomer);
      }
    })();
  }, [presetCustomerId, isCashMode, isEditMode]);

  // توقع رقم الفاتورة التالي (تقديري) لعرضه قابلاً للتعديل قبل الحفظ الفعلي.
  // يعتمد على أعلى رقم مرجعي رقمي مستخدَم فعلياً (يتابع التعديلات اليدوية السابقة)،
  // لا فقط آخر id تسلسلي داخلي.
  useEffect(() => {
    if (isEditMode) return;
    (async () => {
      const next = await getNextRefNumber(db.invoices);
      setRefNumber(next);
    })();
  }, [isEditMode]);

  // تحميل فاتورة للتعديل
  useEffect(() => {
    if (!isEditMode) return;
    (async () => {
      const invoice = await db.invoices.get(Number(id));
      if (!invoice) { setLoaded(true); return; }
      setInvoiceType(invoice.type);
      setPaymentTerm(invoice.paymentTerm || PAYMENT_TERMS.CREDIT);
      setItems(invoice.items || []);
      setDiscount(invoice.discountInput ?? (invoice.discount || ''));
      setDiscountType(invoice.discountType || 'amount');
      setNotes(invoice.notes || '');
      setExistingSignature(invoice.signature || null);
      setInvoiceDate(invoice.date || new Date().toISOString());
      setRefNumber(invoice.refNumber || String(invoice.id));
      setCashCustomerName(invoice.cashCustomerName || '');
      setExistingInvoiceId(invoice.id);
      if (invoice.customerId) {
        const c = await db.customers.get(invoice.customerId);
        if (c) setCustomer(c);
      }
      setLoaded(true);
    })();
  }, [id, isEditMode]);

  const subtotal = items.reduce((sum, it) => sum + it.qty * it.price, 0);
  const discountValue = discountType === 'percent'
    ? Math.round((subtotal * (Number(discount) || 0)) / 100)
    : (Number(discount) || 0);
  const netTotal = Math.max(0, subtotal - discountValue);

  function addProduct(product) {
    setItems((prev) => {
      const existing = prev.find((it) => it.productId === product.id);
      if (existing) {
        return prev.map((it) => it.productId === product.id ? { ...it, qty: it.qty + 1 } : it);
      }
      return [...prev, { productId: product.id, name: product.name, unit: product.unit, price: product.price, qty: 1 }];
    });
    // النافذة تبقى مفتوحة لإضافة منتجات متعددة دون إغلاق وإعادة فتح
  }

  function increaseFromPicker(product) {
    setItems((prev) => prev.map((it) => it.productId === product.id ? { ...it, qty: it.qty + 1 } : it));
  }
  function decreaseFromPicker(product) {
    setItems((prev) => {
      const existing = prev.find((it) => it.productId === product.id);
      if (existing && existing.qty <= 1) {
        return prev.filter((it) => it.productId !== product.id);
      }
      return prev.map((it) => it.productId === product.id ? { ...it, qty: it.qty - 1 } : it);
    });
  }

  function updateItem(productId, patch) {
    setItems((prev) => prev.map((it) => it.productId === productId ? { ...it, ...patch } : it));
  }
  function removeItem(productId) {
    setItems((prev) => prev.filter((it) => it.productId !== productId));
  }

  async function handleSave() {
    if (!customer) {
      showToast('يرجى اختيار العميل أولاً', 'error');
      return;
    }
    if (items.length === 0) {
      showToast('أضف منتجاً واحداً على الأقل', 'error');
      return;
    }

    setSaving(true);
    try {
      const signatureData = signatureRef.current?.getDataURL() || null;

      const invoiceData = {
        type: invoiceType,
        paymentTerm,
        customerId: customer.id,
        cashCustomerName: paymentTerm === PAYMENT_TERMS.CASH ? cashCustomerName.trim() : '',
        date: invoiceDate,
        total: subtotal,
        discount: discountValue,
        discountInput: discount,
        discountType,
        netTotal,
        status: 'محفوظة',
        items,
        signature: signatureData,
        notes,
      };

      if (isEditMode) {
        const invoiceId = Number(id);
        invoiceData.refNumber = refNumber || String(invoiceId);
        // عكس الأثر السابق على الرصيد قبل إعادة تطبيقه بالقيم الجديدة
        await reverseLedgerEntriesByRef(invoiceId);
        await db.invoices.update(invoiceId, invoiceData);
        await applyLedgerForInvoice(invoiceId, invoiceType, paymentTerm, customer.id, netTotal, invoiceDate);
        showToast('تم تحديث الفاتورة بنجاح');
      } else {
        const invoiceId = await db.invoices.add(invoiceData);
        // الرقم المرجعي الافتراضي هو نفس رقم الفاتورة التلقائي، قابل للتعديل لاحقاً
        await db.invoices.update(invoiceId, { refNumber: refNumber || String(invoiceId) });
        await applyLedgerForInvoice(invoiceId, invoiceType, paymentTerm, customer.id, netTotal, invoiceDate);
        showToast('تم حفظ الفاتورة بنجاح');
        navigate(`/invoice/${invoiceId}/print`, { replace: true });
        return;
      }
      navigate(-1);
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء الحفظ', 'error');
    } finally {
      setSaving(false);
    }
  }

  async function applyLedgerForInvoice(invoiceId, type, term, customerId, amount, date) {
    // الفاتورة النقدية لا تُسجَّل كمديونية على الإطلاق — لا أثر على كشف الحساب
    if (term === PAYMENT_TERMS.CASH) return;

    if (type === 'sale') {
      await addLedgerEntry({
        customerId,
        type: 'invoice_sale',
        refId: invoiceId,
        debit: amount,
        note: 'فاتورة بيع آجل',
        date,
      });
    } else {
      await addLedgerEntry({
        customerId,
        type: 'invoice_return',
        refId: invoiceId,
        credit: amount,
        note: 'فاتورة مرتجع',
        date,
      });
    }
  }

  if (!loaded) {
    return (
      <div className="page-with-nav">
        <TopHeader title="جاري التحميل..." showBack />
      </div>
    );
  }

  function handleBack() {
    if (items.length > 0) {
      const confirmed = window.confirm('توجد منتجات لم تُحفظ بعد. هل تريد الخروج دون حفظ الفاتورة؟');
      if (!confirmed) return;
    }
    navigate(-1);
  }

  return (
    <div className="page-with-nav invoice-page">
      <TopHeader
        title={isEditMode ? 'تعديل الفاتورة' : (invoiceType === 'return' ? 'فاتورة مرتجع' : 'فاتورة بيع')}
        showBack
        onBack={handleBack}
        rightSlot={<span />}
      />

      <div className="invoice-content">
        {!isEditMode ? (
          <div className="type-switch">
            <button className={invoiceType === 'sale' ? 'active' : ''} onClick={() => setInvoiceType('sale')}>بيع</button>
            <button className={invoiceType === 'return' ? 'active' : ''} onClick={() => setInvoiceType('return')}>مرتجع</button>
          </div>
        ) : null}

        {invoiceType === 'sale' ? (
          <div className="payment-term-switch">
            <button
              className={paymentTerm === PAYMENT_TERMS.CASH ? 'active cash' : ''}
              onClick={() => setPaymentTerm(PAYMENT_TERMS.CASH)}
            >
              💵 نقد
            </button>
            <button
              className={paymentTerm === PAYMENT_TERMS.CREDIT ? 'active credit' : ''}
              onClick={() => setPaymentTerm(PAYMENT_TERMS.CREDIT)}
            >
              📒 آجل (دين)
            </button>
          </div>
        ) : null}

        <button className="customer-select-row" onClick={() => setCustomerPickerOpen(true)}>
          <div className="customer-select-avatar">{customer ? (customer.name.trim().charAt(0) || '؟') : '؟'}</div>
          <div className="customer-select-info">
            <span className="customer-select-label">العميل</span>
            <span className="customer-select-name">{customer ? customer.name : 'اختر العميل'}</span>
          </div>
          <ChevronIcon />
        </button>

        {paymentTerm === PAYMENT_TERMS.CASH ? (
          <Field label="اسم على الفاتورة (اختياري)" hint="لتمييز هذا الإيصال فقط — لن يُنشئ سجل عميل جديد">
            <Input
              value={cashCustomerName}
              onChange={(e) => setCashCustomerName(e.target.value)}
              placeholder="مثال: أحمد، أو اسم المحل"
            />
          </Field>
        ) : null}

        <div className="meta-edit-row">
          <span className="meta-edit-label">التاريخ والوقت</span>
          {editingDate ? (
            <DateTimeField value={invoiceDate} onChange={setInvoiceDate} />
          ) : (
            <button className="meta-edit-value" onClick={() => setEditingDate(true)}>
              {formatDateTime(invoiceDate)} <EditIcon />
            </button>
          )}
        </div>

        <div className="meta-edit-row">
          <span className="meta-edit-label">رقم الفاتورة</span>
          {editingRefNumber ? (
            <Input value={refNumber} onChange={(e) => setRefNumber(e.target.value)} autoFocus />
          ) : (
            <button className="meta-edit-value" onClick={() => setEditingRefNumber(true)}>
              #{refNumber || existingInvoiceId || '...'} <EditIcon />
            </button>
          )}
        </div>

        <div className="section-header">
          <h2>المنتجات</h2>
          <button className="add-product-btn" onClick={() => setProductPickerOpen(true)}>
            <PlusIcon /> إضافة منتج
          </button>
        </div>

        {items.length === 0 ? (
          <div className="empty-items">لا توجد منتجات مضافة — اضغط «إضافة منتج»</div>
        ) : (
          <div className="line-items-list">
            {items.map((item) => (
              <InvoiceLineItem
                key={item.productId}
                item={item}
                onIncrease={() => updateItem(item.productId, { qty: item.qty + 1 })}
                onDecrease={() => updateItem(item.productId, { qty: Math.max(1, item.qty - 1) })}
                onRemove={() => removeItem(item.productId)}
                onPriceChange={(price) => updateItem(item.productId, { price })}
              />
            ))}
          </div>
        )}

        <div className="discount-row">
          <div className="discount-icon"><DiscountIcon /></div>
          <Input
            value={discount}
            onChange={(e) => setDiscount(e.target.value)}
            placeholder="خصم (اختياري)"
            type="number"
            inputMode="decimal"
            className={Number(discount) < 0 ? 'input-negative' : ''}
          />
          <div className="discount-type-toggle">
            <button className={discountType === 'amount' ? 'active' : ''} onClick={() => setDiscountType('amount')}>ر.ي</button>
            <button className={discountType === 'percent' ? 'active' : ''} onClick={() => setDiscountType('percent')}>%</button>
          </div>
        </div>
        {Number(discount) < 0 ? (
          <p className="negative-discount-warning">⚠️ الخصم سالب — هذا يزيد الإجمالي النهائي بدل تخفيضه. تحقق أن هذا مقصود.</p>
        ) : null}

        <div className="totals-card">
          <div className="totals-row">
            <span>الإجمالي الفرعي</span>
            <span>{formatCurrency(subtotal)}</span>
          </div>
          {discountValue > 0 ? (
            <div className="totals-row discount">
              <span>الخصم</span>
              <span>- {formatCurrency(discountValue)}</span>
            </div>
          ) : null}
          <div className="totals-row net">
            <span>الإجمالي النهائي</span>
            <span>{formatCurrency(netTotal)}</span>
          </div>
        </div>

        <Field label="ملاحظات (اختياري)">
          <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="ملاحظات على الفاتورة" />
        </Field>

        <Field label="توقيع العميل">
          <SignaturePad ref={signatureRef} height={150} initialDataURL={existingSignature} />
        </Field>

        {/* مساحة فارغة لتعويض ارتفاع الشريط الثابت أسفل الصفحة */}
        <div className="sticky-bar-spacer" />
      </div>

      <div className="invoice-sticky-bar">
        <div className="sticky-bar-total">
          <span className="sticky-bar-total-label">الإجمالي النهائي</span>
          <span className="sticky-bar-total-value">{formatCurrency(netTotal)}</span>
        </div>
        <Button size="lg" onClick={handleSave} disabled={saving}>
          {saving ? 'جاري الحفظ...' : 'حفظ الفاتورة'}
        </Button>
      </div>

      <CustomerPicker
        open={customerPickerOpen}
        onClose={() => setCustomerPickerOpen(false)}
        onSelect={(c) => { setCustomer(c); setCustomerPickerOpen(false); }}
        selectedId={customer?.id}
      />
      <ProductPicker
        open={productPickerOpen}
        onClose={() => setProductPickerOpen(false)}
        onAdd={addProduct}
        onIncrease={increaseFromPicker}
        onDecrease={decreaseFromPicker}
        currentItems={items}
      />

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 24px);
        }
        .invoice-content {
          padding: 14px 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .sticky-bar-spacer {
          height: 76px;
        }
        .invoice-sticky-bar {
          position: fixed;
          bottom: calc(var(--nav-h) + var(--safe-bottom));
          left: 0;
          right: 0;
          z-index: 45;
          background: var(--color-bg-elevated);
          border-top: 1px solid var(--color-border);
          box-shadow: 0 -4px 16px rgba(0,0,0,0.06);
          padding: 10px 16px;
          display: flex;
          align-items: center;
          gap: 12px;
          max-width: 560px;
          margin: 0 auto;
        }
        .sticky-bar-total {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 1px;
          min-width: 0;
        }
        .sticky-bar-total-label {
          font-size: 10.5px;
          color: var(--color-ink-faint);
          font-weight: 600;
        }
        .sticky-bar-total-value {
          font-size: 17px;
          font-weight: 800;
          color: var(--color-primary);
          white-space: nowrap;
        }
        .invoice-sticky-bar .btn {
          flex-shrink: 0;
          min-width: 150px;
        }
        .type-switch {
          display: flex;
          background: var(--color-bg-sunken);
          border-radius: var(--radius-sm);
          padding: 4px;
          margin-bottom: 14px;
        }
        .type-switch button {
          flex: 1;
          height: 40px;
          border: none;
          background: transparent;
          border-radius: 8px;
          font-weight: 700;
          font-size: 13.5px;
          color: var(--color-ink-soft);
          cursor: pointer;
        }
        .type-switch button.active {
          background: var(--color-primary);
          color: white;
        }
        .payment-term-switch {
          display: flex;
          gap: 8px;
          margin-bottom: 14px;
        }
        .payment-term-switch button {
          flex: 1;
          height: 42px;
          border: 1.5px solid var(--color-border);
          background: var(--color-surface);
          border-radius: var(--radius-sm);
          font-weight: 700;
          font-size: 13.5px;
          color: var(--color-ink-soft);
          cursor: pointer;
        }
        .payment-term-switch button.active.cash {
          background: var(--color-success);
          border-color: var(--color-success);
          color: white;
        }
        .payment-term-switch button.active.credit {
          background: var(--color-danger);
          border-color: var(--color-danger);
          color: white;
        }
        .meta-edit-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          padding: 10px 2px;
          margin-bottom: 6px;
        }
        .meta-edit-label {
          font-size: 12.5px;
          font-weight: 600;
          color: var(--color-ink-faint);
          flex-shrink: 0;
        }
        .meta-edit-value {
          display: flex;
          align-items: center;
          gap: 6px;
          background: transparent;
          border: none;
          font-size: 13.5px;
          font-weight: 700;
          color: var(--color-ink);
          cursor: pointer;
          padding: 4px 0;
        }
        .meta-edit-value svg {
          width: 13px; height: 13px;
          color: var(--color-ink-faint);
        }
        .customer-select-row {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 12px;
          background: var(--color-surface);
          border: 1.5px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 12px 14px;
          margin-bottom: 18px;
          cursor: pointer;
        }
        .customer-select-row svg { width: 18px; height: 18px; color: var(--color-ink-faint); flex-shrink: 0; }
        .customer-select-avatar {
          width: 40px; height: 40px;
          border-radius: 50%;
          background: var(--color-bg-sunken);
          color: var(--color-primary);
          display: flex; align-items: center; justify-content: center;
          font-weight: 800; font-size: 16px;
          flex-shrink: 0;
        }
        .customer-select-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 1px;
          text-align: start;
          min-width: 0;
        }
        .customer-select-label {
          font-size: 11px;
          color: var(--color-ink-faint);
          font-weight: 600;
        }
        .customer-select-name {
          font-size: 14.5px;
          font-weight: 700;
          color: var(--color-ink);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .section-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 10px;
        }
        .section-header h2 {
          font-size: 14px;
          font-weight: 700;
          color: var(--color-ink-soft);
          margin: 0;
        }
        .add-product-btn {
          display: flex;
          align-items: center;
          gap: 4px;
          background: var(--color-primary);
          color: white;
          border: none;
          border-radius: 999px;
          padding: 7px 14px;
          font-size: 12.5px;
          font-weight: 700;
          cursor: pointer;
        }
        .add-product-btn svg { width: 14px; height: 14px; }
        .empty-items {
          text-align: center;
          padding: 30px 0;
          color: var(--color-ink-faint);
          font-size: 13px;
          background: var(--color-surface-2);
          border-radius: var(--radius-sm);
          border: 1px dashed var(--color-border-strong);
          margin-bottom: 18px;
        }
        .line-items-list {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-bottom: 18px;
        }
        .discount-row {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 16px;
        }
        .discount-icon {
          width: 40px; height: 40px;
          border-radius: var(--radius-sm);
          background: rgba(214,160,21,0.14);
          color: var(--color-amber);
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
        }
        .discount-icon svg { width: 19px; height: 19px; }
        .discount-row .input { flex: 1; }
        .discount-row .input-negative {
          border-color: var(--color-danger) !important;
          color: var(--color-danger);
          font-weight: 700;
        }
        .negative-discount-warning {
          font-size: 11.5px;
          color: var(--color-danger);
          font-weight: 700;
          margin: -8px 0 14px;
        }
        .discount-type-toggle {
          display: flex;
          background: var(--color-bg-sunken);
          border-radius: var(--radius-sm);
          padding: 3px;
          flex-shrink: 0;
        }
        .discount-type-toggle button {
          width: 38px; height: 42px;
          border: none;
          background: transparent;
          border-radius: 7px;
          font-weight: 700;
          font-size: 12px;
          color: var(--color-ink-soft);
          cursor: pointer;
        }
        .discount-type-toggle button.active {
          background: var(--color-primary);
          color: white;
        }
        .totals-card {
          background: var(--color-surface-2);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 14px 16px;
          margin-bottom: 18px;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .totals-row {
          display: flex;
          justify-content: space-between;
          font-size: 13.5px;
          color: var(--color-ink-soft);
        }
        .totals-row.discount {
          color: var(--color-danger);
        }
        .totals-row.net {
          font-size: 17px;
          font-weight: 800;
          color: var(--color-primary);
          padding-top: 8px;
          border-top: 1px dashed var(--color-border-strong);
        }
      `}</style>
    </div>
  );
}
