import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import TopHeader from '../components/TopHeader';
import Sheet from '../components/Sheet';
import { Button, Field, Input } from '../components/ui';
import { SearchIcon, PlusIcon, PhoneIcon, ChevronIcon, CustomerIcon } from '../components/Icons';
import { db } from '../db/db';
import { formatCurrency, isLikelyValidYemeniPhone } from '../utils/format';
import { useToast } from '../components/Toast';

export default function Customers() {
  const navigate = useNavigate();
  const showToast = useToast();
  const [query, setQuery] = useState('');
  const [addOpen, setAddOpen] = useState(false);

  const customers = useLiveQuery(() => db.customers.orderBy('name').toArray(), []);

  const filtered = useMemo(() => {
    if (!customers) return [];
    if (!query.trim()) return customers;
    const q = query.trim().toLowerCase();
    return customers.filter(
      (c) => c.name.toLowerCase().includes(q) || (c.phone || '').includes(q) || (c.area || '').toLowerCase().includes(q)
    );
  }, [customers, query]);

  async function handleAddCustomer(data) {
    const trimmedName = data.name.trim();
    const isDuplicate = customers?.some((c) => c.name.trim() === trimmedName);
    if (isDuplicate) {
      const proceed = window.confirm(`يوجد عميل آخر بنفس الاسم "${trimmedName}" مسبقاً. هل تريد إضافة عميل جديد بهذا الاسم رغم ذلك؟`);
      if (!proceed) return;
    }
    try {
      await db.customers.add({
        name: trimmedName,
        phone: data.phone.trim(),
        area: data.area.trim(),
        balance: Number(data.opening) || 0,
        createdAt: new Date().toISOString(),
      });
      showToast('تم إضافة العميل بنجاح');
      setAddOpen(false);
    } catch (e) {
      showToast('حدث خطأ أثناء الإضافة', 'error');
    }
  }

  return (
    <div className="page-with-nav">
      <TopHeader title="العملاء" />

      <div className="customers-content">
        <div className="search-row">
          <div className="search-box">
            <SearchIcon />
            <input
              type="text"
              placeholder="بحث بالاسم أو الهاتف أو المنطقة"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <button className="add-fab" onClick={() => setAddOpen(true)} aria-label="إضافة عميل">
            <PlusIcon />
          </button>
        </div>

        {customers === undefined ? (
          <div className="loading-state">جاري التحميل...</div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <CustomerIcon />
            <p>{query ? 'لا توجد نتائج مطابقة' : 'لا يوجد عملاء بعد — أضف أول عميل'}</p>
          </div>
        ) : (
          <ul className="customer-list">
            {filtered.map((c) => (
              <li key={c.id}>
                <button className="customer-row" onClick={() => navigate(`/customers/${c.id}`)}>
                  <div className="customer-avatar">{c.name.trim().charAt(0) || '؟'}</div>
                  <div className="customer-info">
                    <span className="customer-name">{c.name}</span>
                    <span className="customer-meta">
                      {c.phone ? (
                        <span className="meta-phone"><PhoneIcon />{c.phone}</span>
                      ) : (
                        <span className="meta-phone">{c.area || '—'}</span>
                      )}
                    </span>
                  </div>
                  <div className="customer-balance-block">
                    <span className={`customer-balance ${c.balance > 0 ? 'owing' : c.balance < 0 ? 'credit' : ''}`}>
                      {formatCurrency(Math.abs(c.balance || 0))}
                    </span>
                    <span className="balance-label">
                      {c.balance > 0 ? 'مديون' : c.balance < 0 ? 'له رصيد' : 'متسوّي'}
                    </span>
                  </div>
                  <ChevronIcon />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <Sheet open={addOpen} onClose={() => setAddOpen(false)} title="إضافة عميل جديد">
        <AddCustomerForm onSubmit={handleAddCustomer} onCancel={() => setAddOpen(false)} />
      </Sheet>

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 16px);
        }
        .customers-content {
          padding: 14px 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .search-row {
          display: flex;
          gap: 10px;
          margin-bottom: 16px;
        }
        .search-box {
          flex: 1;
          display: flex;
          align-items: center;
          gap: 8px;
          background: var(--color-surface);
          border: 1.5px solid var(--color-border);
          border-radius: var(--radius-sm);
          padding: 0 14px;
          height: 48px;
        }
        .search-box svg {
          width: 19px;
          height: 19px;
          color: var(--color-ink-faint);
          flex-shrink: 0;
        }
        .search-box input {
          border: none;
          outline: none;
          background: transparent;
          flex: 1;
          font-size: 14.5px;
          color: var(--color-ink);
          font-family: inherit;
        }
        .add-fab {
          width: 48px;
          height: 48px;
          border-radius: var(--radius-sm);
          background: var(--color-primary);
          color: white;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          cursor: pointer;
        }
        .add-fab svg { width: 22px; height: 22px; }
        .add-fab:active { transform: scale(0.94); }

        .customer-list {
          list-style: none;
          margin: 0;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .customer-row {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 12px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 12px 14px;
          cursor: pointer;
        }
        .customer-row:active { background: var(--color-bg-sunken); }
        .customer-row svg:last-child {
          width: 18px; height: 18px;
          color: var(--color-ink-faint);
          flex-shrink: 0;
        }
        .customer-avatar {
          width: 42px;
          height: 42px;
          border-radius: 50%;
          background: var(--color-bg-sunken);
          color: var(--color-primary);
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 800;
          font-size: 17px;
          flex-shrink: 0;
        }
        .customer-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 2px;
          text-align: start;
          min-width: 0;
        }
        .customer-name {
          font-weight: 700;
          font-size: 14.5px;
          color: var(--color-ink);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .customer-meta {
          font-size: 12px;
          color: var(--color-ink-faint);
        }
        .meta-phone {
          display: inline-flex;
          align-items: center;
          gap: 4px;
        }
        .meta-phone svg { width: 12px; height: 12px; }
        .customer-balance-block {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 1px;
          flex-shrink: 0;
        }
        .customer-balance {
          font-weight: 800;
          font-size: 13.5px;
          color: var(--color-ink-soft);
        }
        .customer-balance.owing { color: var(--color-danger); }
        .customer-balance.credit { color: var(--color-success); }
        .balance-label {
          font-size: 10.5px;
          color: var(--color-ink-faint);
        }
        .empty-state, .loading-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
          padding: 60px 24px;
          color: var(--color-ink-faint);
          text-align: center;
        }
        .empty-state svg {
          width: 40px; height: 40px;
        }
      `}</style>
    </div>
  );
}

function AddCustomerForm({ onSubmit, onCancel }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [area, setArea] = useState('');
  const [opening, setOpening] = useState('');
  const [error, setError] = useState('');

  function submit(e) {
    e.preventDefault();
    if (!name.trim()) {
      setError('اسم العميل مطلوب');
      return;
    }
    onSubmit({ name, phone, area, opening });
  }

  return (
    <form onSubmit={submit}>
      <Field label="اسم العميل" error={error}>
        <Input value={name} onChange={(e) => { setName(e.target.value); setError(''); }} placeholder="مثال: بقالة النور" autoFocus />
      </Field>
      <Field label="رقم الهاتف" hint={phone && !isLikelyValidYemeniPhone(phone) ? '⚠️ تحقق من الرقم — الصيغة المعتادة: 9 أرقام تبدأ بـ7' : undefined}>
        <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="77xxxxxxx" type="tel" inputMode="numeric" />
      </Field>
      <Field label="المنطقة / العنوان">
        <Input value={area} onChange={(e) => setArea(e.target.value)} placeholder="مثال: صنعاء - حدة" />
      </Field>
      <Field label="رصيد افتتاحي (اختياري)" hint="مديونية سابقة على العميل قبل بدء استخدام التطبيق">
        <Input value={opening} onChange={(e) => setOpening(e.target.value)} placeholder="0" type="number" inputMode="decimal" />
      </Field>
      <div className="form-actions">
        <Button type="submit" fullWidth>حفظ العميل</Button>
        <Button type="button" variant="ghost" onClick={onCancel} fullWidth>إلغاء</Button>
      </div>
      <style>{`
        .form-actions {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-top: 6px;
        }
      `}</style>
    </form>
  );
}
