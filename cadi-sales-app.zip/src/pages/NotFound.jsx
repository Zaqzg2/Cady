import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui';

export default function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="not-found-page">
      <div className="not-found-icon">🧭</div>
      <h1>الصفحة غير موجودة</h1>
      <p>الرابط الذي وصلت إليه غير صحيح أو تم نقله.</p>
      <Button onClick={() => navigate('/', { replace: true })}>العودة للرئيسية</Button>

      <style>{`
        .not-found-page {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 10px;
          padding: 24px;
          text-align: center;
        }
        .not-found-icon { font-size: 44px; }
        .not-found-page h1 { font-size: 17px; margin: 0; color: var(--color-ink); }
        .not-found-page p { font-size: 13.5px; color: var(--color-ink-faint); margin: 0 0 10px; }
      `}</style>
    </div>
  );
}
