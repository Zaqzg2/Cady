import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import TopHeader from '../components/TopHeader';
import Sheet from '../components/Sheet';
import { Button, Field, Input } from '../components/ui';
import {
  PhoneIcon, EditIcon, TrashIcon, PrintIcon, LedgerIcon,
  SaleInvoiceIcon, ReturnInvoiceIcon, ReceiptIcon,
} from '../components/Icons';
import { db } from '../db/db';
import { reverseLedgerEntriesByRef } from '../db/ledger';
import { formatCurrency, formatDateTime, invoiceNumber, receiptNumber, isLikelyValidYemeniPhone } from '../utils/format';
import { useToast } from '../components/Toast';

export default function CustomerDetail() {
  const { id } = useParams();
  const customerId = Number(id);
  const navigate = useNavigate();
  const showToast = useToast();

  const [editOpen, setEditOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null); // { kind, id } - حذف حركة فردية من كشف الحساب
  const [confirmDeleteCustomer, setConfirmDeleteCustomer] = useState(false); // حذف العميل بالكامل
  const [deletingCustomer, setDeletingCustomer] = useState(false);

  const customer = useLiveQuery(() => db.customers.get(customerId), [customerId]);

  const ledger = useLiveQuery(
    () => db.ledger.where('customerId').equals(customerId).reverse().sortBy('date'),
    [customerId]
  );

  const invoiceCount = useLiveQuery(
    () => db.invoices.where('customerId').equals(customerId).count(),
    [customerId]
  );
  const receiptCount = useLiveQuery(
    () => db.receipts.where('customerId').equals(customerId).count(),
    [customerId]
  );

  if (customer === undefined || ledger === undefined) {
    return (
      <div className="page-with-nav">
        <TopHeader title="جاري التحميل..." showBack />
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="page-with-nav">
        <TopHeader title="العميل غير موجود" showBack />
      </div>
    );
  }

  async function handleEditCustomer(data) {
    await db.customers.update(customerId, {
      name: data.name.trim(),
      phone: data.phone.trim(),
      area: data.area.trim(),
    });
    showToast('تم تحديث بيانات العميل');
    setEditOpen(false);
  }

  async function handleDeleteEntry() {
    if (!confirmDelete) return;
    const { kind, refId } = confirmDelete;
    try {
      if (kind === 'invoice') {
        await reverseLedgerEntriesByRef(refId);
        await db.invoices.delete(refId);
      } else if (kind === 'receipt') {
        await reverseLedgerEntriesByRef(refId, 'receipt');
        await db.receipts.delete(refId);
      }
      showToast('تم الحذف بنجاح');
    } catch (e) {
      showToast('حدث خطأ أثناء الحذف', 'error');
    }
    setConfirmDelete(null);
  }

  async function handleDeleteCustomer() {
    setDeletingCustomer(true);
    try {
      await db.transaction('rw', db.customers, db.invoices, db.receipts, db.ledger, async () => {
        await db.invoices.where('customerId').equals(customerId).delete();
        await db.receipts.where('customerId').equals(customerId).delete();
        await db.ledger.where('customerId').equals(customerId).delete();
        await db.customers.delete(customerId);
      });
      showToast('تم حذف العميل وكل بياناته بنجاح');
      navigate('/customers', { replace: true });
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء حذف العميل', 'error');
      setDeletingCustomer(false);
    }
  }

  const balance = customer.balance || 0;

  return (
    <div className="page-with-nav">
      <TopHeader title={customer.name} showBack rightSlot={
        <div className="header-actions">
          <button className="icon-btn" onClick={() => setEditOpen(true)} aria-label="تعديل العميل">
            <EditIcon />
          </button>
          <button className="icon-btn danger" onClick={() => setConfirmDeleteCustomer(true)} aria-label="حذف العميل">
            <TrashIcon />
          </button>
        </div>
      } />

      <div className="detail-content">
        <div className="balance-card drop-corner">
          <span className="balance-card-label">
            {balance > 0 ? 'مديون بمبلغ' : balance < 0 ? 'له رصيد لدى الشركة' : 'الحساب متسوّي'}
          </span>
          <span className="balance-card-value">{formatCurrency(Math.abs(balance))}</span>
          {customer.phone ? (
            <a href={`tel:${customer.phone}`} className="balance-card-phone">
              <PhoneIcon /> {customer.phone}
            </a>
          ) : null}
        </div>

        {customer.area ? <p className="customer-area-line">📍 {customer.area}</p> : null}

        <div className="quick-actions">
          <button className="quick-action" onClick={() => navigate(`/invoice/new?type=sale&customerId=${customerId}`)}>
            <SaleInvoiceIcon /> فاتورة بيع
          </button>
          <button className="quick-action" onClick={() => navigate(`/invoice/new?type=return&customerId=${customerId}`)}>
            <ReturnInvoiceIcon /> مرتجع
          </button>
          <button className="quick-action" onClick={() => navigate(`/receipt/new?customerId=${customerId}`)}>
            <ReceiptIcon /> سند قبض
          </button>
        </div>

        <div className="statement-header-row">
          <h2 className="section-title"><LedgerIcon /> كشف الحساب</h2>
          {ledger.length > 0 ? (
            <button className="statement-print-link" onClick={() => navigate(`/customers/${customerId}/statement`)}>
              <PrintIcon /> طباعة / تحميل
            </button>
          ) : null}
        </div>

        {ledger.length === 0 ? (
          <div className="empty-ledger">لا توجد حركات على هذا العميل بعد</div>
        ) : (
          <ul className="ledger-list">
            {ledger.map((entry) => (
              <li key={entry.id}>
                <LedgerRow
                  entry={entry}
                  onEdit={() => {
                    if (entry.type === 'invoice_sale' || entry.type === 'invoice_return') {
                      navigate(`/invoice/${entry.refId}/edit`);
                    } else if (entry.type === 'receipt') {
                      navigate(`/receipt/${entry.refId}/edit`);
                    }
                  }}
                  onPrint={() => {
                    if (entry.type === 'invoice_sale' || entry.type === 'invoice_return') {
                      navigate(`/invoice/${entry.refId}/print`);
                    } else if (entry.type === 'receipt') {
                      navigate(`/receipt/${entry.refId}/print`);
                    }
                  }}
                  onDelete={() => {
                    if (entry.type === 'invoice_sale' || entry.type === 'invoice_return') {
                      setConfirmDelete({ kind: 'invoice', refId: entry.refId });
                    } else if (entry.type === 'receipt') {
                      setConfirmDelete({ kind: 'receipt', refId: entry.refId });
                    }
                  }}
                />
              </li>
            ))}
          </ul>
        )}
      </div>

      <Sheet open={editOpen} onClose={() => setEditOpen(false)} title="تعديل بيانات العميل">
        <EditCustomerForm customer={customer} onSubmit={handleEditCustomer} onCancel={() => setEditOpen(false)} />
      </Sheet>

      <Sheet open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="تأكيد الحذف">
        <p className="confirm-text">
          سيتم حذف هذه الحركة نهائياً وعكس أثرها على رصيد العميل. هل تريد المتابعة؟
        </p>
        <div className="form-actions">
          <Button variant="danger" fullWidth onClick={handleDeleteEntry}>حذف نهائياً</Button>
          <Button variant="ghost" fullWidth onClick={() => setConfirmDelete(null)}>تراجع</Button>
        </div>
      </Sheet>

      <Sheet open={confirmDeleteCustomer} onClose={() => setConfirmDeleteCustomer(false)} title="⚠️ حذف العميل نهائياً">
        <DeleteCustomerConfirm
          customerName={customer.name}
          balance={balance}
          invoiceCount={invoiceCount ?? 0}
          receiptCount={receiptCount ?? 0}
          deleting={deletingCustomer}
          onConfirm={handleDeleteCustomer}
          onCancel={() => setConfirmDeleteCustomer(false)}
        />
      </Sheet>

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 16px);
        }
        .detail-content {
          padding: 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .balance-card {
          background: var(--color-primary);
          color: white;
          padding: 22px 20px 26px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          margin-bottom: 14px;
        }
        .balance-card-label {
          font-size: 13px;
          opacity: 0.9;
          font-weight: 600;
        }
        .balance-card-value {
          font-size: 28px;
          font-weight: 900;
        }
        .balance-card-phone {
          margin-top: 6px;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          color: white;
          background: rgba(255,255,255,0.18);
          padding: 6px 14px;
          border-radius: 999px;
          font-size: 12.5px;
          text-decoration: none;
        }
        .balance-card-phone svg { width: 14px; height: 14px; }
        .customer-area-line {
          text-align: center;
          color: var(--color-ink-faint);
          font-size: 13px;
          margin: 0 0 16px;
        }
        .quick-actions {
          display: flex;
          gap: 8px;
          margin-bottom: 24px;
        }
        .quick-action {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          padding: 12px 6px;
          border-radius: var(--radius-sm);
          border: 1px solid var(--color-border);
          background: var(--color-surface);
          color: var(--color-ink);
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
        }
        .quick-action svg { width: 20px; height: 20px; color: var(--color-primary); }
        .quick-action:active { background: var(--color-bg-sunken); }
        .statement-header-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
        }
        .statement-header-row .section-title {
          margin: 0;
        }
        .statement-print-link {
          display: flex;
          align-items: center;
          gap: 5px;
          background: var(--color-bg-sunken);
          border: none;
          border-radius: 999px;
          padding: 6px 12px;
          font-size: 11.5px;
          font-weight: 700;
          color: var(--color-primary);
          cursor: pointer;
        }
        .statement-print-link svg { width: 13px; height: 13px; }
        .section-title {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 14px;
          font-weight: 700;
          color: var(--color-ink-soft);
          margin: 0 0 12px 4px;
        }
        .section-title svg { width: 17px; height: 17px; }
        .empty-ledger {
          text-align: center;
          color: var(--color-ink-faint);
          padding: 30px 0;
          font-size: 13.5px;
        }
        .ledger-list {
          list-style: none;
          margin: 0;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .confirm-text {
          color: var(--color-ink-soft);
          font-size: 14px;
          line-height: 1.7;
          margin: 0 0 18px;
        }
        .form-actions {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .header-actions {
          display: flex;
          align-items: center;
        }
        .icon-btn {
          width: var(--tap-min);
          height: var(--tap-min);
          display: flex;
          align-items: center;
          justify-content: center;
          background: transparent;
          border: none;
          border-radius: 50%;
          color: var(--color-ink);
          cursor: pointer;
        }
        .icon-btn.danger {
          color: var(--color-danger);
        }
        .icon-btn svg { width: 22px; height: 22px; }
      `}</style>
    </div>
  );
}

function LedgerRow({ entry, onEdit, onPrint, onDelete }) {
  const isDebit = entry.debit > 0;
  const typeLabel = {
    invoice_sale: 'فاتورة بيع',
    invoice_return: 'فاتورة مرتجع',
    receipt: 'سند قبض',
    opening: 'رصيد افتتاحي',
  }[entry.type] || entry.type;

  const TypeIcon = {
    invoice_sale: SaleInvoiceIcon,
    invoice_return: ReturnInvoiceIcon,
    receipt: ReceiptIcon,
  }[entry.type];

  return (
    <div className="ledger-row">
      <div className={`ledger-icon ${isDebit ? 'debit' : 'credit'}`}>
        {TypeIcon ? <TypeIcon /> : <LedgerIcon />}
      </div>
      <div className="ledger-info">
        <span className="ledger-type">{typeLabel} {entry.refId ? `#${String(entry.refId).padStart(5, '0')}` : ''}</span>
        <span className="ledger-date">{formatDateTime(entry.date)}</span>
      </div>
      <div className="ledger-amount-block">
        <span className={`ledger-amount ${isDebit ? 'debit' : 'credit'}`}>
          {isDebit ? '+' : '-'}{formatCurrency(entry.debit || entry.credit)}
        </span>
        <span className="ledger-after">الرصيد: {formatCurrency(entry.balanceAfter)}</span>
      </div>
      {entry.type !== 'opening' ? (
        <div className="ledger-actions">
          <button onClick={onPrint} aria-label="طباعة"><PrintIcon /></button>
          <button onClick={onEdit} aria-label="تعديل"><EditIcon /></button>
          <button onClick={onDelete} aria-label="حذف" className="danger"><TrashIcon /></button>
        </div>
      ) : null}

      <style>{`
        .ledger-row {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 12px 14px;
          display: flex;
          align-items: center;
          gap: 10px;
          flex-wrap: wrap;
        }
        .ledger-icon {
          width: 38px;
          height: 38px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }
        .ledger-icon svg { width: 19px; height: 19px; }
        .ledger-icon.debit { background: rgba(200,30,30,0.10); color: var(--color-danger); }
        .ledger-icon.credit { background: rgba(46,125,91,0.12); color: var(--color-success); }
        .ledger-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 2px;
          min-width: 100px;
        }
        .ledger-type {
          font-weight: 700;
          font-size: 13.5px;
          color: var(--color-ink);
        }
        .ledger-date {
          font-size: 11px;
          color: var(--color-ink-faint);
        }
        .ledger-amount-block {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 2px;
        }
        .ledger-amount {
          font-weight: 800;
          font-size: 13.5px;
        }
        .ledger-amount.debit { color: var(--color-danger); }
        .ledger-amount.credit { color: var(--color-success); }
        .ledger-after {
          font-size: 10.5px;
          color: var(--color-ink-faint);
        }
        .ledger-actions {
          width: 100%;
          display: flex;
          gap: 6px;
          margin-top: 6px;
          padding-top: 10px;
          border-top: 1px dashed var(--color-border);
        }
        .ledger-actions button {
          flex: 1;
          height: 36px;
          border-radius: var(--radius-sm);
          border: none;
          background: var(--color-bg-sunken);
          color: var(--color-ink-soft);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }
        .ledger-actions button.danger {
          color: var(--color-danger);
          background: rgba(200,30,30,0.08);
        }
        .ledger-actions svg { width: 17px; height: 17px; }
      `}</style>
    </div>
  );
}

function EditCustomerForm({ customer, onSubmit, onCancel }) {
  const [name, setName] = useState(customer.name);
  const [phone, setPhone] = useState(customer.phone || '');
  const [area, setArea] = useState(customer.area || '');
  const [error, setError] = useState('');

  function submit(e) {
    e.preventDefault();
    if (!name.trim()) { setError('اسم العميل مطلوب'); return; }
    onSubmit({ name, phone, area });
  }

  return (
    <form onSubmit={submit}>
      <Field label="اسم العميل" error={error}>
        <Input value={name} onChange={(e) => { setName(e.target.value); setError(''); }} />
      </Field>
      <Field label="رقم الهاتف" hint={phone && !isLikelyValidYemeniPhone(phone) ? '⚠️ تحقق من الرقم — الصيغة المعتادة: 9 أرقام تبدأ بـ7' : undefined}>
        <Input value={phone} onChange={(e) => setPhone(e.target.value)} type="tel" inputMode="numeric" />
      </Field>
      <Field label="المنطقة / العنوان">
        <Input value={area} onChange={(e) => setArea(e.target.value)} />
      </Field>
      <div className="form-actions">
        <Button type="submit" fullWidth>حفظ التعديلات</Button>
        <Button type="button" variant="ghost" fullWidth onClick={onCancel}>إلغاء</Button>
      </div>
    </form>
  );
}

function DeleteCustomerConfirm({ customerName, balance, invoiceCount, receiptCount, deleting, onConfirm, onCancel }) {
  const [confirmText, setConfirmText] = useState('');
  const hasData = invoiceCount > 0 || receiptCount > 0 || balance !== 0;
  const canDelete = confirmText.trim() === 'حذف';

  return (
    <div>
      <div className="delete-warning-box">
        <p className="delete-warning-title">
          أنت على وشك حذف العميل «{customerName}» نهائياً.
        </p>
        {hasData ? (
          <ul className="delete-warning-stats">
            <li>📄 سيتم حذف <strong>{invoiceCount}</strong> فاتورة (بيع ومرتجع)</li>
            <li>🧾 سيتم حذف <strong>{receiptCount}</strong> سند قبض</li>
            <li>
              💰 الرصيد الحالي:{' '}
              <strong className={balance > 0 ? 'text-danger' : balance < 0 ? 'text-success' : ''}>
                {balance > 0 ? `مديون بـ ${formatCurrency(balance)}` : balance < 0 ? `له رصيد ${formatCurrency(Math.abs(balance))}` : 'متسوّي'}
              </strong>
            </li>
          </ul>
        ) : (
          <p className="delete-warning-clean">لا توجد فواتير أو سندات أو مديونية مرتبطة بهذا العميل.</p>
        )}
        <p className="delete-warning-final">
          هذا الإجراء <strong>لا يمكن التراجع عنه</strong>. كل البيانات المذكورة أعلاه ستُحذف نهائياً من جهازك.
        </p>
      </div>

      <Field label='اكتب كلمة "حذف" للتأكيد'>
        <Input
          value={confirmText}
          onChange={(e) => setConfirmText(e.target.value)}
          placeholder="حذف"
          autoFocus
        />
      </Field>

      <div className="form-actions">
        <Button variant="danger" fullWidth onClick={onConfirm} disabled={!canDelete || deleting}>
          {deleting ? 'جاري الحذف...' : 'حذف العميل نهائياً'}
        </Button>
        <Button variant="ghost" fullWidth onClick={onCancel} disabled={deleting}>تراجع</Button>
      </div>

      <style>{`
        .delete-warning-box {
          background: rgba(200,30,30,0.06);
          border: 1.5px solid rgba(200,30,30,0.25);
          border-radius: var(--radius-md);
          padding: 14px 16px;
          margin-bottom: 16px;
        }
        .delete-warning-title {
          font-weight: 800;
          font-size: 14px;
          color: var(--color-ink);
          margin: 0 0 10px;
        }
        .delete-warning-stats {
          list-style: none;
          margin: 0 0 12px;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 6px;
          font-size: 13px;
          color: var(--color-ink-soft);
        }
        .delete-warning-stats strong { color: var(--color-ink); }
        .text-danger { color: var(--color-danger) !important; }
        .text-success { color: var(--color-success) !important; }
        .delete-warning-clean {
          font-size: 13px;
          color: var(--color-ink-soft);
          margin: 0 0 12px;
        }
        .delete-warning-final {
          font-size: 12px;
          color: var(--color-danger);
          font-weight: 600;
          margin: 0;
          line-height: 1.6;
        }
      `}</style>
    </div>
  );
}
