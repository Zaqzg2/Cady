import React, { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import TopHeader from '../components/TopHeader';
import ReceiptTemplate from '../components/ReceiptTemplate';
import { Button } from '../components/ui';
import { PrintIcon, ShareIcon, DownloadIcon } from '../components/Icons';
import { db } from '../db/db';
import { getSettings } from '../db/settings';
import { useToast } from '../components/Toast';
import { useBluetoothPrint } from '../hooks/useBluetoothPrint';
import { buildImagePrintBytes } from '../services/receiptImagePrint';
import { bluetoothPrinter } from '../services/bluetoothPrinter';
import { downloadElementAsPdf, elementToReceiptPdfFile } from '../services/pdfBuilder';

export default function ReceiptPrint() {
  const { id } = useParams();
  const navigate = useNavigate();
  const showToast = useToast();
  const { printing, printBytes } = useBluetoothPrint();
  const receiptRef = useRef(null);

  const [receipt, setReceipt] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [settings, setSettings] = useState(null);
  const [pdfBusy, setPdfBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const rec = await db.receipts.get(Number(id));
      if (!rec) return;
      setReceipt(rec);
      if (rec.customerId) {
        const c = await db.customers.get(rec.customerId);
        setCustomer(c);
      }
      const s = await getSettings();
      setSettings(s);
    })();
  }, [id]);

  async function handlePrint() {
    if (!bluetoothPrinter.isSupported()) {
      showToast('متصفحك لا يدعم الاتصال بالبلوتوث — جرّب Chrome على أندرويد', 'error');
      return;
    }
    showToast(bluetoothPrinter.isConnected() ? 'جاري تجهيز الإيصال...' : 'اختر طابعتك من القائمة...');
    try {
      const bytes = await buildImagePrintBytes(receiptRef.current, settings.printer.printWidthPx);
      const ok = await printBytes(bytes);
      if (ok) {
        showToast('تمت الطباعة بنجاح');
      } else {
        showToast('تعذّر الاتصال بالطابعة', 'error');
      }
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء الطباعة', 'error');
    }
  }

  function buildShareText() {
    if (!receipt) return '';
    const methodLabel = receipt.collectionMethod === 'transfer' ? 'تحويل بنكي' : 'نقداً';
    return [
      `${settings?.company.name || 'كادي للمنظفات'}`,
      `سند قبض #${receipt.refNumber || receipt.id}`,
      `العميل: ${customer?.name || '—'}`,
      `طريقة التحصيل: ${methodLabel}`,
      `المبلغ المستلم: ${receipt.amount} ر.ي`,
    ].join('\n');
  }

  async function handleShare() {
    const filename = `سند-قبض-${receipt.refNumber || receipt.id}`;
    try {
      setPdfBusy(true);
      const file = await elementToReceiptPdfFile(receiptRef.current, filename);
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ title: 'سند قبض - كادي للمنظفات', files: [file] });
        return;
      }
    } catch (e) {
      // فشل توليد الملف أو ألغى المستخدم — ننتقل للخيار النصي البديل
    } finally {
      setPdfBusy(false);
    }

    const text = buildShareText();
    if (navigator.share) {
      try {
        await navigator.share({ title: 'سند قبض - كادي للمنظفات', text });
      } catch (e) {
        // المستخدم ألغى المشاركة
      }
    } else {
      await navigator.clipboard?.writeText(text);
      showToast('تم نسخ تفاصيل السند');
    }
  }

  async function handleDownload() {
    setPdfBusy(true);
    try {
      await downloadElementAsPdf(receiptRef.current, `سند-قبض-${receipt.refNumber || receipt.id}`, settings.invoiceLayout.paperWidth);
      showToast('تم تحميل السند كملف PDF');
    } catch (e) {
      console.error(e);
      showToast('تعذّر إنشاء ملف PDF', 'error');
    } finally {
      setPdfBusy(false);
    }
  }

  if (!receipt || !settings) {
    return (
      <div className="page-with-nav">
        <TopHeader title="جاري التحميل..." showBack />
      </div>
    );
  }

  return (
    <div className="page-with-nav print-page">
      <TopHeader title="معاينة السند" showBack onBack={() => navigate('/', { replace: true })} />

      <div className="print-content">
        <div className="receipt-preview-frame">
          <div ref={receiptRef}>
            <ReceiptTemplate kind="receipt" data={receipt} customer={customer} settings={settings} />
          </div>
        </div>

        <div className="print-actions">
          <Button fullWidth size="lg" icon={<PrintIcon />} onClick={handlePrint} disabled={printing}>
            {printing ? 'جاري الطباعة...' : 'طباعة 80مم'}
          </Button>
          <div className="action-row">
            <Button variant="secondary" fullWidth icon={<ShareIcon />} onClick={handleShare} disabled={pdfBusy}>مشاركة</Button>
            <Button variant="secondary" fullWidth icon={<DownloadIcon />} onClick={handleDownload} disabled={pdfBusy}>
              {pdfBusy ? 'جاري التجهيز...' : 'تحميل PDF'}
            </Button>
          </div>
          <Button variant="ghost" fullWidth onClick={() => navigate('/', { replace: true })}>
            الانتقال للرئيسية
          </Button>
        </div>
      </div>

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 16px);
        }
        .print-content {
          padding: 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .receipt-preview-frame {
          background: var(--color-bg-sunken);
          border-radius: var(--radius-md);
          padding: 16px 0;
          display: flex;
          justify-content: center;
          margin-bottom: 20px;
          overflow-x: auto;
        }
        .print-actions {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .action-row {
          display: flex;
          gap: 10px;
        }
        @media print {
          .top-header, .bottom-nav, .print-actions { display: none !important; }
          .receipt-preview-frame { background: white; padding: 0; }
          .page-with-nav { padding-bottom: 0; }
        }
      `}</style>
    </div>
  );
}
