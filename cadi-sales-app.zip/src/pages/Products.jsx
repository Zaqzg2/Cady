import React, { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import TopHeader from '../components/TopHeader';
import Sheet from '../components/Sheet';
import { Button, Field, Input } from '../components/ui';
import { SearchIcon, PlusIcon, EditIcon, TrashIcon, BoxOpenIcon } from '../components/Icons';
import { db } from '../db/db';
import { formatCurrency } from '../utils/format';
import { useToast } from '../components/Toast';

const CATEGORY_COLORS = [
  '#C81E1E', '#D6A015', '#2E7D5B', '#3D6FB4', '#8A4FB4', '#B45A2E',
];

function colorForCategory(category) {
  if (!category) return CATEGORY_COLORS[0];
  let hash = 0;
  for (let i = 0; i < category.length; i++) hash = (hash * 31 + category.charCodeAt(i)) >>> 0;
  return CATEGORY_COLORS[hash % CATEGORY_COLORS.length];
}

export default function Products() {
  const showToast = useToast();
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('الكل');
  const [formOpen, setFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const products = useLiveQuery(() => db.products.orderBy('name').toArray(), []);

  const categories = useMemo(() => {
    if (!products) return ['الكل'];
    const set = new Set(products.map((p) => p.category || 'بدون فئة'));
    return ['الكل', ...Array.from(set)];
  }, [products]);

  const filtered = useMemo(() => {
    if (!products) return [];
    let list = products;
    if (activeCategory !== 'الكل') {
      list = list.filter((p) => (p.category || 'بدون فئة') === activeCategory);
    }
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q));
    }
    return list;
  }, [products, activeCategory, query]);

  function openAddForm() {
    setEditingProduct(null);
    setFormOpen(true);
  }
  function openEditForm(product) {
    setEditingProduct(product);
    setFormOpen(true);
  }

  async function handleSubmit(data) {
    const payload = {
      name: data.name.trim(),
      price: Number(data.price) || 0,
      unit: data.unit.trim() || 'حبة',
      category: data.category.trim() || 'بدون فئة',
      isActive: true,
    };
    try {
      if (editingProduct) {
        await db.products.update(editingProduct.id, payload);
        showToast('تم تحديث المنتج');
      } else {
        await db.products.add(payload);
        showToast('تم إضافة المنتج بنجاح');
      }
      setFormOpen(false);
    } catch (e) {
      showToast('حدث خطأ أثناء الحفظ', 'error');
    }
  }

  async function handleDelete() {
    if (!confirmDelete) return;
    try {
      await db.products.delete(confirmDelete.id);
      showToast('تم حذف المنتج');
    } catch (e) {
      showToast('حدث خطأ أثناء الحذف', 'error');
    }
    setConfirmDelete(null);
  }

  return (
    <div className="page-with-nav">
      <TopHeader title="المنتجات" />

      <div className="products-content">
        <div className="search-row">
          <div className="search-box">
            <SearchIcon />
            <input
              type="text"
              placeholder="بحث عن منتج"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <button className="add-fab" onClick={openAddForm} aria-label="إضافة منتج">
            <PlusIcon />
          </button>
        </div>

        {categories.length > 2 ? (
          <div className="category-strip no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                className={`category-chip ${activeCategory === cat ? 'active' : ''}`}
                onClick={() => setActiveCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>
        ) : null}

        {products === undefined ? (
          <div className="loading-state">جاري التحميل...</div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <BoxOpenIcon />
            <p>{query || activeCategory !== 'الكل' ? 'لا توجد نتائج مطابقة' : 'لا توجد منتجات بعد — أضف أول منتج'}</p>
          </div>
        ) : (
          <div className="products-grid">
            {filtered.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                color={colorForCategory(p.category)}
                onEdit={() => openEditForm(p)}
                onDelete={() => setConfirmDelete(p)}
              />
            ))}
          </div>
        )}
      </div>

      <Sheet open={formOpen} onClose={() => setFormOpen(false)} title={editingProduct ? 'تعديل المنتج' : 'إضافة منتج جديد'}>
        <ProductForm product={editingProduct} onSubmit={handleSubmit} onCancel={() => setFormOpen(false)} />
      </Sheet>

      <Sheet open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="تأكيد الحذف">
        <p className="confirm-text">
          هل تريد حذف منتج «{confirmDelete?.name}»؟ لن يؤثر هذا على الفواتير السابقة التي تحتوي عليه.
        </p>
        <div className="form-actions">
          <Button variant="danger" fullWidth onClick={handleDelete}>حذف نهائياً</Button>
          <Button variant="ghost" fullWidth onClick={() => setConfirmDelete(null)}>تراجع</Button>
        </div>
      </Sheet>

      <style>{`
        .page-with-nav {
          min-height: 100vh;
          padding-bottom: calc(var(--nav-h) + var(--safe-bottom) + 16px);
        }
        .products-content {
          padding: 14px 16px;
          max-width: 560px;
          margin: 0 auto;
        }
        .search-row {
          display: flex;
          gap: 10px;
          margin-bottom: 12px;
        }
        .search-box {
          flex: 1;
          display: flex;
          align-items: center;
          gap: 8px;
          background: var(--color-surface);
          border: 1.5px solid var(--color-border);
          border-radius: var(--radius-sm);
          padding: 0 14px;
          height: 48px;
        }
        .search-box svg {
          width: 19px; height: 19px;
          color: var(--color-ink-faint);
          flex-shrink: 0;
        }
        .search-box input {
          border: none; outline: none; background: transparent;
          flex: 1; font-size: 14.5px; color: var(--color-ink);
          font-family: inherit;
        }
        .add-fab {
          width: 48px; height: 48px;
          border-radius: var(--radius-sm);
          background: var(--color-primary);
          color: white; border: none;
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0; cursor: pointer;
        }
        .add-fab svg { width: 22px; height: 22px; }
        .add-fab:active { transform: scale(0.94); }

        .category-strip {
          display: flex;
          gap: 8px;
          overflow-x: auto;
          padding-bottom: 4px;
          margin-bottom: 14px;
        }
        .category-chip {
          flex-shrink: 0;
          padding: 8px 16px;
          border-radius: 999px;
          border: 1.5px solid var(--color-border);
          background: var(--color-surface);
          color: var(--color-ink-soft);
          font-size: 12.5px;
          font-weight: 700;
          cursor: pointer;
          white-space: nowrap;
        }
        .category-chip.active {
          background: var(--color-primary);
          border-color: var(--color-primary);
          color: white;
        }

        .products-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }
        .empty-state, .loading-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
          padding: 60px 24px;
          color: var(--color-ink-faint);
          text-align: center;
        }
        .empty-state svg { width: 40px; height: 40px; }
        .confirm-text {
          color: var(--color-ink-soft);
          font-size: 14px;
          line-height: 1.7;
          margin: 0 0 18px;
        }
        .form-actions {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
      `}</style>
    </div>
  );
}

function ProductCard({ product, color, onEdit, onDelete }) {
  return (
    <div className="product-card drop-corner" style={{ '--cat-color': color }}>
      <div className="product-card-top">
        <span className="product-category-dot" />
        <span className="product-category-name">{product.category || 'بدون فئة'}</span>
      </div>
      <span className="product-name">{product.name}</span>
      <div className="product-card-bottom">
        <div className="product-price-block">
          <span className="product-price">{formatCurrency(product.price)}</span>
          <span className="product-unit">/ {product.unit}</span>
        </div>
        <div className="product-actions">
          <button onClick={onEdit} aria-label="تعديل"><EditIcon /></button>
          <button onClick={onDelete} aria-label="حذف" className="danger"><TrashIcon /></button>
        </div>
      </div>

      <style>{`
        .product-card {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-top: 3px solid var(--cat-color);
          padding: 14px 14px 12px;
          display: flex;
          flex-direction: column;
          gap: 8px;
          box-shadow: var(--shadow-card);
        }
        .product-card-top {
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .product-category-dot {
          width: 7px; height: 7px;
          border-radius: 50%;
          background: var(--cat-color);
          flex-shrink: 0;
        }
        .product-category-name {
          font-size: 10.5px;
          color: var(--color-ink-faint);
          font-weight: 600;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .product-name {
          font-size: 13.5px;
          font-weight: 700;
          color: var(--color-ink);
          line-height: 1.4;
          min-height: 38px;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .product-card-bottom {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-top: 4px;
        }
        .product-price-block {
          display: flex;
          flex-direction: column;
        }
        .product-price {
          font-weight: 800;
          font-size: 14px;
          color: var(--color-primary);
        }
        .product-unit {
          font-size: 10.5px;
          color: var(--color-ink-faint);
        }
        .product-actions {
          display: flex;
          gap: 4px;
        }
        .product-actions button {
          width: 30px; height: 30px;
          border-radius: 8px;
          border: none;
          background: var(--color-bg-sunken);
          color: var(--color-ink-soft);
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
        }
        .product-actions button.danger {
          color: var(--color-danger);
          background: rgba(200,30,30,0.08);
        }
        .product-actions svg { width: 14px; height: 14px; }
      `}</style>
    </div>
  );
}

function ProductForm({ product, onSubmit, onCancel }) {
  const [name, setName] = useState(product?.name || '');
  const [price, setPrice] = useState(product?.price ?? '');
  const [unit, setUnit] = useState(product?.unit || 'حبة');
  const [category, setCategory] = useState(product?.category || '');
  const [error, setError] = useState('');

  function submit(e) {
    e.preventDefault();
    if (!name.trim()) { setError('اسم المنتج مطلوب'); return; }
    if (!price || Number(price) <= 0) { setError('السعر يجب أن يكون أكبر من صفر'); return; }
    onSubmit({ name, price, unit, category });
  }

  return (
    <form onSubmit={submit}>
      <Field label="اسم المنتج" error={error}>
        <Input
          value={name}
          onChange={(e) => { setName(e.target.value); setError(''); }}
          placeholder="مثال: منظف أطباق كادي ليمون 1 لتر"
          autoFocus
        />
      </Field>
      <div className="form-row">
        <Field label="السعر (ر.ي)">
          <Input
            value={price}
            onChange={(e) => { setPrice(e.target.value); setError(''); }}
            type="number"
            inputMode="decimal"
            placeholder="0"
          />
        </Field>
        <Field label="وحدة القياس">
          <Input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="حبة / كرتون" />
        </Field>
      </div>
      <Field label="الفئة" hint="مثال: منظف أطباق، مساحيق غسيل، معطرات">
        <Input value={category} onChange={(e) => setCategory(e.target.value)} placeholder="فئة المنتج" />
      </Field>
      <div className="form-actions">
        <Button type="submit" fullWidth>{product ? 'حفظ التعديلات' : 'إضافة المنتج'}</Button>
        <Button type="button" variant="ghost" fullWidth onClick={onCancel}>إلغاء</Button>
      </div>
      <style>{`
        .form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }
        .form-actions {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-top: 6px;
        }
      `}</style>
    </form>
  );
}
