import React from 'react';

/**
 * بطاقة كبيرة بزاوية "قطرة" مقصوصة — العنصر التوقيعي للتطبيق.
 * خلفية بتدرج أحمر مليء (لا أبيض باهت) لتباين قوي وسهولة تمييز فورية
 * تحت أشعة الشمس القوية أثناء العمل الميداني.
 * tone: 'primary' | 'amber' | 'red' | 'neutral'
 */
export default function BigCard({ icon, label, sublabel, tone = 'neutral', onClick, badge }) {
  return (
    <button className={`big-card tone-${tone} drop-corner`} onClick={onClick}>
      {badge ? <span className="big-card-badge">{badge}</span> : null}
      <span className="big-card-icon">{icon}</span>
      <span className="big-card-label">{label}</span>
      {sublabel ? <span className="big-card-sublabel">{sublabel}</span> : null}

      <style>{`
        .big-card {
          position: relative;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 10px;
          padding: 22px 14px 26px;
          border: none;
          cursor: pointer;
          min-height: 140px;
          width: 100%;
          box-shadow: var(--shadow-card);
          transition: transform 0.12s ease, box-shadow 0.12s ease;
          text-align: center;
        }
        .big-card:active {
          transform: scale(0.96);
          box-shadow: var(--shadow-pressed);
        }
        .big-card-icon {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(255,255,255,0.22);
        }
        .big-card-icon svg {
          width: 28px;
          height: 28px;
          color: #ffffff;
        }

        /* تدرجات أحمر غامقة متفاوتة الشدة لتمييز نوع العملية مع بقاء التباين قوياً للجميع */
        .tone-primary {
          background: linear-gradient(160deg, #D6342E 0%, #A81E1E 100%);
        }
        .tone-red {
          background: linear-gradient(160deg, #A81E1E 0%, #6E1212 100%);
        }
        .tone-amber {
          background: linear-gradient(160deg, #D68A1E 0%, #A8650E 100%);
        }
        .tone-maroon {
          background: linear-gradient(160deg, #8B2640 0%, #5C1729 100%);
        }
        .tone-neutral {
          background: linear-gradient(160deg, #5A4A45 0%, #3A2E2A 100%);
        }

        .big-card-label {
          font-weight: 800;
          font-size: 15.5px;
          color: #ffffff;
        }
        .big-card-sublabel {
          font-size: 12px;
          color: rgba(255,255,255,0.85);
          font-weight: 600;
        }
        .big-card-badge {
          position: absolute;
          top: 10px;
          inset-inline-end: 10px;
          background: #ffffff;
          color: var(--color-primary-dark);
          font-size: 11px;
          font-weight: 800;
          min-width: 20px;
          height: 20px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0 6px;
        }
      `}</style>
    </button>
  );
}
