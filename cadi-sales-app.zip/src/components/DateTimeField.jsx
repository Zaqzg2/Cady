import React from 'react';

/**
 * حقل تعديل التاريخ والوقت يدوياً — يحوّل بين ISO string وصيغة input[type=datetime-local].
 * يُستخدم عند تعديل فاتورة/سند لتصحيح وقت العملية الفعلي إن أخطأ المندوب بتسجيله وقتها.
 */
export default function DateTimeField({ value, onChange }) {
  const localValue = isoToLocalInputValue(value);

  function handleChange(e) {
    const newIso = localInputValueToIso(e.target.value);
    if (newIso) onChange(newIso);
  }

  return (
    <input
      type="datetime-local"
      className="datetime-field"
      value={localValue}
      onChange={handleChange}
      style={{
        height: 48,
        padding: '0 14px',
        borderRadius: 'var(--radius-sm)',
        border: '1.5px solid var(--color-border)',
        background: 'var(--color-surface)',
        color: 'var(--color-ink)',
        fontSize: 14,
        width: '100%',
        fontFamily: 'inherit',
      }}
    />
  );
}

function isoToLocalInputValue(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function localInputValueToIso(localValue) {
  if (!localValue) return null;
  const d = new Date(localValue);
  if (isNaN(d.getTime())) return null;
  return d.toISOString();
}
