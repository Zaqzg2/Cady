import React, { useRef, useState } from 'react';
import { Button } from './ui';
import Sheet from './Sheet';
import { DownloadIcon, CheckIcon } from './Icons';
import { downloadBackupFile, readBackupFile, restoreFromBackup, mergeFromBackup } from '../db/backup';
import { useToast } from './Toast';

/**
 * قسم النسخ الاحتياطي الكامل ضمن صفحة الإعدادات.
 * - تصدير: يولّد ملف JSON يحتوي كل بيانات التطبيق ويُنزّله على الهاتف فوراً.
 * - استيراد: يقرأ ملف JSON سابق، ويعرض نمطين (استبدال كامل / دمج) مع تحذير واضح،
 *   ولا يُنفّذ أي تغيير فعلي قبل تأكيد صريح من المستخدم.
 */
export default function BackupSection() {
  const showToast = useToast();
  const fileInputRef = useRef(null);

  const [exporting, setExporting] = useState(false);
  const [pendingBackup, setPendingBackup] = useState(null); // الملف المقروء بانتظار اختيار وضع الاستيراد
  const [importMode, setImportMode] = useState(null); // 'replace' | 'merge'
  const [importing, setImporting] = useState(false);

  async function handleExport() {
    setExporting(true);
    try {
      const backup = await downloadBackupFile();
      showToast(`تم تصدير ${backup.counts.customers} عميل و ${backup.counts.invoices} فاتورة و ${backup.counts.receipts} سند بنجاح`);
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء تصدير النسخة الاحتياطية', 'error');
    } finally {
      setExporting(false);
    }
  }

  function handleFileSelected(e) {
    const file = e.target.files?.[0];
    e.target.value = ''; // لإتاحة اختيار نفس الملف مرة أخرى لاحقاً إن لزم
    if (!file) return;

    readBackupFile(file)
      .then((parsed) => setPendingBackup(parsed))
      .catch((err) => showToast(err.message, 'error'));
  }

  async function handleConfirmImport() {
    if (!pendingBackup || !importMode) return;
    setImporting(true);
    try {
      if (importMode === 'replace') {
        await restoreFromBackup(pendingBackup);
      } else {
        await mergeFromBackup(pendingBackup);
      }
      showToast('تم استيراد النسخة الاحتياطية بنجاح');
      setPendingBackup(null);
      setImportMode(null);
      // إعادة تحميل الصفحة لضمان تحديث كل الاستعلامات المعروضة في كل الصفحات
      setTimeout(() => window.location.reload(), 800);
    } catch (e) {
      console.error(e);
      showToast('حدث خطأ أثناء الاستيراد — لم يتم تغيير أي بيانات', 'error');
      setImporting(false);
    }
  }

  const counts = pendingBackup?.counts;

  return (
    <>
      <div className="backup-actions">
        <Button fullWidth icon={<DownloadIcon />} onClick={handleExport} disabled={exporting}>
          {exporting ? 'جاري التصدير...' : 'تصدير نسخة احتياطية الآن'}
        </Button>
        <Button fullWidth variant="secondary" onClick={() => fileInputRef.current?.click()}>
          استيراد من ملف نسخة احتياطية
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept="application/json,.json"
          onChange={handleFileSelected}
          style={{ display: 'none' }}
        />
      </div>

      <p className="backup-hint">
        التصدير يحفظ كل العملاء والمنتجات والفواتير والسندات وكشوف الحساب في ملف واحد على هاتفك.
        احتفظ بهذا الملف في مكان آمن (مثل بريدك الإلكتروني أو التخزين السحابي) بشكل دوري لحماية بياناتك من الضياع.
      </p>

      <Sheet
        open={!!pendingBackup}
        onClose={() => { setPendingBackup(null); setImportMode(null); }}
        title="استيراد نسخة احتياطية"
      >
        {counts ? (
          <>
            <div className="backup-file-summary">
              <p className="backup-file-summary-title">محتوى الملف المُحدَّد:</p>
              <ul>
                <li>👥 {counts.customers} عميل</li>
                <li>📦 {counts.products} منتج</li>
                <li>📄 {counts.invoices} فاتورة</li>
                <li>🧾 {counts.receipts} سند قبض</li>
              </ul>
            </div>

            <p className="backup-mode-label">اختر طريقة الاستيراد:</p>

            <button
              className={`backup-mode-option ${importMode === 'merge' ? 'active' : ''}`}
              onClick={() => setImportMode('merge')}
            >
              <div className="backup-mode-option-header">
                {importMode === 'merge' ? <CheckIcon /> : null}
                <span>دمج مع البيانات الحالية</span>
              </div>
              <span className="backup-mode-option-desc">
                يضيف بيانات الملف كعملاء وفواتير جديدة، دون حذف أي شيء موجود حالياً. مناسب لاستعادة بيانات من جهاز آخر.
              </span>
            </button>

            <button
              className={`backup-mode-option danger ${importMode === 'replace' ? 'active' : ''}`}
              onClick={() => setImportMode('replace')}
            >
              <div className="backup-mode-option-header">
                {importMode === 'replace' ? <CheckIcon /> : null}
                <span>⚠️ استبدال كامل البيانات الحالية</span>
              </div>
              <span className="backup-mode-option-desc">
                يحذف كل العملاء والفواتير والسندات الموجودة حالياً على هذا الجهاز نهائياً، ويستعيد فقط بيانات هذا الملف. لا يمكن التراجع عن هذا.
              </span>
            </button>

            <div className="backup-confirm-actions">
              <Button
                fullWidth
                variant={importMode === 'replace' ? 'danger' : 'primary'}
                onClick={handleConfirmImport}
                disabled={!importMode || importing}
              >
                {importing ? 'جاري الاستيراد...' : 'تأكيد الاستيراد'}
              </Button>
              <Button fullWidth variant="ghost" onClick={() => { setPendingBackup(null); setImportMode(null); }} disabled={importing}>
                إلغاء
              </Button>
            </div>
          </>
        ) : null}
      </Sheet>

      <style>{`
        .backup-actions {
          display: flex;
          flex-direction: column;
          gap: 10px;
          margin-bottom: 12px;
        }
        .backup-hint {
          font-size: 11.5px;
          color: var(--color-ink-faint);
          line-height: 1.7;
          margin: 0;
        }
        .backup-file-summary {
          background: var(--color-surface-2);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 12px 14px;
          margin-bottom: 16px;
        }
        .backup-file-summary-title {
          font-weight: 700;
          font-size: 13px;
          margin: 0 0 8px;
          color: var(--color-ink);
        }
        .backup-file-summary ul {
          list-style: none;
          margin: 0;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 4px;
          font-size: 13px;
          color: var(--color-ink-soft);
        }
        .backup-mode-label {
          font-size: 12.5px;
          font-weight: 700;
          color: var(--color-ink-soft);
          margin: 0 0 8px;
        }
        .backup-mode-option {
          display: flex;
          flex-direction: column;
          gap: 4px;
          width: 100%;
          text-align: start;
          background: var(--color-surface);
          border: 1.5px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 12px 14px;
          margin-bottom: 10px;
          cursor: pointer;
        }
        .backup-mode-option.active {
          border-color: var(--color-primary);
          background: rgba(200,30,30,0.04);
        }
        .backup-mode-option.danger.active {
          border-color: var(--color-danger);
          background: rgba(200,30,30,0.06);
        }
        .backup-mode-option-header {
          display: flex;
          align-items: center;
          gap: 6px;
          font-weight: 700;
          font-size: 13.5px;
          color: var(--color-ink);
        }
        .backup-mode-option-header svg {
          width: 15px; height: 15px;
          color: var(--color-primary);
          flex-shrink: 0;
        }
        .backup-mode-option.danger .backup-mode-option-header svg {
          color: var(--color-danger);
        }
        .backup-mode-option-desc {
          font-size: 11.5px;
          color: var(--color-ink-faint);
          line-height: 1.6;
        }
        .backup-confirm-actions {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-top: 6px;
        }
      `}</style>
    </>
  );
}
