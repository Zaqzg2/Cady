import React, { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import Sheet from './Sheet';
import { Button } from './ui';
import { SearchIcon, PlusIcon, MinusIcon, CheckIcon } from './Icons';
import { db } from '../db/db';
import { formatCurrency } from '../utils/format';

const CATEGORY_COLORS = ['#C81E1E', '#D6A015', '#2E7D5B', '#3D6FB4', '#8A4FB4', '#B45A2E'];
function colorForCategory(category) {
  if (!category) return CATEGORY_COLORS[0];
  let hash = 0;
  for (let i = 0; i < category.length; i++) hash = (hash * 31 + category.charCodeAt(i)) >>> 0;
  return CATEGORY_COLORS[hash % CATEGORY_COLORS.length];
}

/**
 * منتقي المنتجات — يدعم طريقتين للإضافة معاً:
 *  1. نقرة واحدة على البطاقة تضيف قطعة فوراً (إضافة سريعة).
 *  2. أزرار +/- تظهر بعد الإضافة الأولى لضبط الكمية مباشرة دون إغلاق النافذة.
 * النافذة تبقى مفتوحة بين الإضافات المتعددة؛ المستخدم يغلقها بنفسه بزر "تم".
 *
 * currentItems: عناصر الفاتورة الحالية [{productId, qty, ...}] لعرض الكمية المضافة فعلياً على كل بطاقة.
 */
export default function ProductPicker({ open, onClose, onAdd, onIncrease, onDecrease, currentItems = [] }) {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('الكل');
  const products = useLiveQuery(() => db.products.orderBy('name').toArray(), []);

  const qtyMap = useMemo(() => {
    const map = {};
    for (const it of currentItems) map[it.productId] = it.qty;
    return map;
  }, [currentItems]);

  const categories = useMemo(() => {
    if (!products) return ['الكل'];
    const set = new Set(products.map((p) => p.category || 'بدون فئة'));
    return ['الكل', ...Array.from(set)];
  }, [products]);

  const filtered = useMemo(() => {
    if (!products) return [];
    let list = products;
    if (activeCategory !== 'الكل') {
      list = list.filter((p) => (p.category || 'بدون فئة') === activeCategory);
    }
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q));
    }
    return list;
  }, [products, activeCategory, query]);

  const totalAddedCount = currentItems.reduce((s, it) => s + it.qty, 0);

  return (
    <Sheet open={open} onClose={onClose} title="إضافة منتجات" maxHeight="85vh">
      <div className="picker-search">
        <SearchIcon />
        <input
          type="text"
          placeholder="بحث عن منتج (اختياري)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {categories.length > 2 ? (
        <div className="picker-category-strip no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              className={`picker-category-chip ${activeCategory === cat ? 'active' : ''}`}
              onClick={() => setActiveCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      ) : null}

      <div className="product-picker-grid">
        {filtered.map((p) => {
          const qty = qtyMap[p.id] || 0;
          return (
            <div
              key={p.id}
              className={`product-pick-card drop-corner-sm ${qty > 0 ? 'added' : ''}`}
              style={{ '--cat-color': colorForCategory(p.category) }}
            >
              {qty > 0 ? <span className="pick-card-badge"><CheckIcon /></span> : null}
              <span className="pick-card-name">{p.name}</span>
              <span className="pick-card-price">{formatCurrency(p.price)} <span className="pick-card-unit">/ {p.unit}</span></span>

              {qty > 0 ? (
                <div className="pick-card-qty-row">
                  <button className="qty-btn" onClick={() => onDecrease(p)} aria-label="تقليل"><MinusIcon /></button>
                  <span className="qty-value">{qty}</span>
                  <button className="qty-btn" onClick={() => onIncrease(p)} aria-label="زيادة"><PlusIcon /></button>
                </div>
              ) : (
                <button className="pick-card-add-btn" onClick={() => onAdd(p)}>
                  <PlusIcon /> إضافة
                </button>
              )}
            </div>
          );
        })}
        {filtered.length === 0 ? <p className="picker-empty">لا توجد منتجات مطابقة</p> : null}
      </div>

      <div className="picker-footer">
        <Button fullWidth onClick={onClose}>
          {totalAddedCount > 0 ? `تم — ${totalAddedCount} قطعة مضافة` : 'إغلاق'}
        </Button>
      </div>

      <style>{`
        .picker-search {
          display: flex;
          align-items: center;
          gap: 8px;
          background: var(--color-surface-2);
          border: 1.5px solid var(--color-border);
          border-radius: var(--radius-sm);
          padding: 0 14px;
          height: 46px;
          margin-bottom: 10px;
        }
        .picker-search svg { width: 18px; height: 18px; color: var(--color-ink-faint); flex-shrink: 0; }
        .picker-search input {
          border: none; outline: none; background: transparent;
          flex: 1; font-size: 14.5px; color: var(--color-ink); font-family: inherit;
        }
        .picker-category-strip {
          display: flex;
          gap: 6px;
          overflow-x: auto;
          margin-bottom: 12px;
        }
        .picker-category-chip {
          flex-shrink: 0;
          padding: 6px 14px;
          border-radius: 999px;
          border: 1.5px solid var(--color-border);
          background: var(--color-surface);
          color: var(--color-ink-soft);
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          white-space: nowrap;
        }
        .picker-category-chip.active {
          background: var(--color-primary);
          border-color: var(--color-primary);
          color: white;
        }
        .product-picker-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          max-height: 50vh;
          overflow-y: auto;
          padding-bottom: 4px;
        }
        .product-pick-card {
          position: relative;
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          gap: 6px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-top: 3px solid var(--cat-color);
          padding: 12px;
          text-align: start;
          min-height: 110px;
        }
        .product-pick-card.added {
          background: var(--color-surface-2);
          border-color: var(--color-primary);
        }
        .pick-card-badge {
          position: absolute;
          top: 8px;
          inset-inline-end: 8px;
          width: 18px; height: 18px;
          border-radius: 50%;
          background: var(--color-primary);
          color: white;
          display: flex; align-items: center; justify-content: center;
        }
        .pick-card-badge svg { width: 11px; height: 11px; }
        .pick-card-name {
          font-size: 12.5px;
          font-weight: 700;
          color: var(--color-ink);
          line-height: 1.35;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .pick-card-price {
          font-weight: 800;
          font-size: 12.5px;
          color: var(--color-primary);
          margin-top: auto;
        }
        .pick-card-unit {
          font-size: 10px;
          color: var(--color-ink-faint);
          font-weight: 600;
        }
        .pick-card-add-btn {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 4px;
          height: 32px;
          border: none;
          border-radius: var(--radius-sm);
          background: var(--color-primary);
          color: white;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
        }
        .pick-card-add-btn svg { width: 13px; height: 13px; }
        .pick-card-add-btn:active { transform: scale(0.96); }
        .pick-card-qty-row {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 6px;
        }
        .qty-btn {
          width: 30px; height: 30px;
          border-radius: 8px;
          border: none;
          background: var(--color-bg-sunken);
          color: var(--color-primary);
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          flex-shrink: 0;
        }
        .qty-btn:active { transform: scale(0.9); }
        .qty-btn svg { width: 14px; height: 14px; }
        .qty-value {
          flex: 1;
          text-align: center;
          font-weight: 800;
          font-size: 15px;
          color: var(--color-ink);
        }
        .picker-empty {
          grid-column: 1 / -1;
          text-align: center;
          padding: 30px 0;
          color: var(--color-ink-faint);
          font-size: 13px;
        }
        .picker-footer {
          position: sticky;
          bottom: 0;
          background: var(--color-bg-elevated);
          padding-top: 10px;
          margin-top: 4px;
        }
      `}</style>
    </Sheet>
  );
}
