import React from 'react';
import { PlusIcon, MinusIcon, TrashIcon } from './Icons';
import { formatCurrency } from '../utils/format';

export default function InvoiceLineItem({ item, onIncrease, onDecrease, onRemove, onPriceChange }) {
  const lineTotal = item.qty * item.price;
  const isNegativePrice = item.price < 0;

  return (
    <div className="line-item">
      <div className="line-item-info">
        <span className="line-item-name">{item.name}</span>
        <div className="line-item-price-edit">
          <input
            type="number"
            inputMode="decimal"
            value={item.price}
            className={isNegativePrice ? 'price-negative' : ''}
            onChange={(e) => onPriceChange(Number(e.target.value) || 0)}
          />
          <span>ر.ي / {item.unit}</span>
        </div>
        {isNegativePrice ? (
          <span className="negative-warning">⚠️ السعر سالب — تحقق أن هذا مقصود</span>
        ) : null}
      </div>

      <div className="line-item-qty">
        <button onClick={onDecrease} aria-label="تقليل الكمية"><MinusIcon /></button>
        <span className="qty-value">{item.qty}</span>
        <button onClick={onIncrease} aria-label="زيادة الكمية"><PlusIcon /></button>
      </div>

      <div className="line-item-total">
        <span>{formatCurrency(lineTotal)}</span>
        <button className="remove-btn" onClick={onRemove} aria-label="حذف المنتج">
          <TrashIcon />
        </button>
      </div>

      <style>{`
        .line-item {
          display: flex;
          align-items: center;
          gap: 10px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-sm);
          padding: 10px 12px;
        }
        .line-item-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 4px;
          min-width: 0;
        }
        .line-item-name {
          font-size: 13px;
          font-weight: 700;
          color: var(--color-ink);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .line-item-price-edit {
          display: flex;
          align-items: center;
          gap: 4px;
        }
        .line-item-price-edit input {
          width: 64px;
          height: 26px;
          border: 1px solid var(--color-border);
          border-radius: 6px;
          background: var(--color-surface-2);
          font-size: 11.5px;
          padding: 0 6px;
          color: var(--color-ink-soft);
          font-family: inherit;
        }
        .line-item-price-edit span {
          font-size: 10.5px;
          color: var(--color-ink-faint);
        }
        .line-item-price-edit input.price-negative {
          border-color: var(--color-danger);
          color: var(--color-danger);
          font-weight: 700;
        }
        .negative-warning {
          font-size: 10.5px;
          color: var(--color-danger);
          font-weight: 700;
        }
        .line-item-qty {
          display: flex;
          align-items: center;
          gap: 6px;
          flex-shrink: 0;
        }
        .line-item-qty button {
          width: 30px; height: 30px;
          border-radius: 8px;
          border: none;
          background: var(--color-bg-sunken);
          color: var(--color-primary);
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
        }
        .line-item-qty button:active { transform: scale(0.9); }
        .line-item-qty svg { width: 15px; height: 15px; }
        .qty-value {
          min-width: 22px;
          text-align: center;
          font-weight: 800;
          font-size: 14px;
          color: var(--color-ink);
        }
        .line-item-total {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 4px;
          flex-shrink: 0;
          min-width: 64px;
        }
        .line-item-total span:first-child {
          font-weight: 800;
          font-size: 13px;
          color: var(--color-primary);
          white-space: nowrap;
        }
        .remove-btn {
          width: 22px; height: 22px;
          border: none;
          background: transparent;
          color: var(--color-ink-faint);
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
        }
        .remove-btn svg { width: 14px; height: 14px; }
        .remove-btn:active { color: var(--color-danger); }
      `}</style>
    </div>
  );
}
