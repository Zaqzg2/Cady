import React from 'react';

export function Button({ children, variant = 'primary', size = 'md', fullWidth, icon, ...rest }) {
  return (
    <button className={`btn btn-${variant} btn-${size} ${fullWidth ? 'btn-full' : ''}`} {...rest}>
      {icon ? <span className="btn-icon">{icon}</span> : null}
      <span>{children}</span>

      <style>{`
        .btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          border: none;
          border-radius: var(--radius-sm);
          font-weight: 700;
          cursor: pointer;
          transition: transform 0.1s ease, opacity 0.1s ease;
          font-family: inherit;
          white-space: nowrap;
        }
        .btn:active { transform: scale(0.97); }
        .btn:disabled { opacity: 0.45; cursor: not-allowed; }
        .btn-full { width: 100%; }

        .btn-sm { height: 38px; padding: 0 14px; font-size: 13px; }
        .btn-md { height: var(--tap-min); padding: 0 18px; font-size: 14.5px; }
        .btn-lg { height: 56px; padding: 0 22px; font-size: 16px; }

        .btn-primary { background: var(--color-primary); color: #fff; }
        .btn-secondary { background: var(--color-bg-sunken); color: var(--color-ink); }
        .btn-outline { background: transparent; color: var(--color-primary); border: 1.5px solid var(--color-primary); }
        .btn-danger { background: var(--color-danger); color: #fff; }
        .btn-ghost { background: transparent; color: var(--color-ink-soft); }

        .btn-icon svg { width: 18px; height: 18px; display: block; }
      `}</style>
    </button>
  );
}

export function Field({ label, children, hint, error }) {
  return (
    <div className="field">
      {label ? <label className="field-label">{label}</label> : null}
      {children}
      {hint && !error ? <span className="field-hint">{hint}</span> : null}
      {error ? <span className="field-error">{error}</span> : null}

      <style>{`
        .field {
          display: flex;
          flex-direction: column;
          gap: 6px;
          margin-bottom: 16px;
        }
        .field-label {
          font-size: 13px;
          font-weight: 700;
          color: var(--color-ink-soft);
        }
        .field-hint {
          font-size: 12px;
          color: var(--color-ink-faint);
        }
        .field-error {
          font-size: 12px;
          color: var(--color-danger);
          font-weight: 600;
        }
      `}</style>
    </div>
  );
}

export function Input({ className = '', ...rest }) {
  return (
    <>
      <input className={`input ${className}`} {...rest} />
      <style>{`
        .input {
          height: 48px;
          padding: 0 14px;
          border-radius: var(--radius-sm);
          border: 1.5px solid var(--color-border);
          background: var(--color-surface);
          color: var(--color-ink);
          font-size: 15px;
          width: 100%;
          transition: border-color 0.15s ease;
        }
        .input:focus {
          border-color: var(--color-primary);
        }
        .input::placeholder {
          color: var(--color-ink-faint);
        }
      `}</style>
    </>
  );
}

export function Textarea(props) {
  return (
    <>
      <textarea className="textarea" {...props} />
      <style>{`
        .textarea {
          padding: 12px 14px;
          border-radius: var(--radius-sm);
          border: 1.5px solid var(--color-border);
          background: var(--color-surface);
          color: var(--color-ink);
          font-size: 15px;
          width: 100%;
          min-height: 80px;
          resize: vertical;
          font-family: inherit;
        }
        .textarea:focus {
          border-color: var(--color-primary);
        }
      `}</style>
    </>
  );
}
