import React from 'react';

export default function Toggle({ checked, onChange, label }) {
  return (
    <div className="toggle-row">
      <span className="toggle-label">{label}</span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        className={`toggle-switch ${checked ? 'on' : ''}`}
        onClick={() => onChange(!checked)}
      >
        <span className="toggle-knob" />
      </button>

      <style>{`
        .toggle-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 0;
        }
        .toggle-label {
          font-size: 13.5px;
          color: var(--color-ink);
          font-weight: 600;
        }
        .toggle-switch {
          width: 48px;
          height: 28px;
          border-radius: 999px;
          background: var(--color-border-strong);
          border: none;
          position: relative;
          cursor: pointer;
          flex-shrink: 0;
          transition: background 0.2s ease;
        }
        .toggle-switch.on {
          background: var(--color-primary);
        }
        .toggle-knob {
          position: absolute;
          top: 3px;
          right: 3px;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background: white;
          transition: transform 0.2s ease;
          box-shadow: 0 1px 3px rgba(0,0,0,0.25);
        }
        .toggle-switch.on .toggle-knob {
          transform: translateX(-20px);
        }
      `}</style>
    </div>
  );
}
