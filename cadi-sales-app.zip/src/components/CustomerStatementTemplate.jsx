import React from 'react';
import logoMark from '../assets/logo-full.png';
import { formatCurrency, formatDateTime, formatDateShort } from '../utils/format';

const TYPE_LABELS = {
  invoice_sale: 'فاتورة بيع',
  invoice_return: 'مرتجع',
  receipt: 'سند قبض',
  opening: 'رصيد افتتاحي',
};

const FONT_SIZES = {
  small: { base: 15, header: 18, label: 14 },
  normal: { base: 17, header: 20, label: 15.5 },
  large: { base: 19.5, header: 23, label: 17.5 },
};

/**
 * قالب كشف حساب كامل لعميل واحد — بنفس صيغة إيصال 80مم وبنفس أسلوب الترويسة
 * الموحّد المستخدم في الفاتورة والسند (انظر ReceiptTemplate)، لاتساق كل المستندات المطبوعة.
 * ledgerEntries يجب أن تكون مرتّبة تصاعدياً بالتاريخ (الأقدم أولاً).
 */
export default function CustomerStatementTemplate({ customer, ledgerEntries, settings }) {
  const layout = settings.invoiceLayout;
  const sizes = FONT_SIZES[layout.fontSize] || FONT_SIZES.normal;
  const sortedAsc = [...ledgerEntries].sort((a, b) => new Date(a.date) - new Date(b.date));
  const currentBalance = customer.balance || 0;

  return (
    <div className="statement-paper" style={{ fontSize: `${sizes.base}px`, width: `${layout.paperWidth}mm` }}>
      <div className="statement-header">
        {layout.showLogo ? (
          <img src={logoMark} alt={settings.company.name} className="statement-logo" />
        ) : null}
        <div className="statement-company-name" style={{ fontSize: `${sizes.header}px` }}>{settings.company.name}</div>
        {settings.company.address ? <div className="statement-subline">{settings.company.address}</div> : null}
      </div>

      <div className="statement-divider thick" />

      <div className="statement-title" style={{ fontSize: `${sizes.header}px` }}>كشف حساب عميل</div>

      <div className="statement-divider" />

      <div className="statement-field-grid" style={{ fontSize: `${sizes.label}px` }}>
        <FieldRow label="اسم العميل" value={customer.name} />
        {customer.phone ? <FieldRow label="الهاتف" value={customer.phone} /> : null}
        {customer.area && customer.area !== '—' ? <FieldRow label="المنطقة" value={customer.area} /> : null}
        <FieldRow label="تاريخ الكشف" value={formatDateTime(new Date().toISOString())} />
      </div>

      <div className="statement-divider thick" />

      {sortedAsc.length === 0 ? (
        <div className="statement-empty">لا توجد حركات على هذا العميل</div>
      ) : (
        <table className="statement-table">
          <thead>
            <tr>
              <th className="col-date">التاريخ</th>
              <th className="col-desc">البيان</th>
              <th className="col-doc">رقم المستند</th>
              <th className="col-debit">مدين</th>
              <th className="col-credit">دائن</th>
              <th className="col-balance">الرصيد</th>
            </tr>
          </thead>
          <tbody>
            {sortedAsc.map((entry) => (
              <tr key={entry.id}>
                <td className="col-date">{formatDateShort(entry.date)}</td>
                <td className="col-desc">{entry.note || TYPE_LABELS[entry.type] || entry.type}</td>
                <td className="col-doc">{entry.documentNumber ?? entry.refId ?? '—'}</td>
                <td className="col-debit">{entry.debit > 0 ? formatNum(entry.debit) : '—'}</td>
                <td className="col-credit">{entry.credit > 0 ? formatNum(entry.credit) : '—'}</td>
                <td className="col-balance">{formatNum(entry.balanceAfter)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div className="statement-divider thick" />

      <div className="statement-summary" style={{ fontSize: `${sizes.header}px` }}>
        <span>
          {currentBalance > 0 ? 'الرصيد الحالي (مديون)' : currentBalance < 0 ? 'الرصيد الحالي (له رصيد)' : 'الرصيد الحالي'}
        </span>
        <span>{formatCurrency(Math.abs(currentBalance))}</span>
      </div>

      <div className="statement-divider thick" />
      <div className="statement-footer">{settings.company.footerNote}</div>

      <style>{`
        .statement-paper {
          background: #ffffff;
          color: #161010;
          padding: 14px 10px;
          margin: 0 auto;
          font-family: var(--font-body), 'Cairo', sans-serif;
          direction: rtl;
        }
        .statement-header {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
        }
        .statement-logo {
          height: 64px;
          object-fit: contain;
          margin-bottom: 2px;
        }
        .statement-company-name {
          text-align: center;
          font-weight: 800;
        }
        .statement-subline {
          font-size: 0.85em;
          color: #555;
        }
        .statement-divider {
          border-top: 1px dashed #888;
          margin: 7px 0;
        }
        .statement-divider.thick {
          border-top: 1.5px solid #161010;
        }
        .statement-title {
          text-align: center;
          font-weight: 800;
        }
        .statement-field-grid {
          display: flex;
          flex-direction: column;
          gap: 3px;
        }
        .field-row {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          gap: 10px;
        }
        .field-row-label {
          color: #555;
          font-weight: 600;
          flex-shrink: 0;
        }
        .field-row-value {
          font-weight: 700;
          color: #161010;
          text-align: left;
          direction: ltr;
          unicode-bidi: plaintext;
        }
        .statement-empty {
          text-align: center;
          color: #888;
          padding: 14px 0;
        }
        .statement-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 8px;
          font-size: 0.78em;
        }
        .statement-table th, .statement-table td {
          border: 1px solid #161010;
          padding: 3px 2px;
          text-align: center;
        }
        .statement-table th {
          font-weight: 800;
          background: #f1ece2;
          font-size: 0.92em;
        }
        .statement-table .col-date { width: 14%; }
        .statement-table .col-desc {
          width: 24%;
          text-align: start;
          font-size: 0.94em;
          line-height: 1.25;
        }
        .statement-table .col-doc { width: 13%; }
        .statement-table .col-debit { width: 16%; color: #C81E1E; font-weight: 700; }
        .statement-table .col-credit { width: 16%; color: #2E7D5B; font-weight: 700; }
        .statement-table .col-balance { width: 17%; font-weight: 800; }
        .amount { font-weight: 800; }
        .amount.debit { color: #C81E1E; }
        .amount.credit { color: #2E7D5B; }
        .muted { color: #666; font-size: 0.9em; }
        .statement-summary {
          display: flex;
          justify-content: space-between;
          font-weight: 800;
        }
        .statement-footer {
          text-align: center;
          font-weight: 700;
        }
      `}</style>
    </div>
  );
}

function FieldRow({ label, value }) {
  return (
    <div className="field-row">
      <span className="field-row-label">{label}</span>
      <span className="field-row-value">{value}</span>
    </div>
  );
}

function formatNum(n) {
  if (n === undefined || n === null) return '—';
  return Number(n).toLocaleString('en-US', { maximumFractionDigits: 0 });
}