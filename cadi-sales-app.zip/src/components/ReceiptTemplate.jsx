import React from 'react';
import logoMark from '../assets/logo-full.png';
import { formatCurrency, formatDateTime, invoiceNumber, receiptNumber } from '../utils/format';

const FONT_SIZES = {
  small: { base: 15, total: 19, header: 18, label: 14 },
  normal: { base: 17, total: 21, header: 20, label: 15.5 },
  large: { base: 19.5, total: 24, header: 23, label: 17.5 },
};

const COLUMN_TITLES = {
  name: 'الصنف',
  qty: 'كمية',
  price: 'سعر',
  total: 'الاجمالي',
};
const COLUMN_ORDER = ['total', 'price', 'qty', 'name'];
const DEFAULT_COLUMN_ORDER = COLUMN_ORDER;

const PAYMENT_TERM_LABELS = { cash: 'نقد', credit: 'آجل' };
const COLLECTION_METHOD_LABELS = { cash: 'نقداً', transfer: 'تحويل بنكي' };

/**
 * قالب إيصال 80مم — تخطيط عمودي (تسمية الحقل ↔ القيمة) أقرب لتصميم فواتير
 * الأنظمة التجارية التقليدية، مع جدول منتجات بحدود واضحة لسهولة القراءة في الإضاءة القوية.
 * kind: 'invoice' | 'receipt'
 */
export default function ReceiptTemplate({ kind, data, customer, settings }) {
  const layout = settings.invoiceLayout;
  const sizes = FONT_SIZES[layout.fontSize] || FONT_SIZES.normal;
  const isReturn = kind === 'invoice' && data.type === 'return';
  // ترتيب الأعمدة يأتي من إعدادات المستخدم نفسها (قابلة لإعادة الترتيب من صفحة الإعدادات)،
  // مع قائمة افتراضية احتياطية فقط إن كانت الإعدادات فاضية أو من نسخة قديمة من التطبيق.
  const visibleColumns = (layout.columns && layout.columns.length ? layout.columns : DEFAULT_COLUMN_ORDER)
    .filter((c) => COLUMN_TITLES[c]);

  const title = kind === 'invoice'
    ? `فاتورة مبيعات ${isReturn ? 'مرتجع' : (PAYMENT_TERM_LABELS[data.paymentTerm] || 'آجل')}`
    : 'سند قبض';

  return (
    <div className="receipt-paper" style={{ fontSize: `${sizes.base}px`, width: `${layout.paperWidth}mm` }}>
      <div className="receipt-header">
        {layout.showLogo ? (
          <img src={logoMark} alt={settings.company.name} className="receipt-logo" />
        ) : null}
        <div className="receipt-company-name" style={{ fontSize: `${sizes.header}px` }}>{settings.company.name}</div>
        {settings.company.address ? <div className="receipt-subline">{settings.company.address}</div> : null}
      </div>

      <div className="receipt-divider thick" />

      <div className="receipt-title" style={{ fontSize: `${sizes.header}px` }}>{title}</div>

      <div className="receipt-divider" />

      <div className="receipt-field-grid" style={{ fontSize: `${sizes.label}px` }}>
        {layout.showInvoiceNumber ? (
          <FieldRow label={`رقم ${kind === 'invoice' ? 'الفاتورة' : 'السند'}`} value={data.refNumber || data.id} />
        ) : null}
        <FieldRow label="اسم العميل" value={data.cashCustomerName || customer?.name || '—'} />
        {kind === 'invoice' && !isReturn ? (
          <FieldRow label="طريقة الدفع" value={PAYMENT_TERM_LABELS[data.paymentTerm] || 'آجل'} />
        ) : null}
        {kind === 'receipt' ? (
          <FieldRow label="طريقة التحصيل" value={COLLECTION_METHOD_LABELS[data.collectionMethod] || 'نقداً'} />
        ) : null}
        {layout.showDate ? <FieldRow label="التاريخ" value={formatDateTime(data.date)} /> : null}
        {layout.showCustomerPhone && customer?.phone ? <FieldRow label="هاتف العميل" value={customer.phone} /> : null}
        {layout.showCustomerArea && customer?.area && customer.area !== '—' ? (
          <FieldRow label="المنطقة" value={customer.area} />
        ) : null}
        <FieldRow label="المندوب" value={settings.company.repName || settings.company.name} />
      </div>

      <div className="receipt-divider thick" />

      {kind === 'invoice' ? (
        <>
          <table className="receipt-table">
            <thead>
              <tr>
                {visibleColumns.map((col) => (
                  <th key={col} className={`col-${col}`}>{COLUMN_TITLES[col]}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.items.map((item, idx) => (
                <tr key={idx} className={`row-density-${layout.rowDensity || 'normal'}`}>
                  {visibleColumns.map((col) => (
                    <td key={col} className={`col-${col}`}>
                      {col === 'name' ? item.name
                        : col === 'qty' ? item.qty
                        : col === 'price' ? formatNum(item.price)
                        : formatNum(item.qty * item.price)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>

          <div className="receipt-totals">
            <FieldRow label="الإجمالي الفرعي" value={formatCurrency(data.total)} />
            {data.discount > 0 ? <FieldRow label="الخصم" value={`- ${formatCurrency(data.discount)}`} danger /> : null}
            <div className="receipt-net-row" style={{ fontSize: `${sizes.total}px` }}>
              <span>الاجمالي</span>
              <span>{formatCurrency(data.netTotal)}</span>
            </div>
          </div>

          {data.paymentTerm !== 'cash' && customer ? (
            <div className="receipt-balance-block">
              <span>{(customer.balance || 0) >= 0 ? 'إجمالي المديونية المتبقية' : 'له رصيد دائن لدى الشركة'}</span>
              <span>{formatCurrency(Math.abs(customer.balance || 0))}</span>
            </div>
          ) : null}

          {data.notes ? <div className="receipt-notes">ملاحظات: {data.notes}</div> : null}

          <div className="receipt-signature-row">
            <div className="receipt-signature-box">
              <span className="muted">توقيع العميل بالاستلام</span>
              {data.signature ? <img src={data.signature} alt="توقيع العميل" /> : <span className="sig-placeholder">—</span>}
            </div>
          </div>
        </>
      ) : (
        <>
          <div className="receipt-amount-block" style={{ fontSize: `${sizes.total}px` }}>
            <span>المبلغ المستلم</span>
            <span>{formatCurrency(data.amount)}</span>
          </div>

          {customer ? (
            <div className="receipt-balance-block">
              <span>{(customer.balance || 0) >= 0 ? 'إجمالي المديونية المتبقية' : 'له رصيد دائن لدى الشركة'}</span>
              <span>{formatCurrency(Math.abs(customer.balance || 0))}</span>
            </div>
          ) : null}

          {data.notes ? <div className="receipt-notes">ملاحظات: {data.notes}</div> : null}
          <div className="receipt-signature-row">
            <div className="receipt-signature-box">
              <span className="muted">توقيع المندوب</span>
              {data.repSignature ? <img src={data.repSignature} alt="توقيع المندوب" /> : <span className="sig-placeholder">—</span>}
            </div>
          </div>
        </>
      )}

      <div className="receipt-divider thick" />
      <div className="receipt-footer">{settings.company.footerNote}</div>
      {settings.company.phone ? <div className="receipt-footer muted">هاتف: {settings.company.phone}</div> : null}

      <style>{`
        .receipt-paper {
          background: #ffffff;
          color: #161010;
          padding: 14px 10px;
          margin: 0 auto;
          font-family: var(--font-body), 'Cairo', sans-serif;
          direction: rtl;
        }
        .receipt-header {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
        }
        .receipt-logo {
          height: 64px;
          object-fit: contain;
          margin-bottom: 2px;
        }
        .receipt-company-name {
          text-align: center;
          font-weight: 800;
        }
        .receipt-subline {
          font-size: 0.85em;
          color: #555;
        }
        .receipt-divider {
          border-top: 1px dashed #888;
          margin: 7px 0;
        }
        .receipt-divider.thick {
          border-top: 1.5px solid #161010;
        }
        .receipt-title {
          text-align: center;
          font-weight: 800;
        }
        .receipt-field-grid {
          display: flex;
          flex-direction: column;
          gap: 3px;
        }
        .field-row {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          gap: 10px;
        }
        .field-row-label {
          color: #555;
          font-weight: 600;
          flex-shrink: 0;
        }
        .field-row-value {
          font-weight: 700;
          color: #161010;
          text-align: left;
          direction: ltr;
          unicode-bidi: plaintext;
        }
        .field-row-value.danger { color: #C81E1E; }
        .receipt-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 8px;
        }
        .receipt-table th, .receipt-table td {
          border: 1px solid #161010;
          padding: 5px 4px;
          text-align: center;
        }
        .receipt-table tr.row-density-compact td { padding: 2px 4px; }
        .receipt-table tr.row-density-spacious td { padding: 8px 4px; }
        .receipt-table th {
          font-weight: 800;
          background: #f1ece2;
        }
        .receipt-table .col-name {
          text-align: start;
        }
        .receipt-totals {
          display: flex;
          flex-direction: column;
          gap: 3px;
          margin-bottom: 6px;
        }
        .receipt-net-row {
          display: flex;
          justify-content: space-between;
          font-weight: 800;
          border-top: 1.5px solid #161010;
          margin-top: 4px;
          padding-top: 6px;
        }
        .receipt-amount-block {
          display: flex;
          justify-content: space-between;
          font-weight: 800;
          padding: 6px 0;
        }
        .receipt-balance-block {
          display: flex;
          justify-content: space-between;
          font-weight: 700;
          padding: 6px 8px;
          margin-bottom: 6px;
          background: #f1ece2;
          border: 1px dashed #161010;
        }
        .receipt-notes {
          font-size: 0.92em;
          color: #444;
          margin-bottom: 8px;
        }
        .receipt-signature-row {
          display: flex;
          justify-content: center;
          margin-top: 10px;
        }
        .receipt-signature-box {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          width: 100%;
        }
        .receipt-signature-box img {
          max-width: 70%;
          max-height: 56px;
          object-fit: contain;
        }
        .sig-placeholder {
          color: #aaa;
          font-size: 1.4em;
        }
        .muted { color: #666; font-size: 0.88em; }
        .receipt-footer {
          text-align: center;
          font-weight: 700;
        }
        .receipt-footer.muted {
          font-weight: 500;
          margin-top: 2px;
        }
      `}</style>
    </div>
  );
}

function FieldRow({ label, value, danger = false }) {
  return (
    <div className="field-row">
      <span className="field-row-label">{label}</span>
      <span className={`field-row-value ${danger ? 'danger' : ''}`}>{value}</span>
    </div>
  );
}

function formatNum(n) {
  return Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 0 });
}
