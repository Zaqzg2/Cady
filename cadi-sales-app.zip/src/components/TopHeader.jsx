import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import logoMark from '../assets/logo-full.png';
import { db } from '../db/db';

const SETTINGS_KEY = 'appSettings';

export default function TopHeader({ title, showBack = false, onBack, rightSlot }) {
  const navigate = useNavigate();
  const settingsRow = useLiveQuery(() => db.settings.get(SETTINGS_KEY), []);
  const companyName = settingsRow?.value?.company?.name || 'كادي للمنظفات';

  return (
    <header className="top-header">
      <div className="top-header-side">
        {showBack ? (
          <button className="icon-btn" onClick={onBack || (() => navigate(-1))} aria-label="رجوع">
            <BackIcon />
          </button>
        ) : (
          <div className="brand">
            <img src={logoMark} alt="كادي" className="brand-logo" />
            <span className="brand-name">{companyName}</span>
          </div>
        )}
      </div>

      <h1 className="top-header-title">{title}</h1>

      <div className="top-header-side end">
        {rightSlot !== undefined ? rightSlot : (
          <button className="icon-btn" onClick={() => navigate('/reports')} aria-label="التقارير">
            <ReportsIcon />
          </button>
        )}
      </div>

      <style>{`
        .top-header {
          position: sticky;
          top: 0;
          z-index: 40;
          height: calc(var(--header-h) + var(--safe-top));
          padding-top: var(--safe-top);
          background: var(--color-bg-elevated);
          border-bottom: 1px solid var(--color-border);
          display: flex;
          align-items: center;
          padding-inline: 8px;
        }
        .top-header-side {
          width: 56px;
          display: flex;
          align-items: center;
          overflow: visible;
        }
        .top-header-side:first-child {
          width: auto;
          min-width: 56px;
        }
        .top-header-side.end {
          justify-content: flex-end;
        }
        .top-header-title {
          flex: 1;
          text-align: center;
          font-size: 17px;
          font-weight: 700;
          color: var(--color-ink);
          margin: 0;
        }
        .brand {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .brand-logo {
          height: 34px;
          width: auto;
          object-fit: contain;
          flex-shrink: 0;
        }
        .brand-name {
          font-size: 14px;
          font-weight: 800;
          color: var(--color-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 120px;
        }
        .icon-btn {
          width: var(--tap-min);
          height: var(--tap-min);
          display: flex;
          align-items: center;
          justify-content: center;
          background: transparent;
          border: none;
          border-radius: 50%;
          color: var(--color-ink);
          cursor: pointer;
        }
        .icon-btn:active {
          background: var(--color-bg-sunken);
        }
        .icon-btn svg {
          width: 24px;
          height: 24px;
        }
      `}</style>
    </header>
  );
}

function BackIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M15 18l-7-6 7-6" />
    </svg>
  );
}
function ReportsIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 21V9M12 21V3M19 21v-7" />
    </svg>
  );
}
