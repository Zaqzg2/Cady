import React from 'react';

const props = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: '2',
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
};

export const CashIcon = () => (
  <svg {...props}>
    <rect x="2.5" y="6.5" width="19" height="12" rx="2" />
    <circle cx="12" cy="12.5" r="2.8" />
    <path d="M6 6.5v0M18 17.5v0" />
  </svg>
);

export const ReturnInvoiceIcon = () => (
  <svg {...props}>
    <path d="M4 7h11a4 4 0 0 1 4 4v1" />
    <path d="M8 3 4 7l4 4" />
    <path d="M5 21h13" />
    <path d="M8.5 17h7" />
  </svg>
);

export const SaleInvoiceIcon = () => (
  <svg {...props}>
    <path d="M6 3h9l3 3v15H6z" />
    <path d="M15 3v3h3" />
    <path d="M9 12h6M9 16h6M9 8h3" />
  </svg>
);

export const ReceiptIcon = () => (
  <svg {...props}>
    <path d="M6 2.5h12v19l-2.5-1.5L13 21.5 10.5 20 8 21.5 5.5 20 3 21.5V5a2.5 2.5 0 0 1 2.5-2.5z" />
    <path d="M8.5 8h7M8.5 11.5h7M8.5 15h4" />
  </svg>
);

export const PlusIcon = () => (
  <svg {...props}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);

export const MinusIcon = () => (
  <svg {...props}>
    <path d="M5 12h14" />
  </svg>
);

export const SearchIcon = () => (
  <svg {...props}>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </svg>
);

export const PhoneIcon = () => (
  <svg {...props}>
    <path d="M5 4h3.2l1.6 4.5L7.8 10a11 11 0 0 0 6.2 6.2l1.5-2 4.5 1.6V19a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z" />
  </svg>
);

export const EditIcon = () => (
  <svg {...props}>
    <path d="M4 17.25 4 20h2.75L19.81 6.94a1.5 1.5 0 0 0 0-2.12l-1.63-1.63a1.5 1.5 0 0 0-2.12 0Z" />
  </svg>
);

export const TrashIcon = () => (
  <svg {...props}>
    <path d="M4 7h16M9 7V4.5A1.5 1.5 0 0 1 10.5 3h3A1.5 1.5 0 0 1 15 4.5V7m2 0-.6 12.4A2 2 0 0 1 14.4 21H9.6a2 2 0 0 1-2-1.9L7 7" />
  </svg>
);

export const PrintIcon = () => (
  <svg {...props}>
    <path d="M6 9V3h12v6" />
    <rect x="4" y="9" width="16" height="8" rx="1.5" />
    <path d="M6 17h12v4H6z" />
  </svg>
);

export const ShareIcon = () => (
  <svg {...props}>
    <circle cx="18" cy="5.5" r="2.3" />
    <circle cx="6" cy="12" r="2.3" />
    <circle cx="18" cy="18.5" r="2.3" />
    <path d="m8.1 10.8 7.8-4.4M8.1 13.2l7.8 4.4" />
  </svg>
);

export const DownloadIcon = () => (
  <svg {...props}>
    <path d="M12 3v13" />
    <path d="m7 12 5 5 5-5" />
    <path d="M5 21h14" />
  </svg>
);

export const SaveIcon = () => (
  <svg {...props}>
    <path d="M5 4h11l3 3v13H5z" />
    <path d="M8 4v5h7V4M8 14h8v6" />
  </svg>
);

export const SignatureIcon = () => (
  <svg {...props}>
    <path d="M3 17c2-1 3.5-3 4-5 .6-2.4-.3-4-1.7-3.4C4 9.2 4 13 6 14.5c2 1.6 5-.3 6.7-3 1.6-2.6 3-2.8 3.6-1 .6 1.8-.7 4-2.3 4.8-1 .5-1.2 1.4-.3 1.8 1.6.8 4-.6 5.3-2.6" />
    <path d="M3 20h18" />
  </svg>
);

export const DiscountIcon = () => (
  <svg {...props}>
    <path d="M5 12 12 5l7 7-7 7-7-7Z" />
    <circle cx="9.5" cy="9.5" r="0.9" fill="currentColor" stroke="none" />
    <path d="m9 14 5-5" />
  </svg>
);

export const CustomerIcon = () => (
  <svg {...props}>
    <circle cx="12" cy="8" r="3.6" />
    <path d="M5 20c0-3.6 3-6 7-6s7 2.4 7 6" />
  </svg>
);

export const ChevronIcon = ({ dir = 'start' }) => (
  <svg {...props} style={{ transform: dir === 'end' ? 'rotate(180deg)' : undefined }}>
    <path d="M14.5 6.5 9 12l5.5 5.5" />
  </svg>
);

export const CheckIcon = () => (
  <svg {...props}>
    <path d="M4.5 12.5 9.5 18l10-12" />
  </svg>
);

export const CloseIcon = () => (
  <svg {...props}>
    <path d="M5 5l14 14M19 5 5 19" />
  </svg>
);

export const BluetoothIcon = () => (
  <svg {...props}>
    <path d="M7 7.5 17 15l-5 4V5l5 4-10 7.5" />
  </svg>
);

export const MoonIcon = () => (
  <svg {...props}>
    <path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5Z" />
  </svg>
);

export const SunIcon = () => (
  <svg {...props}>
    <circle cx="12" cy="12" r="4.5" />
    <path d="M12 2.5v2M12 19.5v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2.5 12h2M19.5 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4" />
  </svg>
);

export const LedgerIcon = () => (
  <svg {...props}>
    <path d="M6 3h12v18l-3-2-3 2-3-2-3 2z" />
    <path d="M9 8h6M9 12h6" />
  </svg>
);

export const BoxOpenIcon = () => (
  <svg {...props}>
    <path d="M3.5 9 12 4.5 20.5 9 12 13.5z" />
    <path d="M3.5 9v9.5L12 23l8.5-4.5V9" />
    <path d="M12 13.5V23" />
  </svg>
);
