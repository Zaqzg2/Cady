import React, { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import Sheet from './Sheet';
import { SearchIcon, CheckIcon } from './Icons';
import { db } from '../db/db';
import { formatCurrency } from '../utils/format';

export default function CustomerPicker({ open, onClose, onSelect, selectedId }) {
  const [query, setQuery] = useState('');
  const customers = useLiveQuery(() => db.customers.orderBy('name').toArray(), []);

  const filtered = useMemo(() => {
    if (!customers) return [];
    if (!query.trim()) return customers;
    const q = query.trim().toLowerCase();
    return customers.filter(
      (c) => c.name.toLowerCase().includes(q) || (c.phone || '').includes(q)
    );
  }, [customers, query]);

  return (
    <Sheet open={open} onClose={onClose} title="اختيار العميل" maxHeight="85vh">
      <div className="picker-search">
        <SearchIcon />
        <input
          type="text"
          placeholder="بحث بالاسم أو الهاتف (اختياري)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div className="customer-cards-grid">
        {filtered.map((c) => (
          <button
            key={c.id}
            className={`customer-pick-card drop-corner-sm ${selectedId === c.id ? 'selected' : ''}`}
            onClick={() => onSelect(c)}
          >
            {selectedId === c.id ? <span className="customer-pick-badge"><CheckIcon /></span> : null}
            <div className="customer-pick-avatar">{c.name.trim().charAt(0) || '؟'}</div>
            <span className="customer-pick-name">{c.name}</span>
            <span className="customer-pick-meta">
              {c.balance > 0 ? `مديون: ${formatCurrency(c.balance)}` : c.area || '—'}
            </span>
          </button>
        ))}
        {filtered.length === 0 ? <p className="picker-empty">لا توجد نتائج</p> : null}
      </div>

      <style>{`
        .picker-search {
          display: flex;
          align-items: center;
          gap: 8px;
          background: var(--color-surface-2);
          border: 1.5px solid var(--color-border);
          border-radius: var(--radius-sm);
          padding: 0 14px;
          height: 46px;
          margin-bottom: 12px;
        }
        .picker-search svg { width: 18px; height: 18px; color: var(--color-ink-faint); flex-shrink: 0; }
        .picker-search input {
          border: none; outline: none; background: transparent;
          flex: 1; font-size: 14.5px; color: var(--color-ink); font-family: inherit;
        }
        .customer-cards-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          max-height: 58vh;
          overflow-y: auto;
          padding-bottom: 4px;
        }
        .customer-pick-card {
          position: relative;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          background: var(--color-surface);
          border: 1.5px solid var(--color-border);
          padding: 16px 10px 14px;
          cursor: pointer;
          text-align: center;
          min-height: 116px;
        }
        .customer-pick-card.selected {
          border-color: var(--color-primary);
          background: rgba(200,30,30,0.05);
        }
        .customer-pick-card:active { transform: scale(0.97); }
        .customer-pick-badge {
          position: absolute;
          top: 8px;
          inset-inline-end: 8px;
          width: 18px; height: 18px;
          border-radius: 50%;
          background: var(--color-primary);
          color: white;
          display: flex; align-items: center; justify-content: center;
        }
        .customer-pick-badge svg { width: 11px; height: 11px; }
        .customer-pick-avatar {
          width: 44px; height: 44px;
          border-radius: 50%;
          background: var(--color-bg-sunken);
          color: var(--color-primary);
          display: flex; align-items: center; justify-content: center;
          font-weight: 800; font-size: 18px;
        }
        .customer-pick-name {
          font-weight: 700;
          font-size: 13px;
          color: var(--color-ink);
          line-height: 1.3;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .customer-pick-meta {
          font-size: 10.5px;
          color: var(--color-ink-faint);
          margin-top: auto;
        }
        .picker-empty {
          grid-column: 1 / -1;
          text-align: center;
          padding: 30px 0;
          color: var(--color-ink-faint);
          font-size: 13px;
        }
      `}</style>
    </Sheet>
  );
}
