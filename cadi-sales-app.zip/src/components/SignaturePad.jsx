import React, { useRef, useEffect, useState, forwardRef, useImperativeHandle } from 'react';

/**
 * منطقة توقيع باللمس. يكشف عبر ref:
 *  - getDataURL(): يرجع صورة PNG base64 (الجديدة أو المحمَّلة مسبقاً إن لم تُعدَّل) أو null إن كانت فارغة بالكامل
 *  - clear(): تفريغ اللوحة
 *  - isEmpty(): هل اللوحة فارغة
 *
 * يقبل initialDataURL لعرض توقيع محفوظ مسبقاً (مهم عند فتح فاتورة/سند للتعديل
 * حتى لا يضيع التوقيع الأصلي إذا لم يُعِد المستخدم التوقيع من جديد).
 */
const SignaturePad = forwardRef(function SignaturePad({ height = 160, initialDataURL = null }, ref) {
  const canvasRef = useRef(null);
  const drawing = useRef(false);
  const lastPoint = useRef(null);
  const [hasContent, setHasContent] = useState(false);
  const preservedInitialRef = useRef(initialDataURL); // يبقى محفوظاً حتى لو رسم المستخدم فوقه ثم محاه

  useEffect(() => {
    const canvas = canvasRef.current;
    const resize = () => {
      const ratio = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * ratio;
      canvas.height = rect.height * ratio;
      const ctx = canvas.getContext('2d');
      ctx.scale(ratio, ratio);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = '#1A1110';
      // إعادة رسم التوقيع الموجود مسبقاً (إن وُجد) بعد كل ضبط لمقاسات الكانفاس
      if (preservedInitialRef.current) {
        drawImage(ctx, preservedInitialRef.current, rect.width, rect.height);
      }
    };
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  // تحميل التوقيع الأولي عند توفره (مثلاً عند فتح الصفحة في وضع التعديل بعد تحميل البيانات من القاعدة)
  useEffect(() => {
    if (!initialDataURL) return;
    preservedInitialRef.current = initialDataURL;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const ratio = window.devicePixelRatio || 1;
    drawImage(ctx, initialDataURL, canvas.width / ratio, canvas.height / ratio);
    setHasContent(true);
  }, [initialDataURL]);

  function drawImage(ctx, dataUrl, width, height) {
    const img = new Image();
    img.onload = () => {
      ctx.clearRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);
    };
    img.src = dataUrl;
  }

  function getPoint(e) {
    const rect = canvasRef.current.getBoundingClientRect();
    const touch = e.touches?.[0];
    const clientX = touch ? touch.clientX : e.clientX;
    const clientY = touch ? touch.clientY : e.clientY;
    return { x: clientX - rect.left, y: clientY - rect.top };
  }

  function start(e) {
    e.preventDefault();
    // إذا كان هناك توقيع محمَّل مسبقاً ولم يُلمَس بعد، أول لمسة جديدة تعتبر توقيعاً جديداً بديلاً (لا رسماً فوق القديم)
    if (preservedInitialRef.current && !drawing.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      const ratio = window.devicePixelRatio || 1;
      ctx.clearRect(0, 0, canvas.width / ratio, canvas.height / ratio);
      preservedInitialRef.current = null;
      setHasContent(false);
    }
    drawing.current = true;
    lastPoint.current = getPoint(e);
  }

  function move(e) {
    if (!drawing.current) return;
    e.preventDefault();
    const ctx = canvasRef.current.getContext('2d');
    const point = getPoint(e);
    ctx.beginPath();
    ctx.moveTo(lastPoint.current.x, lastPoint.current.y);
    ctx.lineTo(point.x, point.y);
    ctx.stroke();
    lastPoint.current = point;
    setHasContent(true);
  }

  function end() {
    drawing.current = false;
    lastPoint.current = null;
  }

  useImperativeHandle(ref, () => ({
    // يرجع التوقيع الجديد إن رُسم، أو التوقيع المحمَّل مسبقاً إن لم يُلمَس، أو null إن كانت اللوحة فارغة بالكامل
    getDataURL: () => {
      if (!hasContent) return null;
      if (preservedInitialRef.current) return preservedInitialRef.current;
      return canvasRef.current.toDataURL('image/png');
    },
    clear: () => {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      const ratio = window.devicePixelRatio || 1;
      ctx.clearRect(0, 0, canvas.width / ratio, canvas.height / ratio);
      preservedInitialRef.current = null;
      setHasContent(false);
    },
    isEmpty: () => !hasContent,
  }), [hasContent]);

  return (
    <div className="signature-pad-wrap">
      <canvas
        ref={canvasRef}
        className="signature-canvas"
        style={{ height: `${height}px` }}
        onMouseDown={start}
        onMouseMove={move}
        onMouseUp={end}
        onMouseLeave={end}
        onTouchStart={start}
        onTouchMove={move}
        onTouchEnd={end}
      />
      {!hasContent ? <span className="signature-placeholder">وقّع هنا باللمس</span> : null}
      {hasContent ? (
        <button
          type="button"
          className="signature-clear-btn"
          onClick={() => {
            const canvas = canvasRef.current;
            const ctx = canvas.getContext('2d');
            const ratio = window.devicePixelRatio || 1;
            ctx.clearRect(0, 0, canvas.width / ratio, canvas.height / ratio);
            preservedInitialRef.current = null;
            setHasContent(false);
          }}
        >
          محو وإعادة التوقيع
        </button>
      ) : null}

      <style>{`
        .signature-pad-wrap {
          position: relative;
          width: 100%;
          border: 1.5px dashed var(--color-border-strong);
          border-radius: var(--radius-md);
          background: var(--color-surface-2);
          overflow: hidden;
        }
        .signature-canvas {
          width: 100%;
          display: block;
          touch-action: none;
          cursor: crosshair;
        }
        .signature-placeholder {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          color: var(--color-ink-faint);
          font-size: 13px;
          pointer-events: none;
          font-weight: 600;
        }
        .signature-clear-btn {
          position: absolute;
          bottom: 6px;
          left: 6px;
          background: var(--color-bg-elevated);
          border: 1px solid var(--color-border);
          border-radius: 999px;
          padding: 5px 12px;
          font-size: 11px;
          font-weight: 700;
          color: var(--color-danger);
          cursor: pointer;
        }
      `}</style>
    </div>
  );
});

export default SignaturePad;
