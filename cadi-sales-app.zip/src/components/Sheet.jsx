import React, { useEffect } from 'react';
import { CloseIcon } from './Icons';

/**
 * نافذة منبثقة من الأسفل (bottom sheet) — مناسبة للمس على الموبايل.
 */
export default function Sheet({ open, onClose, title, children, maxHeight = '85vh' }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === 'Escape') onClose?.(); };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="sheet-overlay" onClick={onClose}>
      <div
        className="sheet-panel"
        style={{ maxHeight }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <div className="sheet-handle" />
        <div className="sheet-header">
          <h2 className="sheet-title">{title}</h2>
          <button className="sheet-close" onClick={onClose} aria-label="إغلاق">
            <CloseIcon />
          </button>
        </div>
        <div className="sheet-body">{children}</div>
      </div>

      <style>{`
        .sheet-overlay {
          position: fixed;
          inset: 0;
          background: rgba(20, 12, 10, 0.45);
          z-index: 100;
          display: flex;
          align-items: flex-end;
          justify-content: center;
          animation: fadeUp 0.18s ease;
        }
        .sheet-panel {
          width: 100%;
          max-width: 560px;
          background: var(--color-bg-elevated);
          border-radius: 22px 22px 0 0;
          padding: 8px 18px calc(18px + var(--safe-bottom));
          display: flex;
          flex-direction: column;
          animation: scaleIn 0.2s ease;
          box-shadow: var(--shadow-elevated);
        }
        .sheet-handle {
          width: 40px;
          height: 4px;
          background: var(--color-border-strong);
          border-radius: 2px;
          margin: 6px auto 4px;
        }
        .sheet-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 8px 2px 12px;
          border-bottom: 1px solid var(--color-border);
          margin-bottom: 14px;
        }
        .sheet-title {
          font-size: 17px;
          font-weight: 800;
          margin: 0;
          color: var(--color-ink);
        }
        .sheet-close {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          border: none;
          background: var(--color-bg-sunken);
          color: var(--color-ink-soft);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }
        .sheet-close svg {
          width: 18px;
          height: 18px;
        }
        .sheet-body {
          overflow-y: auto;
          flex: 1;
        }
      `}</style>
    </div>
  );
}
