import React, { useState } from 'react';
import { ChevronIcon } from './Icons';

export default function SettingsSection({ icon, title, subtitle, defaultOpen = false, children }) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="settings-section">
      <button className="settings-section-header" onClick={() => setOpen((o) => !o)}>
        <div className="settings-section-icon">{icon}</div>
        <div className="settings-section-titles">
          <span className="settings-section-title">{title}</span>
          {subtitle ? <span className="settings-section-subtitle">{subtitle}</span> : null}
        </div>
        <div className={`settings-section-chevron ${open ? 'open' : ''}`}>
          <ChevronIcon dir="end" />
        </div>
      </button>
      {open ? <div className="settings-section-body">{children}</div> : null}

      <style>{`
        .settings-section {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          margin-bottom: 10px;
          overflow: hidden;
        }
        .settings-section-header {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 14px;
          background: transparent;
          border: none;
          cursor: pointer;
        }
        .settings-section-icon {
          width: 38px; height: 38px;
          border-radius: 50%;
          background: rgba(200,30,30,0.08);
          color: var(--color-primary);
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
        }
        .settings-section-icon svg { width: 19px; height: 19px; }
        .settings-section-titles {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 1px;
          text-align: start;
        }
        .settings-section-title {
          font-weight: 700;
          font-size: 14px;
          color: var(--color-ink);
        }
        .settings-section-subtitle {
          font-size: 11.5px;
          color: var(--color-ink-faint);
        }
        .settings-section-chevron {
          color: var(--color-ink-faint);
          transition: transform 0.2s ease;
          transform: rotate(90deg);
          flex-shrink: 0;
        }
        .settings-section-chevron.open {
          transform: rotate(-90deg);
        }
        .settings-section-chevron svg { width: 16px; height: 16px; }
        .settings-section-body {
          padding: 0 14px 16px;
          border-top: 1px solid var(--color-border);
          padding-top: 14px;
        }
      `}</style>
    </div>
  );
}
