import React, { createContext, useCallback, useContext, useRef, useState } from 'react';
import { CheckIcon, CloseIcon } from './Icons';

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  const [toast, setToast] = useState(null);
  const timerRef = useRef(null);

  const showToast = useCallback((message, type = 'success') => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setToast({ message, type, id: Date.now() });
    timerRef.current = setTimeout(() => setToast(null), 2400);
  }, []);

  return (
    <ToastContext.Provider value={showToast}>
      {children}
      {toast ? (
        <div className={`toast toast-${toast.type}`} key={toast.id}>
          <span className="toast-icon">{toast.type === 'error' ? <CloseIcon /> : <CheckIcon />}</span>
          <span>{toast.message}</span>
          <style>{`
            .toast {
              position: fixed;
              bottom: calc(var(--nav-h) + var(--safe-bottom) + 14px);
              left: 50%;
              transform: translateX(-50%);
              background: var(--color-ink);
              color: white;
              padding: 12px 18px;
              border-radius: 999px;
              font-size: 13.5px;
              font-weight: 600;
              display: flex;
              align-items: center;
              gap: 8px;
              z-index: 200;
              animation: toastIn 0.22s ease;
              box-shadow: var(--shadow-elevated);
              max-width: 86vw;
            }
            .toast-error {
              background: var(--color-danger);
            }
            .toast-icon {
              width: 18px;
              height: 18px;
              display: flex;
              flex-shrink: 0;
            }
            .toast-icon svg {
              width: 100%;
              height: 100%;
            }
          `}</style>
        </div>
      ) : null}
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
