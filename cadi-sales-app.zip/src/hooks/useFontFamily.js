// ============================================================
// Hook لإدارة خط واجهة التطبيق (يمكن تبديله من الإعدادات)
// ============================================================
import { useEffect, useState, useCallback } from 'react';
import { getSettings, updateSettings } from '../db/settings';

export function useFontFamily() {
  const [fontFamily, setFontFamilyState] = useState('Tajawal');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    getSettings().then((s) => {
      setFontFamilyState(s.fontFamily || 'Tajawal');
      setLoaded(true);
    });
  }, []);

  useEffect(() => {
    if (!loaded) return;
    applyFontFamily(fontFamily);
  }, [fontFamily, loaded]);

  const setFontFamily = useCallback(async (newFont) => {
    setFontFamilyState(newFont);
    await updateSettings({ fontFamily: newFont });
  }, []);

  return { fontFamily, setFontFamily, loaded };
}

/**
 * يطبّق الخط المختار على متغيرات CSS العامة فوراً (بدون إعادة تحميل الصفحة).
 * يصدَّر بشكل مستقل لاستخدامه أيضاً عند توليد الإيصالات (لضمان تطابق الخط
 * بين الواجهة والمستندات المطبوعة).
 */
export function applyFontFamily(fontFamily) {
  const stack = `'${fontFamily}', 'Cairo', system-ui, sans-serif`;
  document.documentElement.style.setProperty('--font-body', stack);
  document.documentElement.style.setProperty('--font-display', stack);
}
