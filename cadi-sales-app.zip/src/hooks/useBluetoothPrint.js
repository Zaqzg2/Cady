// ============================================================
// Hook لإدارة عملية الطباعة عبر بلوتوث
// ============================================================
import { useCallback, useState } from 'react';
import { bluetoothPrinter } from '../services/bluetoothPrinter';
import { updateSettings } from '../db/settings';

export function useBluetoothPrint() {
  const [printing, setPrinting] = useState(false);
  const [error, setError] = useState(null);

  const ensureConnected = useCallback(async () => {
    if (bluetoothPrinter.isConnected()) return true;

    if (!bluetoothPrinter.isSupported()) {
      setError('NOT_SUPPORTED');
      return false;
    }

    try {
      const info = await bluetoothPrinter.connect();
      await updateSettings({
        printer: { connected: true, deviceName: info.name, deviceId: info.id },
      });
      return true;
    } catch (e) {
      if (e?.name === 'NotFoundError') {
        // المستخدم أغلق نافذة اختيار الجهاز — ليس خطأً حقيقياً
        return false;
      }
      setError(e?.message || 'CONNECTION_FAILED');
      return false;
    }
  }, []);

  const printBytes = useCallback(async (bytes) => {
    setPrinting(true);
    setError(null);
    try {
      const connected = await ensureConnected();
      if (!connected) return false;
      await bluetoothPrinter.write(bytes);
      return true;
    } catch (e) {
      setError(e?.message || 'PRINT_FAILED');
      return false;
    } finally {
      setPrinting(false);
    }
  }, [ensureConnected]);

  return { printing, error, printBytes, ensureConnected, clearError: () => setError(null) };
}
