// ============================================================
// Hook لإدارة الوضع الليلي / النهاري
// ============================================================
import { useEffect, useState, useCallback } from 'react';
import { getSettings, updateSettings } from '../db/settings';

export function useTheme() {
  const [theme, setThemeState] = useState('light');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    getSettings().then((s) => {
      setThemeState(s.theme || 'light');
      setLoaded(true);
    });
  }, []);

  useEffect(() => {
    if (!loaded) return;
    const resolved = resolveTheme(theme);
    document.documentElement.setAttribute('data-theme', resolved);
  }, [theme, loaded]);

  useEffect(() => {
    if (theme !== 'system') return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = () => {
      document.documentElement.setAttribute('data-theme', mq.matches ? 'dark' : 'light');
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, [theme]);

  const setTheme = useCallback(async (newTheme) => {
    setThemeState(newTheme);
    await updateSettings({ theme: newTheme });
  }, []);

  return { theme, setTheme, loaded };
}

function resolveTheme(theme) {
  if (theme === 'system') {
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  return theme;
}
