// ============================================================
// Hook لإدارة تثبيت التطبيق على الشاشة الرئيسية (PWA Install Prompt)
// ============================================================
import { useEffect, useState, useCallback } from 'react';

export function useInstallPrompt() {
  const [deferredEvent, setDeferredEvent] = useState(null);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    function handleBeforeInstall(e) {
      e.preventDefault();
      setDeferredEvent(e);
    }
    function handleInstalled() {
      setInstalled(true);
      setDeferredEvent(null);
    }

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleInstalled);

    // إن كان التطبيق يعمل في standalone (مثبّت أصلاً) لا نعرض الزر
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleInstalled);
    };
  }, []);

  const promptInstall = useCallback(async () => {
    if (!deferredEvent) return false;
    deferredEvent.prompt();
    const { outcome } = await deferredEvent.userChoice;
    setDeferredEvent(null);
    return outcome === 'accepted';
  }, [deferredEvent]);

  return {
    canInstall: !!deferredEvent && !installed,
    installed,
    promptInstall,
  };
}
