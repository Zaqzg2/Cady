// ============================================================
// خدمة الاتصال بطابعة بلوتوث حرارية 80مم عبر Web Bluetooth API
// ============================================================

// معظم طابعات ESC/POS الرخيصة الشائعة (مثل سلسلة طابعات "ESC POS" الصينية)
// تكشف عن خدمة عامة بأحد هذه الـ UUIDs الشائعة
const COMMON_PRINTER_SERVICE_UUIDS = [
  '000018f0-0000-1000-8000-00805f9b34fb', // خدمة طابعة عامة شائعة جداً
  '0000ff00-0000-1000-8000-00805f9b34fb',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
];

class BluetoothPrinterService {
  constructor() {
    this.device = null;
    this.characteristic = null;
  }

  isSupported() {
    return typeof navigator !== 'undefined' && !!navigator.bluetooth;
  }

  isConnected() {
    return !!(this.device?.gatt?.connected && this.characteristic);
  }

  /**
   * يفتح نافذة اختيار أجهزة بلوتوث المتصفح ويحاول الاتصال بأول خدمة كتابة متاحة.
   */
  async connect() {
    if (!this.isSupported()) {
      throw new Error('NOT_SUPPORTED');
    }

    this.device = await navigator.bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: COMMON_PRINTER_SERVICE_UUIDS,
    });

    this.device.addEventListener('gattserverdisconnected', () => {
      this.characteristic = null;
    });

    const server = await this.device.gatt.connect();

    let foundCharacteristic = null;
    for (const serviceUuid of COMMON_PRINTER_SERVICE_UUIDS) {
      try {
        const service = await server.getPrimaryService(serviceUuid);
        const characteristics = await service.getCharacteristics();
        foundCharacteristic = characteristics.find(
          (c) => c.properties.write || c.properties.writeWithoutResponse
        ) || characteristics[0];
        if (foundCharacteristic) break;
      } catch {
        // الخدمة غير متوفرة على هذا الجهاز، نحاول التالية
        continue;
      }
    }

    if (!foundCharacteristic) {
      // محاولة أخيرة: فحص كل الخدمات المتاحة على الجهاز
      const services = await server.getPrimaryServices();
      for (const service of services) {
        try {
          const characteristics = await service.getCharacteristics();
          const writable = characteristics.find(
            (c) => c.properties.write || c.properties.writeWithoutResponse
          );
          if (writable) { foundCharacteristic = writable; break; }
        } catch {
          continue;
        }
      }
    }

    if (!foundCharacteristic) {
      throw new Error('NO_WRITABLE_CHARACTERISTIC');
    }

    this.characteristic = foundCharacteristic;
    return {
      name: this.device.name || 'طابعة بدون اسم',
      id: this.device.id,
    };
  }

  async disconnect() {
    if (this.device?.gatt?.connected) {
      this.device.gatt.disconnect();
    }
    this.characteristic = null;
  }

  /**
   * إرسال بيانات (Uint8Array) للطابعة على دفعات (chunks) لتجنب تجاوز حد MTU.
   */
  async write(bytes) {
    if (!this.isConnected()) {
      throw new Error('NOT_CONNECTED');
    }
    const chunkSize = 180;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      const chunk = bytes.slice(i, i + chunkSize);
      if (this.characteristic.properties.writeWithoutResponse) {
        await this.characteristic.writeValueWithoutResponse(chunk);
      } else {
        await this.characteristic.writeValue(chunk);
      }
      // تأخير صغير بين الدفعات لإعطاء الطابعة وقتاً للمعالجة
      await new Promise((r) => setTimeout(r, 20));
    }
  }
}

export const bluetoothPrinter = new BluetoothPrinterService();
