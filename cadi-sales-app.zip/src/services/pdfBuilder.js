// ============================================================
// توليد ملف PDF حقيقي من أي قالب إيصال أو كشف حساب
// يحول عنصر HTML المعروض فعلياً إلى صورة (يحافظ على شكل العربي الصحيح
// بدلاً من الاعتماد على رسم نص عربي مباشر في jsPDF الذي قد يُشوّه الحروف)
// ثم يضع هذه الصورة داخل صفحة PDF بعرض الورق المطلوب (80مم للإيصال، 210مم لكشف حساب A4).
// ============================================================
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

/**
 * يحوّل عنصر DOM (قالب إيصال أو كشف حساب) إلى ملف PDF ويُرجعه كـ Blob.
 * @param {HTMLElement} element - عنصر القالب المعروض المطلوب تصويره
 * @param {number} paperWidthMm - عرض الورق بالمليمتر (80 لإيصال حراري، 210 لكشف حساب A4)
 */
export async function elementToReceiptPdfBlob(element, paperWidthMm = 80) {
  const canvas = await html2canvas(element, {
    scale: 3, // دقة عالية لوضوح النص العربي الصغير عند الطباعة
    backgroundColor: '#ffffff',
    useCORS: true,
  });

  const imgData = canvas.toDataURL('image/png');

  // نحسب ارتفاع الصفحة بالمليمتر بناءً على نسبة الصورة الفعلية
  const pageWidthMm = paperWidthMm;
  const pageHeightMm = (canvas.height / canvas.width) * pageWidthMm;

  const pdf = new jsPDF({
    unit: 'mm',
    format: [pageWidthMm, pageHeightMm],
  });

  pdf.addImage(imgData, 'PNG', 0, 0, pageWidthMm, pageHeightMm);

  return pdf.output('blob');
}

/**
 * يولّد PDF من عنصر القالب ويبدأ تحميله مباشرة بنفس اسم الملف المُمرَّر.
 */
export async function downloadElementAsPdf(element, filename, paperWidthMm = 80) {
  const blob = await elementToReceiptPdfBlob(element, paperWidthMm);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * يولّد PDF من عنصر القالب ويُرجعه كملف File جاهز للمشاركة عبر Web Share API.
 */
export async function elementToReceiptPdfFile(element, filename, paperWidthMm = 80) {
  const blob = await elementToReceiptPdfBlob(element, paperWidthMm);
  return new File([blob], filename.endsWith('.pdf') ? filename : `${filename}.pdf`, {
    type: 'application/pdf',
  });
}
