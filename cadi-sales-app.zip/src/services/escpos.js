// ============================================================
// مُنشئ أوامر ESC/POS لطابعات الإيصالات الحرارية (80مم)
// يبني مصفوفة Uint8Array جاهزة للإرسال عبر Bluetooth
// ============================================================

const ESC = 0x1b;
const GS = 0x1d;

export class EscPosBuilder {
  constructor() {
    this.bytes = [];
  }

  _push(...arr) {
    this.bytes.push(...arr);
    return this;
  }

  init() {
    this._push(ESC, 0x40); // ESC @  — إعادة ضبط الطابعة
    // ESC t n — تحديد جدول ترميز الأحرف الداخلي للطابعة (Code Page).
    // n=22 يطابق CP864 (عربي DOS) في أغلب طابعات ESC/POS الصينية الشائعة.
    // n=32 يطابق CP1256 (عربي Windows) في بعض الطابعات الأخرى.
    const codePageByte = activeEncodingTable === CP1256_MAP ? 32 : 22;
    return this._push(ESC, 0x74, codePageByte);
  }

  align(mode) {
    // mode: 'left' | 'center' | 'right'
    const map = { left: 0, center: 1, right: 2 };
    return this._push(ESC, 0x61, map[mode] ?? 0);
  }

  bold(on) {
    return this._push(ESC, 0x45, on ? 1 : 0);
  }

  doubleSize(on) {
    // GS ! n — حجم مضاعف للعرض والارتفاع
    return this._push(GS, 0x21, on ? 0x11 : 0x00);
  }

  fontSize(scale) {
    // scale: 0 = عادي، 1 = مضاعف الارتفاع، 2 = مضاعف الكل
    const n = scale === 2 ? 0x11 : scale === 1 ? 0x01 : 0x00;
    return this._push(GS, 0x21, n);
  }

  underline(on) {
    return this._push(ESC, 0x2d, on ? 1 : 0);
  }

  text(str) {
    const encoded = encodeArabicText(str);
    this.bytes.push(...encoded);
    return this;
  }

  line(str = '') {
    this.text(str);
    return this.newline();
  }

  newline(n = 1) {
    for (let i = 0; i < n; i++) this._push(0x0a);
    return this;
  }

  divider(char = '-', width = 32) {
    return this.line(char.repeat(width));
  }

  feed(n = 3) {
    return this._push(ESC, 0x64, n);
  }

  cut() {
    return this._push(GS, 0x56, 1);
  }

  /**
   * طباعة صورة (مثل التوقيع) من Canvas ImageData أحادي اللون عبر ESC/POS raster (GS v 0).
   * widthPx يجب أن يكون مضاعفاً لـ 8.
   */
  image(monoBitmap, widthPx, heightPx) {
    const widthBytes = Math.ceil(widthPx / 8);
    this._push(GS, 0x76, 0x30, 0x00); // GS v 0 — راستر بت إماج
    this._push(widthBytes & 0xff, (widthBytes >> 8) & 0xff);
    this._push(heightPx & 0xff, (heightPx >> 8) & 0xff);
    this.bytes.push(...monoBitmap);
    return this;
  }

  build() {
    return new Uint8Array(this.bytes);
  }
}

/**
 * جدول تحويل Unicode → CP864 (الترميز العربي القياسي لطابعات ESC/POS الحرارية).
 * هذا أساسي وضروري: طابعات ESC/POS الصينية الشائعة لا تدعم UTF-8 إطلاقاً،
 * وتتوقع بايتاً واحداً لكل حرف بصيغة Code Page تقليدية. إرسال UTF-8 لها
 * (كما كان يحدث سابقاً) ينتج عنه رموز عشوائية مكسورة بدل النص العربي.
 * المصدر: جدول CP864 الرسمي المنشور على unicode.org.
 */
const CP864_MAP = {
  0x0660: 0x80, 0x0661: 0x81, 0x0662: 0x82, 0x0663: 0x83, 0x0664: 0x84,
  0x0665: 0x85, 0x0666: 0x86, 0x0667: 0x87, 0x0668: 0x88, 0x0669: 0x89,
  0x060C: 0xAC, 0x061B: 0xBB, 0x061F: 0xBF,
  0x0621: 0xC1, 0x0622: 0xC2, 0x0623: 0xC3, 0x0624: 0xC4, 0x0625: 0xC5,
  0x0626: 0xC6, 0x0627: 0xC7, 0x0628: 0xC8, 0x0629: 0xC9, 0x062A: 0xCA,
  0x062B: 0xCB, 0x062C: 0xCC, 0x062D: 0xCD, 0x062E: 0xCE, 0x062F: 0xCF,
  0x0630: 0xD0, 0x0631: 0xD1, 0x0632: 0xD2, 0x0633: 0xD3, 0x0634: 0xD4,
  0x0635: 0xD5, 0x0636: 0xD6, 0x0637: 0xD7, 0x0638: 0xD8, 0x0639: 0xD9,
  0x063A: 0xDA,
  0x0640: 0xE0, 0x0641: 0xE1, 0x0642: 0xE2, 0x0643: 0xE3, 0x0644: 0xE4,
  0x0645: 0xE5, 0x0646: 0xE6, 0x0647: 0xE7, 0x0648: 0xE8, 0x0649: 0xE9,
  0x064A: 0xEA, 0x064B: 0xEB, 0x064C: 0xEC, 0x064D: 0xED, 0x064E: 0xEE,
  0x064F: 0xEF, 0x0650: 0xF0, 0x0651: 0xF1, 0x0652: 0xF2,
};

/**
 * جدول تحويل Unicode → CP1256 (الترميز العربي البديل الشائع في بيئة Windows).
 * بعض طابعات ESC/POS الصينية تستخدم هذا بدل CP864 — لذا نوفره كخيار بديل
 * قابل للاختيار من الإعدادات إن لم تظهر النصوص بشكل صحيح بـ CP864.
 */
const CP1256_MAP = {
  0x060C: 0xA1, 0x061B: 0xBA, 0x061F: 0xBF,
  0x0621: 0xC1, 0x0622: 0xC2, 0x0623: 0xC3, 0x0624: 0xC4, 0x0625: 0xC5,
  0x0626: 0xC6, 0x0627: 0xC7, 0x0628: 0xC8, 0x0629: 0xC9, 0x062A: 0xCA,
  0x062B: 0xCB, 0x062C: 0xCC, 0x062D: 0xCD, 0x062E: 0xCE, 0x062F: 0xCF,
  0x0630: 0xD0, 0x0631: 0xD1, 0x0632: 0xD2, 0x0633: 0xD3, 0x0634: 0xD4,
  0x0635: 0xD5, 0x0636: 0xD6, 0x0637: 0xD8, 0x0638: 0xD9, 0x0639: 0xDB,
  0x063A: 0xDC,
  0x0640: 0xDD, 0x0641: 0xDE, 0x0642: 0xDF, 0x0643: 0xE0, 0x0644: 0xE1,
  0x0645: 0xE3, 0x0646: 0xE4, 0x0647: 0xE5, 0x0648: 0xE6, 0x0649: 0xEC,
  0x064A: 0xED, 0x064B: 0xF0, 0x064C: 0xF1, 0x064D: 0xF2, 0x064E: 0xF3,
  0x064F: 0xF5, 0x0650: 0xF6, 0x0651: 0xF8, 0x0652: 0xFA,
  0x0660: 0x30, 0x0661: 0x31, 0x0662: 0x32, 0x0663: 0x33, 0x0664: 0x34,
  0x0665: 0x35, 0x0666: 0x36, 0x0667: 0x37, 0x0668: 0x38, 0x0669: 0x39,
};

let activeEncodingTable = CP864_MAP;

/**
 * يضبط جدول الترميز المستخدم لكل النصوص العربية اللاحقة في كل بنايات الإيصال.
 * يُستدعى من الإعدادات حسب اختيار المستخدم (افتراضياً CP864).
 */
export function setArabicEncoding(encoding) {
  activeEncodingTable = encoding === 'cp1256' ? CP1256_MAP : CP864_MAP;
}

function encodeArabicText(str) {
  const bytes = [];
  for (const ch of str) {
    const code = ch.codePointAt(0);
    if (code < 0x80) {
      // ASCII (أرقام، حروف لاتينية، علامات) — بايت واحد مطابق مباشرة
      bytes.push(code);
    } else {
      const mapped = activeEncodingTable[code];
      // إن لم يوجد الحرف في الجدول (رمز غير مدعوم)، نستخدم علامة استفهام بدل بايت عشوائي مكسور
      bytes.push(mapped !== undefined ? mapped : 0x3F);
    }
  }
  return bytes;
}

/**
 * يحوّل عنصر <canvas> طويل (مثل إيصال كامل) إلى مجموعة شرائح bitmap أحادية اللون،
 * كل شريحة بارتفاع آمن (slabHeight) لتجنّب تجاوز سعة buffer الطابعة الداخلي
 * عند إرسال صورة ضخمة واحدة. تُستخدم لطباعة الإيصال كاملاً كصورة (نص + أرقام)
 * بدل أوامر نصية، لتجاوز قيود الطابعات التي لا تدعم ربط الحروف العربية.
 */
export function canvasToMonoBitmapSlices(canvas, threshold = 128, slabHeight = 240) {
  const totalHeight = canvas.height;
  const slices = [];
  for (let y = 0; y < totalHeight; y += slabHeight) {
    const sliceHeight = Math.min(slabHeight, totalHeight - y);
    const sliceCanvas = document.createElement('canvas');
    sliceCanvas.width = canvas.width;
    sliceCanvas.height = sliceHeight;
    const sliceCtx = sliceCanvas.getContext('2d');
    sliceCtx.drawImage(canvas, 0, -y);
    slices.push(canvasToMonoBitmap(sliceCanvas, threshold));
  }
  return slices;
}

/**
 * يحوّل عنصر <canvas> إلى bitmap أحادي اللون (1bpp) متوافق مع أوامر GS v 0.
 * يُستخدم لطباعة التوقيع كصورة.
 */
export function canvasToMonoBitmap(canvas, threshold = 128) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width;
  const h = canvas.height;
  const imageData = ctx.getImageData(0, 0, w, h);
  const widthBytes = Math.ceil(w / 8);
  const bitmap = new Uint8Array(widthBytes * h);

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const r = imageData.data[idx];
      const g = imageData.data[idx + 1];
      const b = imageData.data[idx + 2];
      const a = imageData.data[idx + 3];
      const gray = (r + g + b) / 3;
      const isDark = a > 10 && gray < threshold;
      if (isDark) {
        const byteIndex = y * widthBytes + (x >> 3);
        const bitIndex = 7 - (x % 8);
        bitmap[byteIndex] |= (1 << bitIndex);
      }
    }
  }
  return { bitmap, widthPx: w, heightPx: h };
}

/**
 * يحمّل صورة (base64 dataURL أو رابط URL عادي مثل ملف مستورد من Vite) إلى canvas
 * مصغّر بعرض مناسب للطباعة (مضاعف 8) ويُرجع bitmap أحادي اللون جاهز للطباعة.
 */
export function dataUrlToMonoBitmap(dataUrl, targetWidthPx = 384) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const width = targetWidthPx - (targetWidthPx % 8);
      const scale = width / img.width;
      const height = Math.round(img.height * scale);

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);

      resolve(canvasToMonoBitmap(canvas));
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}
