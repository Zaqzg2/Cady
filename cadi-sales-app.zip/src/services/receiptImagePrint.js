// ============================================================
// طباعة الإيصال بالكامل كصورة (نص + جداول + توقيع + شعار في صورة واحدة)
// ============================================================
// السبب: طابعات ESC/POS الحرارية الرخيصة الشائعة لا تدعم عرض الحروف العربية
// متصلة (Shaping) إطلاقاً — ترميزات Code Page كـ CP864/CP1256 تحتوي فقط على
// الشكل المنعزل لكل حرف، فتظهر الحروف منفصلة ومعكوسة الترتيب عند إرسالها كنص.
// الحل الموثوق: نعرض الإيصال بـHTML (الذي يرسم العربي بشكل صحيح تماماً عبر
// محرك المتصفح نفسه)، نحوّله لصورة (html2canvas)، ثم نطبعه بالكامل كصورة
// عبر أوامر GS v 0 — تماماً كآلية طباعة الشعار والتوقيع المستخدمة فعلياً.
// ============================================================
import html2canvas from 'html2canvas';
import { EscPosBuilder, canvasToMonoBitmapSlices } from './escpos';

/**
 * يتأكد أن كل عناصر <img> داخل العنصر المستهدف قد اكتمل تحميلها فعلياً في DOM
 * قبل تصويره بـhtml2canvas. هذا ضروري لتجنّب مشكلة شائعة وموثّقة في html2canvas:
 * لو صُوِّر العنصر قبل اكتمال تحميل صورة (مثل الشعار) داخله، فإن html2canvas
 * قد ترسم مساحة فارغة في موضعها بينما تخطيط flex/grid المحيط "يعيد ترتيب"
 * العناصر الأخرى لتعويض الفراغ — وهذا يُنتج تراكباً وتشويشاً ظاهراً فقط في
 * الصورة المطبوعة، رغم أن العرض المباشر على الشاشة (الذي ينتظر التحميل تلقائياً
 * بفعل سلوك المتصفح الطبيعي) يبدو سليماً تماماً.
 */
function waitForImagesLoaded(element) {
  const images = Array.from(element.querySelectorAll('img'));
  const pending = images.filter((img) => !img.complete || img.naturalWidth === 0);
  if (pending.length === 0) return Promise.resolve();

  return Promise.all(
    pending.map((img) => new Promise((resolve) => {
      const onDone = () => {
        img.removeEventListener('load', onDone);
        img.removeEventListener('error', onDone);
        resolve();
      };
      img.addEventListener('load', onDone);
      img.addEventListener('error', onDone); // لا نُعلّق الطباعة بسبب صورة فشلت، فقط نتابع
    }))
  );
}

/**
 * يحوّل عنصر DOM معروض فعلياً (قالب إيصال/كشف حساب) إلى أوامر ESC/POS جاهزة
 * للطباعة بالكامل كصورة، مقسّمة لشرائح آمنة الحجم.
 * targetWidthPx: عرض منطقة الطباعة الفعلي بالنقطة. القيم الشائعة لطابعات 80مم:
 *   576 نقطة (الأشيع — دقة 203dpi، منطقة طباعة ~72مم فعلية) — الافتراضي.
 *   384 نقطة (طابعات أقدم/أضيق منطقة طباعة).
 * إرسال عرض أصغر من العرض الفعلي يترك هامشاً فارغاً ويُصغّر النص نسبياً؛
 * إرسال عرض أكبر قد يتسبب بقصّ الصورة عن حدود الورق. القيمة قابلة للتغيير
 * من الإعدادات (طابعة البلوتوث) لمطابقة طابعة المستخدم بالتحديد.
 */
export async function buildImagePrintBytes(element, targetWidthPx = 576) {
  // الخطوة الأهم: نتأكد أن كل الصور (الشعار، التوقيع) قد اكتمل تحميلها فعلياً
  // في DOM، وأن المتصفح أتمّ إعادة التخطيط (layout/reflow) بعدها، قبل أي تصوير.
  // تخطي هذه الخطوة هو السبب الجذري الشائع لظهور عناصر متراكبة أو مفقودة في
  // الصورة المطبوعة رغم أن العرض المباشر على الشاشة يبدو سليماً تماماً.
  await waitForImagesLoaded(element);
  await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));

  // نصوّر العنصر بدقة عالية (scale: 3) بدل دقة الشاشة الفعلية المنخفضة،
  // ثم نُصغّرها (downscale) لعرض الطباعة المستهدف. هذا يحافظ على حدة النص
  // ووضوحه — تكبير صورة منخفضة الدقة (upscale) يُنتج بكسلات ضعيفة ومشوّشة،
  // بخلاف تصغير صورة عالية الدقة الذي يحافظ على التفاصيل الدقيقة للحروف.
  const sourceCanvas = await html2canvas(element, {
    scale: 3,
    backgroundColor: '#ffffff',
    useCORS: true,
    imageTimeout: 0, // لا نريد أي timeout داخلي يقطع تحميل الصور قبل اكتماله
  });

  // نُعيد رسم الصورة بعرض الطابعة المستهدف بالضبط (مضاعف لـ8 كما تتطلب GS v 0)
  const width = targetWidthPx - (targetWidthPx % 8);
  const scale = width / sourceCanvas.width;
  const height = Math.round(sourceCanvas.height * scale);

  const resizedCanvas = document.createElement('canvas');
  resizedCanvas.width = width;
  resizedCanvas.height = height;
  const ctx = resizedCanvas.getContext('2d');
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(sourceCanvas, 0, 0, width, height);

  const slices = canvasToMonoBitmapSlices(resizedCanvas, 128, 240);

  const builder = new EscPosBuilder();
  builder.init();
  builder.align('center');
  for (const { bitmap, widthPx, heightPx } of slices) {
    builder.image(bitmap, widthPx, heightPx);
  }
  builder.feed(3);
  builder.cut();

  return builder.build();
}
